@echo off
chcp 65001 >nul
set PYTHONUTF8=1
echo Κλείσε το Σύμβολον ERP πριν συνεχίσεις. Η ενημέρωση αλλάζει μόνο 2 αρχεία κώδικα.
echo Δεν αντικαθιστά τα Data, τις καρτέλες, τους λογαριασμούς ή τις ρυθμίσεις σου.
where py >nul 2>nul
if errorlevel 1 goto use_python
py -3 "%~dp0update_pending.py" %*
goto finished
:use_python
python "%~dp0update_pending.py" %*
:finished
set "SYMBOLON_UPDATE_EXIT=%ERRORLEVEL%"
pause
exit /b %SYMBOLON_UPDATE_EXIT%
