"""Apply the P9.5.1 pending display code-only fix; never open or replace user Data."""
import argparse
import ast
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import tempfile

FILES=('app/ui/desktop.py', 'app/ui/aade_dialog.py')


def sha(data):return hashlib.sha256(data).hexdigest()


def replace(path,data):
    fd,name=tempfile.mkstemp(prefix='.ebs-update-',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as stream:
            stream.write(data);stream.flush();os.fsync(stream.fileno())
        os.replace(name,path)
    finally:
        if os.path.exists(name):os.unlink(name)


def apply(target,package,*,check=False):
    target=Path(target).resolve();package=Path(package).resolve()
    manifest=json.loads((package/'UPDATE_MANIFEST.json').read_text(encoding='utf8'))
    if set(manifest['files'])!=set(FILES):raise ValueError('Μη έγκυρο πακέτο ενημέρωσης.')
    if not (target/'app/__main__.py').is_file():raise ValueError('Διάλεξε τον φάκελο που περιέχει το app και το ANOIGMA_MINI_ERP.bat.')
    before={};after={};changed=[]
    for name in FILES:
        path=target/name;source=package/'payload'/name
        if not path.resolve().is_relative_to(target) or not source.resolve().is_relative_to(package):
            raise ValueError('Μη έγκυρη διαδρομή ενημέρωσης.')
        old=path.read_bytes();new=source.read_bytes();entry=manifest['files'][name]
        if sha(new)!=entry['after']:raise ValueError('Αλλοιωμένο αρχείο ενημέρωσης: '+name)
        ast.parse(new,filename=name)
        if sha(old) not in (entry['before'],entry['after']):
            raise ValueError('Η εγκατάσταση έχει διαφορετική έκδοση αρχείου: '+name+'. Δεν άλλαξε τίποτα.')
        before[name]=old;after[name]=new
        if old!=new:changed.append(name)
    result=dict(update=manifest['update'],application=str(target),changed=changed,data_untouched=True)
    if check or not changed:return dict(result,status='CHECKED' if check else 'ALREADY_APPLIED')
    # All input validation finishes before any application file is touched.
    backup=target/'Updates'/('EBS-Check-'+datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
    for name,data in before.items():
        path=backup/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
    try:
        for name in changed:replace(target/name,after[name])
    except BaseException:
        for name in changed:
            if (target/name).read_bytes()!=before[name]:replace(target/name,before[name])
        raise
    result.update(status='APPLIED',backup=str(backup))
    (backup/'UPDATE_RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--target',type=Path);parser.add_argument('--check',action='store_true')
    args=parser.parse_args();package=Path(__file__).resolve().parent
    if args.target is None:
        import tkinter as tk
        from tkinter import filedialog
        root=tk.Tk();root.withdraw()
        try:folder=filedialog.askdirectory(parent=root,title='Διάλεξε την εγκατάσταση Σύμβολον ERP που χρησιμοποιείς (φάκελος με app)')
        finally:root.destroy()
        if not folder:return
        args.target=Path(folder)
    result=apply(args.target,package,check=args.check)
    print(json.dumps(result,ensure_ascii=False,indent=2))
    print('Η παραμετροποίηση και τα παραστατικά δεν άλλαξαν. Άνοιξε την ίδια εγκατάσταση. Οι νέες εγγραφές εμφανίζονται χωρίς προηγούμενη σύγκριση EBS.')


if __name__=='__main__':
    try:main()
    except Exception as exc:
        print('Η ενημέρωση δεν ολοκληρώθηκε: '+str(exc));raise SystemExit(1)
