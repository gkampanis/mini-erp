"""Three-sector presentation over the existing notebook and callbacks."""
from tkinter import ttk
from pathlib import Path
import tkinter as tk


class SectorNavigation:
    def __init__(self,owner,parent):
        self.owner=owner;self.current='expenses';self.compact=None;self.buttons={};self.images={}
        self.frame=ttk.Frame(parent,style='Navigation.TFrame',padding=10)
        self.caption=ttk.Label(self.frame,text='ΧΩΡΟΣ ΕΡΓΑΣΙΑΣ',style='NavigationCaption.TLabel')
        self.caption.pack(anchor='w',pady=(8,12))
        self.items=ttk.Frame(self.frame,style='Navigation.TFrame');self.items.pack(fill='x')
        for key,title in (('expenses','Έξοδα'),('income','Έσοδα'),('movement','Διακίνηση')):
            image=None
            path=Path(__file__).resolve().parents[2]/'docs/branding/navigation'/f'{key}.png'
            try:self.images[key]=tk.PhotoImage(master=owner.root,file=str(path));image=self.images[key]
            except (tk.TclError,OSError):pass
            button=ttk.Button(self.items,text=title,style='Navigation.TButton',command=lambda k=key:self.choose(k),compound='left')
            if image:button.configure(image=image)
            button.pack(fill='x',pady=3);self.buttons[key]=button
        self.cards=ttk.Button(self.items,text='Καρτέλες',style='Navigation.TButton',command=lambda:self.open_tab(owner.creditors_tab))
        self.cards.pack(fill='x',pady=(22,3))
        self.settings=ttk.Button(self.items,text='Ρυθμίσεις',style='Navigation.TButton',command=owner.open_settings)
        self.settings.pack(fill='x',pady=3)
        self.refresh_icons(owner.ui_preferences.theme)
        owner.root.bind('<Configure>',self._resize,add='+')
        owner.notebook.bind('<<NotebookTabChanged>>',lambda _:self.sync(),add='+')
        self._layout(owner.root.winfo_width()<1180)
        self.choose('expenses')

    def _resize(self,event):
        if event.widget is self.owner.root:self._layout(event.width<1180)

    def refresh_icons(self,mode):
        directory=Path(__file__).resolve().parents[2]/'docs/branding/navigation'
        for key,button in self.buttons.items():
            path=directory/(key+('-dark' if mode=='dark' else '')+'.png')
            try:
                self.images[key]=tk.PhotoImage(master=self.owner.root,file=str(path))
                button.configure(image=self.images[key])
            except (tk.TclError,OSError):button.configure(image='')

    def _layout(self,compact):
        if self.compact==compact:return
        self.compact=compact;self.frame.pack_forget()
        if compact:
            self.frame.pack(side='top',fill='x',before=self.owner.main_frame)
            self.caption.pack_forget()
        else:
            self.frame.pack(side='left',fill='y',before=self.owner.main_frame)
            self.caption.pack(anchor='w',pady=(8,12),before=self.items)
        for button in (*self.buttons.values(),self.cards,self.settings):
            button.pack_forget()
            button.pack(side='left' if compact else 'top',fill=None if compact else 'x',padx=2 if compact else 0,pady=2 if compact else 4)

    def tabs(self,key):
        owner=self.owner
        if key in ('income','movement'):return (owner.document_views[key].parent,)
        return (owner.documents_tab,owner.document_views['expenses'].parent,owner.document_views['purchases'].parent,owner.reviews_tab,owner.suppliers_tab,owner.creditors_tab,owner.reconciliation_tab)

    def choose(self,key,select=True):
        if key not in self.buttons:return
        self.current=key;book=self.owner.notebook
        visible={str(tab) for tab in self.tabs(key)}
        # add() restores hidden tabs at their original index, retaining widgets/state.
        for tab in book.tabs():
            if tab in visible:book.add(tab)
        if select:book.select(self.tabs(key)[0])
        for tab in book.tabs():
            if tab not in visible:book.hide(tab)
        for name,button in self.buttons.items():
            button.configure(style='NavigationSelected.TButton' if name==key else 'Navigation.TButton')

    def open_tab(self,tab):
        self.choose('expenses',select=False);self.owner.notebook.select(tab)

    def sync(self):
        selected=self.owner.notebook.select()
        if not selected:return
        key=next((k for k in self.buttons if selected in {str(t) for t in self.tabs(k)}),'expenses')
        if key!=self.current:self.choose(key,select=False)
