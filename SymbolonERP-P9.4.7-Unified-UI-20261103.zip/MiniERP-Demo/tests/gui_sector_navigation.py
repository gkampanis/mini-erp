"""Presentation-only sector navigation, using synthetic installation data."""
import unittest
from tests import gui_regressions as harness


class SectorNavigationTests(unittest.TestCase):
    setUpClass=classmethod(harness.DesktopRegressions.setUpClass.__func__)
    tearDownClass=classmethod(harness.DesktopRegressions.tearDownClass.__func__)
    setUp=harness.DesktopRegressions.setUp
    tearDown=harness.DesktopRegressions.tearDown
    def test_sectors_keep_existing_views_and_programmatic_reconciliation_links(self):
        app=self.app;nav=app.navigation
        before=app.erp.db.total_changes
        original=app.tree
        nav.choose('income');self.root.update()
        self.assertEqual(app.notebook.select(),str(app.document_views['income'].parent))
        self.assertEqual(nav.current,'income')
        nav.choose('movement');self.root.update()
        self.assertEqual(app.notebook.select(),str(app.document_views['movement'].parent))
        app.notebook.select(app.reconciliation_tab);self.root.update()
        self.assertEqual(nav.current,'expenses')
        app.notebook.select(app.documents_tab);self.root.update()
        self.assertIs(app.tree,original)
        self.assertEqual(app.erp.db.total_changes,before)

    def test_compact_navigation_preserves_posting_space_and_theme(self):
        app=self.app;root=self.root;root.state('normal')
        for mode in ('light','dark'):
            app.change_theme(mode)
            for size,compact in (('960x650',True),('1440x860',False)):
                root.geometry(size);root.update()
                self.assertEqual(app.navigation.compact,compact)
                for button in app.navigation.buttons.values():self.assertTrue(button.winfo_ismapped())
                for key in ('post','selected','one'):
                    button=app.rpa_panel.buttons[key]
                    self.assertGreaterEqual(button.winfo_width(),button.winfo_reqwidth())
                self.assertTrue(app.month_box.winfo_ismapped())
                self.assertTrue(app.tree.winfo_ismapped())
                for widget in (app.month_box,app.company_box,app.import_button,app.ebs_import_button):
                    self.assertGreaterEqual(widget.winfo_width(),widget.winfo_reqwidth())
                    self.assertLessEqual(widget.winfo_x()+widget.winfo_width(),widget.master.winfo_width())


if __name__=='__main__':unittest.main()
