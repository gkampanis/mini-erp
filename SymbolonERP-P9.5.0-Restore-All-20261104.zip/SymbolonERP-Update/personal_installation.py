"""Personal portable installation: use adjacent data, never the PC's default DB."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import zipfile
from datetime import datetime, timezone
from contextlib import closing


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def inspect_database(path):
    with closing(sqlite3.connect(Path(path).resolve().as_uri() + '?mode=ro', uri=True)) as db:
        if db.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
            raise ValueError('Database integrity check failed')
        if db.execute('PRAGMA foreign_key_check').fetchone() is not None:
            raise ValueError('Database foreign key check failed')
        tables = {}
        for (name,) in db.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").fetchall():
            quoted = '"' + name.replace('"', '""') + '"'
            rows = []
            for row in db.execute('SELECT * FROM ' + quoted):
                value = [dict(binary=v.hex()) if isinstance(v, bytes) else v for v in row]
                rows.append(hashlib.sha256(json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest())
            tables[name] = dict(rows=len(rows), fingerprint=hashlib.sha256(''.join(sorted(rows)).encode()).hexdigest())
        schema = list(db.execute('SELECT type,name,tbl_name,sql FROM sqlite_master ORDER BY type,name'))
        return dict(schema=hashlib.sha256(json.dumps(schema, ensure_ascii=False).encode()).hexdigest(), tables=tables)


def make_archive(source, application, destination, resources):
    """Snapshot all tables and all adjacent files. Source DB is read-only."""
    source, application, destination, resources = map(lambda p: Path(p).resolve(), (source, application, destination, resources))
    if not (source / 'mini_erp.sqlite3').is_file():
        raise ValueError('Missing source database; refusing to create an empty installation')
    if destination.is_relative_to(source) or destination.is_relative_to(application):
        raise ValueError('Export must be outside the data/application directory')
    if destination.exists():
        raise FileExistsError('The destination already exists; choose a new filename')
    destination.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='Symbolon-export-') as temporary:
        backup = Path(temporary) / 'mini_erp.sqlite3'
        with closing(sqlite3.connect((source / 'mini_erp.sqlite3').as_uri() + '?mode=ro', uri=True)) as db:
            with closing(sqlite3.connect(backup)) as target:
                db.backup(target)
        captured = inspect_database(backup)
        fd, name = tempfile.mkstemp(prefix='.symbolon-', suffix='.zip', dir=destination.parent)
        os.close(fd)
        staged = Path(name)
        try:
            files = {}
            with zipfile.ZipFile(staged, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
                def add(path, relative):
                    if path.is_symlink():
                        raise ValueError('Symbolic links cannot be silently omitted from this backup')
                    data = path.read_bytes()
                    archive.writestr('SymbolonERP/' + relative, data)
                    files[relative] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
                add(backup, 'Data/mini_erp.sqlite3')
                for path in sorted(source.rglob('*')):
                    if path.is_symlink():
                        raise ValueError('Data contains a symbolic link')
                    if not path.is_file():
                        continue
                    relative = path.relative_to(source).as_posix()
                    if relative in ('mini_erp.sqlite3', 'mini_erp.sqlite3-wal', 'mini_erp.sqlite3-shm'):
                        continue
                    add(path, 'Data/' + relative)
                for path in sorted(application.rglob('*')):
                    if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc':
                        add(path, 'MiniERP-Demo/' + path.relative_to(application).as_posix())
                for filename in ('personal_installation.py', 'ANOIGMA_MINI_ERP.bat', 'EXAGOGI_OLON.bat', 'ODIGIES.md'):
                    add(resources / filename, filename)
                manifest = dict(format='SymbolonERP-personal-full-v1', created_utc=datetime.now(timezone.utc).isoformat(), application=(application/'app/__init__.py').read_text(encoding='utf8').strip() if (application/'app/__init__.py').is_file() else 'unknown', credentials='Windows Credential Manager credentials are not included; re-enter on destination', database=captured, files=files)
                archive.writestr('SymbolonERP/TRANSFER_MANIFEST.json', json.dumps(manifest, ensure_ascii=False, indent=2))
            # If another process edited the database during the export, fail rather than claim a current snapshot.
            if inspect_database(source / 'mini_erp.sqlite3') != captured:
                raise ValueError('Data changed during export. Finish editing and export again.')
            with zipfile.ZipFile(staged) as archive:
                if archive.testzip() is not None:
                    raise ValueError('ZIP integrity check failed')
                for relative, entry in files.items():
                    data = archive.read('SymbolonERP/' + relative)
                    if len(data) != entry['bytes'] or hashlib.sha256(data).hexdigest() != entry['sha256']:
                        raise ValueError('ZIP file verification failed')
                restored = Path(temporary) / 'restored.sqlite3'
                restored.write_bytes(archive.read('SymbolonERP/Data/mini_erp.sqlite3'))
                if inspect_database(restored) != captured:
                    raise ValueError('Restored database does not match the source')
            # Exclusive destination: never overwrite an existing backup.
            with staged.open('rb') as inp, destination.open('xb') as out:
                for block in iter(lambda: inp.read(1024 * 1024), b''):
                    out.write(block)
            return dict(path=str(destination), sha256=digest(destination), tables=len(captured['tables']), verified=True)
        finally:
            staged.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--export', action='store_true')
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    data, app = root / 'Data', root / 'MiniERP-Demo'
    if sys.version_info < (3, 12):
        raise RuntimeError('Python 3.12 or newer is required')
    if not (data / 'mini_erp.sqlite3').is_file() or not (app / 'app' / '__main__.py').is_file():
        raise RuntimeError('Extract the entire ZIP first. Data and MiniERP-Demo must be next to this launcher.')
    if args.check:
        result = inspect_database(data / 'mini_erp.sqlite3')
        print(json.dumps(dict(integrity='ok', tables=len(result['tables']), data=str(data)), ensure_ascii=False))
        return 0
    if args.export:
        import tkinter as tk
        from tkinter import filedialog, messagebox
        window = tk.Tk()
        window.withdraw()
        try:
            filename = filedialog.asksaveasfilename(parent=window, title='Εξαγωγή ολόκληρης εγκατάστασης', initialfile='SymbolonERP-OLA-' + datetime.now().strftime('%Y%m%d-%H%M%S') + '.zip', defaultextension='.zip', filetypes=[('Πλήρες αντίγραφο Σύμβολον ERP', '*.zip')])
            if not filename:
                return 0
            result = make_archive(data, app, filename, root)
            messagebox.showinfo('Ολοκληρώθηκε', 'Αποθηκεύτηκαν όλα τα δεδομένα, η παραμετροποίηση και η εφαρμογή.\n\n' + result['path'], parent=window)
        finally:
            window.destroy()
        return 0
    env = os.environ.copy()
    env.update(PYTHONUTF8='1', PYTHONIOENCODING='utf-8')
    logs = root / 'Logs'
    logs.mkdir(exist_ok=True)
    with (logs / ('startup-' + datetime.now().strftime('%Y%m%d-%H%M%S') + '.log')).open('a', encoding='utf8') as log:
        log.write('Personal installation. Data: ' + str(data) + '\n')
        log.flush()
        return subprocess.call([sys.executable, '-X', 'faulthandler', '-u', '-m', 'app', '--data-dir', str(data)], cwd=app, env=env, stdout=log, stderr=subprocess.STDOUT)


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as error:
        print('ERROR:', error, file=sys.stderr)
        raise SystemExit(1)
