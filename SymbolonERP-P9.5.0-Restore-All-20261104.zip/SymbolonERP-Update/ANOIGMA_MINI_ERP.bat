@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
set "PYTHONUTF8=1"
where py >nul 2>nul
if errorlevel 1 goto python
py -3 "%~dp0restore_configuration.py" %*
goto end
:python
python "%~dp0restore_configuration.py" %*
:end
if not errorlevel 1 exit /b 0
echo.
echo Restore failed. The original backup was not changed.
pause
exit /b 1
