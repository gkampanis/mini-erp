"""Restore a full personal backup alongside the verified new application."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import tempfile
import zipfile

from personal_installation import inspect_database


def safe_members(archive):
    names = set()
    for entry in archive.infolist():
        path = PurePosixPath(entry.filename)
        if (path.is_absolute() or '..' in path.parts or '\\' in entry.filename
                or ':' in entry.filename or entry.filename.casefold() in names
                or (entry.external_attr >> 16) & 0o170000 == 0o120000):
            raise ValueError('Το ZIP περιέχει μη ασφαλή ή διπλή διαδρομή.')
        names.add(entry.filename.casefold())
    if sum(e.file_size for e in archive.infolist()) > 4 * 1024**3:
        raise ValueError('Το ZIP ξεπερνά το υποστηριζόμενο μέγεθος 4 GB.')


def restore(backup, destination, application, resources):
    destination = Path(destination).resolve()
    if destination.exists():
        raise FileExistsError('Ο φάκελος προορισμού υπάρχει ήδη. Διάλεξε νέο, κενό όνομα· δεν αντικαταστάθηκε τίποτα.')
    destination.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.symbolon-restore-', dir=destination.parent) as temp:
        target = Path(temp)/'installation'
        target.mkdir()
        with zipfile.ZipFile(backup) as archive:
            safe_members(archive)
            try:
                manifest = json.loads(archive.read('SymbolonERP/TRANSFER_MANIFEST.json'))
            except KeyError as exc:
                raise ValueError('Επίλεξε το προσωπικό πλήρες ZIP SymbolonERP-OLA, όχι το γενικό ZIP εφαρμογής.') from exc
            if manifest.get('format') != 'SymbolonERP-personal-full-v1':
                raise ValueError('Το ZIP δεν είναι πλήρες προσωπικό αντίγραφο Σύμβολον ERP.')
            members = {e.filename for e in archive.infolist() if not e.is_dir() and e.filename.startswith('SymbolonERP/Data/')}
            expected = {'SymbolonERP/'+p for p in manifest['files'] if p.startswith('Data/')}
            if members != expected or 'SymbolonERP/Data/mini_erp.sqlite3' not in members:
                raise ValueError('Το πλήρες αντίγραφο έχει ελλιπή δεδομένα ή αρχεία χωρίς αποτύπωμα.')
            for member in sorted(members):
                relative = member.removeprefix('SymbolonERP/')
                data = archive.read(member)
                entry = manifest['files'][relative]
                if len(data) != entry['bytes'] or hashlib.sha256(data).hexdigest() != entry['sha256']:
                    raise ValueError('Το αποτύπωμα αρχείου δεν συμφωνεί: '+relative)
                path = target/relative
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(data)
            if inspect_database(target/'Data/mini_erp.sqlite3') != manifest['database']:
                raise ValueError('Οι πίνακες της βάσης δεν συμφωνούν με το πλήρες αντίγραφο.')
        with zipfile.ZipFile(application) as archive:
            safe_members(archive)
            if not all(PurePosixPath(e.filename).parts[0] == 'MiniERP-Demo' for e in archive.infolist()):
                raise ValueError('Μη έγκυρη δομή εφαρμογής.')
            archive.extractall(target)
        for name in ('personal_installation.py','ANOIGMA_MINI_ERP.bat','EXAGOGI_OLON.bat','ODIGIES.md'):
            shutil.copy2(Path(resources)/name, target/name)
        # A current manifest makes future backups verifiable, including all data.
        files = {}
        for p in sorted(target.rglob('*')):
            if p.is_file():
                data = p.read_bytes()
                files[p.relative_to(target).as_posix()] = dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
        manifest['files'] = files
        manifest['application'] = (target/'MiniERP-Demo/app/__init__.py').read_text(encoding='utf8').strip()
        (target/'TRANSFER_MANIFEST.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf8')
        target.rename(destination)
    return destination


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--backup', type=Path)
    parser.add_argument('--destination', type=Path)
    parser.add_argument('--no-launch', action='store_true')
    parser.add_argument('--check', action='store_true')
    args=parser.parse_args()
    root=Path(__file__).resolve().parent
    if args.check:
        assert (root/'Application.zip').is_file() and (root/'resources/personal_installation.py').is_file()
        print('Restore launcher ready; no data modified.')
        return 0
    window=None
    try:
        backup=args.backup
        destination=args.destination or root/'SymbolonERP'
        if backup is None:
            import tkinter as tk
            from tkinter import filedialog, messagebox
            window=tk.Tk();window.withdraw()
            # Subsequent starts use the restored installation; never an empty DB.
            if (destination/'Data/mini_erp.sqlite3').is_file() and (destination/'personal_installation.py').is_file():
                return subprocess.call([sys.executable,str(destination/'personal_installation.py')])
            selected=filedialog.askopenfilename(parent=window,title='Επίλεξε το πλήρες προσωπικό ZIP SymbolonERP-OLA με τα δεδομένα σου',filetypes=[('Πλήρες προσωπικό αντίγραφο','*.zip')])
            if not selected:return 0
            backup=Path(selected)
        restored=restore(backup,destination,root/'Application.zip',root/'resources')
        if window is not None:
            messagebox.showinfo('Επαναφέρθηκε όλη η παραμετροποίηση','Μεταφέρθηκαν όλες οι καρτέλες, λογαριασμοί, ομάδες, κανόνες ΦΠΑ, mapping και ιστορικό.\n\nΆνοιγμα της νέας έκδοσης με αυτά τα δεδομένα.\nΟι κωδικοί ΑΑΔΕ μπορεί να χρειαστούν επανεισαγωγή.',parent=window)
        if args.no_launch:
            print(json.dumps(dict(restored=str(restored),tables=len(inspect_database(restored/'Data/mini_erp.sqlite3')['tables'])),ensure_ascii=False))
            return 0
        return subprocess.call([sys.executable,str(restored/'personal_installation.py')])
    except Exception as error:
        if window is not None:
            from tkinter import messagebox
            messagebox.showerror('Δεν ολοκληρώθηκε η επαναφορά',str(error)+'\nΤο αρχικό ZIP διατηρήθηκε.',parent=window)
        else:print(str(error),file=sys.stderr)
        return 1
    finally:
        if window is not None:window.destroy()


if __name__=='__main__':raise SystemExit(main())
