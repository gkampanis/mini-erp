@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
set "PYTHONUTF8=1"
where py >nul 2>nul
if errorlevel 1 goto python
py -3 "%~dp0personal_installation.py" %*
goto end
:python
python "%~dp0personal_installation.py" %*
:end
if not errorlevel 1 exit /b 0
echo.
echo Unable to open. Extract the complete ZIP and install Python 3.12+ with Tk.
pause
exit /b 1
