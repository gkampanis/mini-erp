@echo off
call "%~dp0ANOIGMA_MINI_ERP.bat" --export
