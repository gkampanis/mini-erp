"""Synthetic Win32 message model; no native windows or input is used."""
import ctypes
from types import SimpleNamespace
import unittest
from unittest.mock import Mock,patch
from app.infrastructure.ebs_adapter.session import WindowsSession

class NativeReadinessTests(unittest.TestCase):
    def make(self,active=202):
        user=SimpleNamespace()
        user.GetForegroundWindow=Mock(return_value=100)
        def thread(hwnd,pid):pid._obj.value=9;return 11
        user.GetWindowThreadProcessId=Mock(side_effect=thread)
        def info(tid,result):
            result._obj.hwndFocus=100;result._obj.hwndActive=100;return 1
        user.GetGUIThreadInfo=Mock(side_effect=info)
        user.GetParent=Mock(side_effect=lambda h:{201:150,202:150,150:100,100:0}.get(h,0))
        user.GetWindowTextW=Mock(return_value=0)
        def cls(hwnd,buffer,size):buffer.value='MDIClient' if hwnd==150 else 'Other';return len(buffer.value)
        user.GetClassNameW=Mock(side_effect=cls)
        def message(hwnd,msg,wp,lp,flags,ms,result):result._obj.value=active;return 1
        user.SendMessageTimeoutW=Mock(side_effect=message)
        session=WindowsSession.__new__(WindowsSession);session.pid=9;session.expected_ted=None
        session._mdi_forms=Mock(return_value={201,202});session.at_ebs=Mock(return_value=100);session.health=Mock()
        return user,session
    def test_prepare_resolves_mdi_active_child_on_other_ui_thread(self):
        user,session=self.make()
        with patch.object(ctypes,'windll',SimpleNamespace(user32=user),create=True):
            self.assertEqual(session.prepare({'save':(10,20),'new':(30,40)},202),202)
        self.assertEqual(session.expected_ted,202)
    def test_unknown_message_handle_never_becomes_a_target(self):
        user,session=self.make(active=999)
        with patch.object(ctypes,'windll',SimpleNamespace(user32=user),create=True):
            self.assertIsNone(session._active_ted())
    def test_prepare_waits_for_expected_child_activation_and_never_accepts_another(self):
        _,session=self.make()
        session._active_ted=Mock(side_effect=[201,None,202])
        with patch('app.infrastructure.ebs_adapter.session.time.sleep'):
            self.assertEqual(session.prepare({'save':(10,20),'new':(30,40)},202),202)
        self.assertEqual(session._active_ted.call_count,3)
        session._active_ted=Mock(return_value=201)
        with patch('app.infrastructure.ebs_adapter.session.time.monotonic',side_effect=[0,3]):
            with self.assertRaisesRegex(RuntimeError,'Δεν είναι ενεργό'):
                session.prepare({'save':(10,20),'new':(30,40)},202)
    def test_other_foreground_process_and_hung_mdi_do_not_select_a_child(self):
        user,session=self.make();session.pid=77
        with patch.object(ctypes,'windll',SimpleNamespace(user32=user),create=True):
            self.assertIsNone(session._active_ted());user.SendMessageTimeoutW.assert_not_called()
        user,session=self.make();user.SendMessageTimeoutW.return_value=0;user.SendMessageTimeoutW.side_effect=None
        with patch.object(ctypes,'windll',SimpleNamespace(user32=user),create=True):
            self.assertIsNone(session._active_ted())
        self.assertEqual(user.SendMessageTimeoutW.call_args.args[4:6],(2,250))
    def test_new_ted_is_explicitly_activated_before_prepare_can_fill_it(self):
        user,session=self.make(active=201);session.pg=Mock()
        state={'active':201}
        session._mdi_forms.side_effect=lambda:{201,202} if session.pg.click.called else {201}
        def message(hwnd,msg,wp,lp,flags,ms,result):
            if msg==0x0222:state['active']=wp;result._obj.value=0
            elif msg==0x0229:result._obj.value=state['active']
            return 1
        user.SendMessageTimeoutW.side_effect=message
        with patch.object(ctypes,'windll',SimpleNamespace(user32=user),create=True):
            fresh=session.open_new((30,40))
            self.assertEqual(fresh,202)
            self.assertEqual(session.prepare({'save':(10,20),'new':(30,40)},fresh),fresh)
        activation=[c.args for c in user.SendMessageTimeoutW.call_args_list if c.args[1]==0x0222]
        self.assertEqual(len(activation),1);self.assertEqual(activation[0][2],202)
        session.pg.click.assert_called_once_with(30,40)
    def test_fresh_activation_rejects_unknown_handle_and_another_process(self):
        user,session=self.make()
        with patch.object(ctypes,'windll',SimpleNamespace(user32=user),create=True):
            with self.assertRaises(RuntimeError):session._activate_fresh_ted(999)
            session.pid=77
            with self.assertRaises(RuntimeError):session._activate_fresh_ted(202)
        self.assertFalse(any(c.args[1]==0x0222 for c in user.SendMessageTimeoutW.call_args_list))
    def test_open_new_does_not_return_a_handle_recreated_during_activation(self):
        user,session=self.make(active=201);session.pg=Mock()
        state={'active':201,'new':202}
        session._mdi_forms.side_effect=lambda:{201,state['new']} if session.pg.click.called else {201}
        user.GetParent.side_effect=lambda h:150 if h in (201,202,203) else 100 if h==150 else 0
        def message(hwnd,msg,wp,lp,flags,ms,result):
            if msg==0x0222:
                # WinForms can recreate its HWND while applying layout/DPI.
                state['new']=203;state['active']=203;result._obj.value=0
            elif msg==0x0229:result._obj.value=state['active']
            return 1
        user.SendMessageTimeoutW.side_effect=message
        with patch.object(ctypes,'windll',SimpleNamespace(user32=user),create=True):
            fresh=session.open_new((30,40))
            self.assertEqual(fresh,203)
            self.assertEqual(session.prepare({'save':(10,20),'new':(30,40)},fresh),203)
        session.pg.click.assert_called_once_with(30,40)
    def test_mapping_point_on_an_old_ted_cannot_be_typed_even_in_same_ebs_process(self):
        from app.infrastructure.ebs_adapter.adapter import WindowsAdapter
        user,session=self.make();session.expected_ted=202
        user.WindowFromPoint=Mock(return_value=220)
        parent=user.GetParent.side_effect
        user.GetParent.side_effect=lambda h:201 if h==220 else parent(h)
        with patch.object(ctypes,'windll',SimpleNamespace(user32=user),create=True),patch.object(WindowsAdapter,'validate_target',return_value=(10,20)):
            with self.assertRaisesRegex(RuntimeError,'δεν ανήκει'):session.validate_target('AFM_CREDITOR',(10,20))
            user.GetParent.side_effect=lambda h:202 if h==220 else parent(h)
            self.assertEqual(session.validate_target('AFM_CREDITOR',(10,20)),(10,20))
