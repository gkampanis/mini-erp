"""Quantity documents and explicitly confirmed AADE actions, separate from EBS."""
from datetime import date, datetime
import json
import sqlite3
import threading
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import webbrowser
from app.application.delivery import DeliveryService

OPERATIONS={'SendInvoices':'Έκδοση στην ΑΑΔΕ','GetDeliveryNoteStatus':'Ενημέρωση κατάστασης',
 'CancelInvoice':'Ακύρωση δελτίου','RegisterTransfer':'Μεταφορά / μεταφόρτωση',
 'ConfirmDeliveryOutcome':'Δήλωση παράδοσης / παραλαβής','RejectDeliveryNote':'Απόρριψη παραλαβής',
 'ConfirmDeliveryReturn':'Επιβεβαίωση επιστροφής'}
ROLES={'issuer':'Εκδότης','carrier':'Μεταφορέας','recipient':'Παραλήπτης'}
LOCAL={'draft':'Πρόχειρο','imported':'Αντλήθηκε από ΑΑΔΕ','accepted':'Αποδεκτή ενέργεια',
       'error':'Η ενέργεια απορρίφθηκε','pending':'Αναμονή απάντησης','uncertain':'Αβέβαιο αποτέλεσμα — ενημέρωση κατάστασης'}
STATES={'1':'Εκδόθηκε','2':'Ακυρώθηκε','3':'Σε διακίνηση','4':'Απορρίφθηκε',
        '5':'Παραδόθηκε από μεταφορέα','7':'Αποτυχία παράδοσης','8':'Ολοκληρώθηκε','9':'Επιστροφή σε διακίνηση'}
PURPOSES={'1':'1 · Πώληση','2':'2 · Πώληση για λογαριασμό τρίτων','3':'3 · Δειγματισμός',
 '4':'4 · Έκθεση','5':'5 · Επιστροφή','6':'6 · Φύλαξη','7':'7 · Επεξεργασία / συναρμολόγηση',
 '8':'8 · Μεταξύ εγκαταστάσεων','9':'9 · Αγορά','10':'10 · Εφοδιασμός πλοίων / αεροσκαφών',
 '11':'11 · Δωρεάν διάθεση','12':'12 · Εγγύηση','13':'13 · Χρησιδανεισμός','14':'14 · Αποθήκευση σε τρίτους',
 '15':'15 · Επιστροφή από φύλαξη','16':'16 · Ανακύκλωση','17':'17 · Καταστροφή άχρηστου υλικού','18':'18 · Διακίνηση παγίων (ενδοδιακίνηση)','19':'19 · Λοιπές διακινήσεις','20':'20 · Μεταφορές - Ταχυμεταφορές'}
# Official ERP REST v2.0.2 §8.14 pp103–104 explicitly retires these
# business values although the numeric XSD range still includes them.
RETIRED_PURPOSES={'6','15','16','17','18'}
PURPOSE_CHOICES=tuple(value for code,value in PURPOSES.items() if code not in RETIRED_PURPOSES)


def text_view(parent,content):
    from app.ui.desktop import read_text
    return read_text(parent,content)


def field(parent,values,key,title,row,default='',choices=None,width=28):
    variable=tk.StringVar(parent,value=str(default if default is not None else ''));values[key]=variable
    ttk.Label(parent,text=title).grid(row=row,column=0,sticky='w',pady=5,padx=(0,14))
    widget=ttk.Combobox(parent,textvariable=variable,values=choices,state='readonly',width=width) if choices else ttk.Entry(parent,textvariable=variable,width=width)
    widget.grid(row=row,column=1,sticky='ew',pady=5);parent.columnconfigure(1,weight=1)
    return widget


class DeliveryWorkspace:
    def __init__(self,owner,parent):
        from app.ui.desktop import table
        self.owner,self.parent=owner,parent;self.rows={};self.cancel_event=None
        toolbar=ttk.Frame(parent);toolbar.pack(fill='x',pady=(0,8))
        ttk.Button(toolbar,text='+ Νέο δελτίο',style='Primary.TButton',command=self.new_draft).pack(side='left')
        ttk.Button(toolbar,text='Επεξεργασία',command=self.edit).pack(side='left',padx=6)
        ttk.Button(toolbar,text='Στοιχεία & ιστορικό',command=self.detail).pack(side='left')
        self.action_var=tk.StringVar(parent)
        self.action_box=ttk.Combobox(toolbar,textvariable=self.action_var,state='readonly',width=31)
        self.action_box.pack(side='left',padx=(14,6),fill='x',expand=True)
        ttk.Button(toolbar,text='Άνοιγμα ενέργειας',command=self.action).pack(side='left')
        filters=ttk.Frame(parent);filters.pack(fill='x',pady=(0,8))
        self.query=tk.StringVar(parent);search=ttk.Entry(filters,textvariable=self.query)
        search.pack(side='left',fill='x',expand=True);search.bind('<Return>',lambda _:self.refresh())
        ttk.Button(filters,text='Αναζήτηση',command=self.refresh).pack(side='left',padx=6)
        self.environment=tk.StringVar(parent,value='Όλα τα περιβάλλοντα')
        box=ttk.Combobox(filters,textvariable=self.environment,values=('Όλα τα περιβάλλοντα','Δοκιμαστικό','Παραγωγικό'),state='readonly',width=23)
        box.pack(side='left');box.bind('<<ComboboxSelected>>',lambda _:self.refresh())
        footer=ttk.Frame(parent);footer.pack(side='bottom',fill='x',pady=(8,0))
        self.caption=tk.StringVar(parent);ttk.Label(footer,textvariable=self.caption,style='Subtitle.TLabel').pack(side='left',fill='x',expand=True)
        self.stop_button=ttk.Button(footer,text='Διακοπή αναμονής',command=self.stop);self.stop_button.pack(side='right');self.stop_button.state(['disabled'])
        menu=ttk.Menubutton(footer,text='Εργαλεία ▾');menu.pack(side='right',padx=6)
        options=tk.Menu(menu,tearoff=False);menu['menu']=options
        options.add_command(label='Εγκατάσταση επικύρωσης XML ΑΑΔΕ',command=self.install_validation)
        options.add_command(label='Αλλαγή ρόλου επιχείρησης στο δελτίο',command=self.change_role)
        options.add_command(label='Άνοιγμα συνδέσμου QR',command=self.open_qr)
        options.add_command(label='Εξαγωγή XML πρόχειρου',command=self.export_xml)
        options.add_command(label='Εισαγωγή πλήρους XML ειδικού δελτίου',command=self.import_xml)
        options.add_command(label='Ανάκτηση MARK έκδοσης από αντλημένα ΑΑΔΕ',command=self.reconcile_issue)
        options.add_command(label='Ομαδικό QR διακίνησης',command=self.groups)
        columns=('reference','issue_date','counterpart_name','counterpart_vat','environment','local_status','aade_status','role','mark')
        self.tree=table(parent,columns,('Παραστατικό','Ημερομηνία','Συναλλασσόμενος','ΑΦΜ','Περιβάλλον','Ενέργεια / εκκρεμότητα','Κατάσταση ΑΑΔΕ','Ρόλος','MARK'),{'reference':110,'counterpart_name':220,'local_status':230,'aade_status':180,'environment':115},table_key='delivery.operations')
        self.tree.configure(selectmode='extended')
        self.tree.bind('<<TreeviewSelect>>',lambda _:self.selection_changed())
        self.tree.bind('<Double-1>',lambda _:self.detail());self.tree.bind('<Return>',lambda _:self.detail())
        from app.ui.column_filters import ColumnFilters
        self.column_filters=ColumnFilters(self.tree,self.refresh,rows=lambda:self.rows,show_summary=True)

    @property
    def service(self):return DeliveryService(self.owner.erp)

    def selected(self):
        selection=self.tree.selection()
        return self.rows.get(selection[0]) if selection else None

    def refresh(self):
        from app.ui.desktop import when
        period=self.owner._month_values.get(self.owner.month_filter.get())
        query=self.query.get().strip().casefold();environment={'Δοκιμαστικό':'test','Παραγωγικό':'production'}.get(self.environment.get())
        rows=[]
        for row in self.service.list(self.owner.company,period):
            if environment and row['environment']!=environment:continue
            if query and not any(query in str(row.get(k,'')).casefold() for k in ('reference','counterpart_vat','counterpart_name','mark')):continue
            rows.append(row)
        rows=self.column_filters.apply(rows);selected=self.tree.selection();self.rows={str(r['id']):r for r in rows}
        self.tree.delete(*self.tree.get_children())
        for n,row in enumerate(rows):
            values=dict(row,issue_date=when(row['issue_date']),environment='Δοκιμαστικό' if row['environment']=='test' else 'Παραγωγικό',role=ROLES.get(row['role'],row['role']),local_status=LOCAL.get(row['local_status'],row['local_status']),aade_status=STATES.get(row.get('aade_status'),row.get('aade_status')) or 'Χρειάζεται ενημέρωση')
            self.tree.insert('','end',iid=str(row['id']),values=[values.get(k) or '—' for k in self.tree['columns']],tags=('alternate',) if n%2 else ())
        self.tree.selection_set([s for s in selected if s in self.rows]);self.selection_changed()
        self.tree.presentation.rows_changed(self.rows);self.column_filters.sync_headings()
        self.caption.set(f'{len(rows)} δελτία · Πρόχειρα και ενέργειες της επιχείρησης · Χωρίς καταχώριση EBS')

    def selection_changed(self):
        row=self.selected();actions=self.service.allowed_actions(self.owner.company,row['id']) if row else []
        values=tuple(OPERATIONS[k] for k in actions if k in OPERATIONS);self.action_box['values']=values
        if self.action_var.get() not in values:self.action_var.set(values[0] if values else '')

    def new_draft(self):
        if self.owner.busy or self.owner.rpa_panel.running:return
        return DraftEditor(self)

    def edit(self):
        row=self.selected()
        if not row:return
        if row.get('original_xml'):
            messagebox.showinfo('Πλήρες XML','Το πρόχειρο προέρχεται από πλήρες XML. Για αλλαγές εισήγαγε νέο διορθωμένο XML· η απλή φόρμα δεν αλλάζει ειδικά πεδία του.',parent=self.owner.root)
            return self.detail()
        if row['local_status']!='draft':
            messagebox.showinfo('Διακίνηση','Το δελτίο έχει ήδη αντληθεί ή έχει ενέργεια ΑΑΔΕ. Τα στοιχεία και οι απαντήσεις του εμφανίζονται στο ιστορικό.',parent=self.owner.root);return self.detail()
        return DraftEditor(self,row)

    def detail(self):
        row=self.selected()
        if not row:return
        record=self.service.get(self.owner.company,row['id'])
        win=tk.Toplevel(self.owner.root);win.title('Διακίνηση · '+record['reference']);win.geometry('880x650')
        text_view(win,json.dumps(record,ensure_ascii=False,indent=2,default=str));return win

    def open_qr(self):
        row=self.selected()
        if row and str(row.get('qr_url','')).startswith(('https://','http://')):webbrowser.open(row['qr_url'])

    def export_xml(self):
        row=self.selected()
        if not row:return
        try:
            from app.infrastructure.aade.delivery_client import build_invoice_xml
            xml=row.get('original_xml') or build_invoice_xml(row)
        except ValueError as exc:messagebox.showerror('XML δελτίου',str(exc),parent=self.owner.root);return
        path=filedialog.asksaveasfilename(parent=self.owner.root,defaultextension='.xml',filetypes=[('XML ΑΑΔΕ','*.xml')])
        if path:
            from pathlib import Path
            Path(path).write_text(xml,encoding='utf8')

    def import_xml(self):
        if self.owner.busy or self.owner.rpa_panel.running:return
        path=filedialog.askopenfilename(parent=self.owner.root,filetypes=[('XML ΑΑΔΕ','*.xml')])
        if not path:return
        try:
            from pathlib import Path
            from app.infrastructure.aade.delivery_client import validate_xml
            from app.infrastructure.aade.delivery_read import read_xml
            with Path(path).open('rb') as source:raw=source.read(16*1024*1024+1)
            validate_xml(raw,'InvoicesDoc-v2.0.2.xsd');data=read_xml(raw)
            if data['invoice_type'] not in ('9.1','9.2','9.3','10.1','10.2'):raise ValueError('Μόνο μη αξιακά δελτία διακίνησης / ποσοτικής παραλαβής.')
            vat=self.owner.erp.db.execute('SELECT vat FROM companies WHERE id=?',(self.owner.company,)).fetchone()[0]
            if data['issuer_vat']!=vat:raise ValueError('Ο εκδότης του XML δεν είναι η επιχείρηση της εγκατάστασης.')
            if data.get('mark'):raise ValueError('Το XML έχει ήδη MARK. Χρησιμοποίησε άντληση ΑΑΔΕ αντί νέας έκδοσης.')
            data.update(role='issuer',original_xml=raw.decode('utf8'))
        except (ValueError,OSError,UnicodeError) as exc:messagebox.showerror('Εισαγωγή XML',str(exc),parent=self.owner.root);return
        win=tk.Toplevel(self.owner.root);win.title('Πρόχειρο από πλήρες XML ΑΑΔΕ');win.geometry('850x640')
        header=ttk.Frame(win,padding=16);header.pack(fill='x');values={}
        field(header,values,'environment','Περιβάλλον',0,'test',('test','production'))
        ttk.Label(header,text=f"Τύπος {data['invoice_type']} · {data['series']}/{data['number']} · {data['issue_date']} · ΑΦΜ λήπτη {data['recipient_vat']}",wraplength=760).grid(row=1,column=0,columnspan=2,pady=10)
        text_view(win,data['original_xml'])
        def save():
            data['environment']=values['environment'].get()
            try:
                # Validate monetary boundary and full identity before retaining a draft.
                from decimal import Decimal
                root=validate_xml(raw,'InvoicesDoc-v2.0.2.xsd')
                for element in root.iter():
                    name=element.tag.rsplit('}',1)[-1]
                    if (name in ('netValue','vatAmount','amount','taxAmount') or name.startswith('total')) and element.text and Decimal(element.text)!=0:raise ValueError('Το μη αξιακό δελτίο δεν μπορεί να περιέχει χρηματικές αξίες.')
                result=self.service.save_draft(self.owner.company,data)
            except (ValueError,sqlite3.Error) as exc:messagebox.showerror('Πρόχειρο XML',str(exc),parent=win);return
            win.destroy();self.owner.select_period(result['issue_date'][:7]);self.refresh()
        ttk.Button(win,text='Αποθήκευση πρόχειρου μόνο',command=save,style='Primary.TButton').pack(anchor='e',padx=16,pady=12)
        return win

    def change_role(self):
        row=self.selected()
        if not row or self.owner.busy:return
        win=tk.Toplevel(self.owner.root);win.title('Ρόλος της επιχείρησης');form=ttk.Frame(win,padding=18);form.pack(fill='both',expand=True)
        values={};field(form,values,'role','Ρόλος',0,ROLES[row['role']],tuple(ROLES.values()))
        def save():
            role=next(k for k,v in ROLES.items() if v==values['role'].get())
            try:
                result=self.service.set_role(self.owner.company,row['id'],role,confirmed=True)
                win.destroy();self.refresh()
                if str(result['id']) in self.rows:self.tree.selection_set(str(result['id']))
            except ValueError as exc:messagebox.showerror('Ρόλος',str(exc),parent=win)
        ttk.Label(form,text='Επιβεβαίωσε τον πραγματικό ρόλο της εγκατεστημένης επιχείρησης.',wraplength=400,style='Subtitle.TLabel').grid(row=1,column=0,columnspan=2,pady=10)
        ttk.Button(form,text='Επιβεβαίωση ρόλου',command=save).grid(row=2,column=1,sticky='e')

    def install_validation(self):
        if self.owner.busy or self.owner.rpa_panel.running:return
        from app.infrastructure.optional_packages import install
        self.owner.run_worker(lambda:install('delivery'),lambda _ :self.caption.set('Η επικύρωση XML ΑΑΔΕ εγκαταστάθηκε.'))

    def reconcile_issue(self):
        row=self.selected()
        if not row or self.owner.busy:return
        try:result=self.service.reconcile_issue(self.owner.company,row['id'],confirmed=True)
        except ValueError as exc:messagebox.showerror('Ανάκτηση έκδοσης',str(exc),parent=self.owner.root);return
        self.refresh();self.caption.set(result['recovery_message'])
        messagebox.showinfo('Ανάκτηση έκδοσης',result['recovery_message'],parent=self.owner.root)

    def groups(self):
        from app.ui.delivery_groups import open_groups
        return open_groups(self.owner,[self.rows[id] for id in self.tree.selection()])

    def stop(self):
        if self.cancel_event:
            self.cancel_event.set();self.caption.set('Ζητήθηκε διακοπή. Το ήδη απεσταλμένο αίτημα περιμένει απάντηση έως 30 δευτερόλεπτα.')

    def action(self,operation=None):
        row=self.selected()
        if not row or self.owner.busy or self.owner.rpa_panel.running:return
        if operation is None:operation=next((k for k,v in OPERATIONS.items() if v==self.action_var.get()),None)
        if not operation:return
        return ActionWindow(self,row,operation)

    def execute(self,row,operation,payload,window):
        from app.application.service import ERP
        self.cancel_event=threading.Event();cancel=self.cancel_event;company=self.owner.company;directory=self.owner.directory
        def work():
            erp=None
            try:
                erp=ERP(directory)
                return DeliveryService(erp).perform_action(company,row['id'],operation,payload,cancel=cancel,confirmed=True)
            except Exception as exc:return {'_error':str(exc)}
            finally:
                if erp is not None:erp.close()
        def done(result):
            self.stop_button.state(['disabled']);self.cancel_event=None;self.refresh()
            if '_error' in result:
                self.caption.set(result['_error']);messagebox.showerror('Ενέργεια διακίνησης',result['_error'],parent=self.owner.root);return
            if str(result['id']) in self.rows:self.tree.selection_set(str(result['id']))
            actions=result.get('actions',[]);last=actions[-1] if actions else {};response=json.loads(last.get('response_json') or '{}')
            errors=response.get('errors') or []
            if result['local_status'] in ('error','uncertain'):
                reason='\n'.join(str(e.get('message') or e) for e in errors)
                self.caption.set(LOCAL.get(result['local_status'],'')+' · '+reason)
                messagebox.showwarning('Απάντηση ΑΑΔΕ',reason or LOCAL.get(result['local_status'],''),parent=self.owner.root)
            else:self.caption.set('Η απάντηση ΑΑΔΕ αποθηκεύτηκε στο ιστορικό. '+STATES.get(result.get('aade_status'),'Κάνε ενημέρωση κατάστασης για την τρέχουσα διακίνηση.'))
        if self.owner.run_worker(work,done):
            self.stop_button.state(['!disabled']);window.destroy();self.caption.set('Αναμονή απάντησης ΑΑΔΕ…')


class DraftEditor(tk.Toplevel):
    def __init__(self,workspace,row=None):
        super().__init__(workspace.owner.root);self.workspace=workspace;self.original=row;self.values={};self.lines=[dict(x) for x in (row or {}).get('lines',[])]
        self.title('Πρόχειρο δελτίο αποστολής · 9.3');self.geometry('860x690');self.minsize(760,590)
        row=row or {};company=workspace.owner.erp.db.execute('SELECT vat FROM companies WHERE id=?',(workspace.owner.company,)).fetchone()
        self.issuer=company['vat'];tabs=ttk.Notebook(self);tabs.pack(fill='both',expand=True,padx=16,pady=12)
        header=ttk.Frame(tabs,padding=16);addresses=ttk.Frame(tabs,padding=16);items=ttk.Frame(tabs,padding=16)
        tabs.add(header,text='Στοιχεία δελτίου');tabs.add(addresses,text='Φόρτωση & παράδοση');tabs.add(items,text='Είδη & ποσότητες')
        fields=[('environment','Περιβάλλον',row.get('environment','test'),('test','production')),
          ('series','Σειρά',row.get('series','ΔΑ'),None),('number','Αριθμός (κενό: επόμενος)',row.get('number',''),None),
          ('issue_date','Ημερομηνία έκδοσης',row.get('issue_date',date.today().isoformat()),None),
          ('counterpart_vat','ΑΦΜ παραλήπτη',row.get('counterpart_vat',''),None),
          ('counterpart_name','Επωνυμία παραλήπτη',row.get('counterpart_name',''),None),
          ('dispatch_date','Ημερομηνία διακίνησης',row.get('dispatch_date',date.today().isoformat()),None),
          ('dispatch_time','Ώρα διακίνησης',row.get('dispatch_time',datetime.now().strftime('%H:%M:%S')),None),
          ('vehicle_number','Αριθμός οχήματος',row.get('vehicle_number',''),None),
          ('movement_purpose','Σκοπός διακίνησης',PURPOSES.get(str(row.get('movement_purpose',1)),PURPOSES['1']),PURPOSE_CHOICES),
          ('other_movement_purpose','Περιγραφή λοιπής διακίνησης (σκοπός 19)',row.get('other_movement_purpose',''),None),
          ('correlated_marks','Συσχετιζόμενα MARK (κόμμα)',', '.join(row.get('correlated_marks',[])),None)]
        for n,(key,title,value,choices) in enumerate(fields):field(header,self.values,key,title,n,value,choices)
        for n,(key,title) in enumerate((('loading_address','Διεύθυνση φόρτωσης'),('delivery_address','Διεύθυνση παράδοσης'))):
            form=ttk.LabelFrame(addresses,text=title,padding=12);form.pack(fill='x',pady=6)
            for index,(name,label) in enumerate((('street','Οδός'),('number','Αριθμός'),('postal_code','Τ.Κ.'),('city','Πόλη'))):field(form,self.values,key+'.'+name,label,index,row.get(key,{}).get(name,''))
        tools=ttk.Frame(items);tools.pack(fill='x')
        ttk.Button(tools,text='+ Προσθήκη είδους',command=self.add_line).pack(side='left')
        ttk.Button(tools,text='Επεξεργασία',command=self.edit_line).pack(side='left',padx=6)
        ttk.Button(tools,text='Αφαίρεση',command=self.remove_line).pack(side='left')
        from app.ui.desktop import table
        self.line_tree=table(items,('description','quantity','measurement_unit','item_code'),('Περιγραφή','Ποσότητα','Μονάδα ΑΑΔΕ','Κωδικός'),{'description':350},height=8)
        self.line_tree.bind('<Double-1>',lambda _:self.edit_line());self.draw_lines()
        footer=ttk.Frame(self,padding=16);footer.pack(fill='x')
        ttk.Label(footer,text='Αποθήκευση πρόχειρου μόνο. Η έκδοση στην ΑΑΔΕ γίνεται με χωριστή επιβεβαίωση.',style='Subtitle.TLabel').pack(side='left')
        ttk.Button(footer,text='Αποθήκευση πρόχειρου',style='Primary.TButton',command=self.save).pack(side='right')

    def draw_lines(self):
        self.line_tree.delete(*self.line_tree.get_children())
        for n,row in enumerate(self.lines):self.line_tree.insert('','end',iid=str(n),values=[row.get(k,'') for k in self.line_tree['columns']])

    def add_line(self,index=None):
        win=tk.Toplevel(self);win.title('Είδος διακίνησης');form=ttk.Frame(win,padding=16);form.pack(fill='both',expand=True)
        values={};row=self.lines[index] if index is not None else {}
        for n,(key,title,default) in enumerate((('description','Περιγραφή',''),('quantity','Ποσότητα','1'),('measurement_unit','Μονάδα: 1 τεμ. · 2 κιλά · 3 λίτρα','1'),('item_code','Κωδικός είδους',''))):field(form,values,key,title,n,row.get(key,default))
        def save():
            from decimal import Decimal,InvalidOperation
            data={k:v.get().strip() for k,v in values.items()}
            try:
                q=Decimal(data['quantity'].replace(',','.'));unit=int(data['measurement_unit'])
                if not q.is_finite() or q<=0 or not data['description'] or unit not in (1,2,3,4,5,6,7):raise ValueError()
            except (ValueError,InvalidOperation):messagebox.showerror('Είδος','Συμπλήρωσε περιγραφή, θετική ποσότητα και έγκυρη μονάδα ΑΑΔΕ.',parent=win);return
            data.update(quantity=str(q),measurement_unit=unit)
            if index is None:self.lines.append(data)
            else:self.lines[index]=data
            self.draw_lines();win.destroy()
        ttk.Button(form,text='Αποθήκευση είδους',command=save).grid(row=4,column=1,sticky='e',pady=12)

    def edit_line(self):
        if self.line_tree.selection():self.add_line(int(self.line_tree.selection()[0]))

    def remove_line(self):
        if self.line_tree.selection():del self.lines[int(self.line_tree.selection()[0])];self.draw_lines()

    def save(self):
        data={k:v.get().strip() for k,v in self.values.items() if '.' not in k}
        data.update(issuer_vat=self.issuer,recipient_vat=data['counterpart_vat'],role='issuer',lines=[dict(x) for x in self.lines])
        data['movement_purpose']=int(next(k for k,v in PURPOSES.items() if v==data['movement_purpose']))
        if str(data['movement_purpose']) in RETIRED_PURPOSES:
            messagebox.showerror('Σκοπός διακίνησης','Η ΑΑΔΕ δεν επιτρέπει πλέον αυτόν τον σκοπό. Επίλεξε ισχύοντα σκοπό διακίνησης.',parent=self);return None
        if data['movement_purpose']==19 and not data.get('other_movement_purpose'):
            messagebox.showerror('Σκοπός διακίνησης','Συμπλήρωσε περιγραφή για τη λοιπή διακίνηση (σκοπός 19).',parent=self);return None
        data['correlated_marks']=[x.strip() for x in data['correlated_marks'].split(',') if x.strip()]
        for key in ('loading_address','delivery_address'):data[key]={field:self.values[key+'.'+field].get().strip() for field in ('street','number','postal_code','city')}
        try:result=self.workspace.service.save_draft(self.workspace.owner.company,data,self.original['id'] if self.original else None)
        except (ValueError,sqlite3.Error) as exc:
            messagebox.showerror('Πρόχειρο δελτίο',str(exc),parent=self);return None
        self.workspace.owner.select_period(result['issue_date'][:7])
        self.workspace.refresh();self.destroy();return result


class ActionWindow(tk.Toplevel):
    def __init__(self,workspace,row,operation):
        super().__init__(workspace.owner.root);self.workspace,self.row,self.operation=workspace,row,operation;self.values={};self.payload=None
        self.title(OPERATIONS[operation]+' · '+row['reference']);self.geometry('840x700');self.minsize(700,580)
        caption=f"{row['reference']} · MARK {row.get('mark') or '—'} · {'ΠΑΡΑΓΩΓΙΚΟ' if row['environment']=='production' else 'ΔΟΚΙΜΑΣΤΙΚΟ'} · {ROLES[row['role']]}"
        ttk.Label(self,text=caption,style='Section.TLabel',padding=16).pack(anchor='w')
        form=ttk.Frame(self,padding=(16,0));form.pack(fill='x')
        if operation in ('RegisterTransfer','ConfirmDeliveryOutcome','ConfirmDeliveryReturn'):field(form,self.values,'qrUrl','Σύνδεσμος QR δελτίου',0,row.get('qr_url',''))
        if operation=='RegisterTransfer':
            company=workspace.owner.erp.db.execute('SELECT vat FROM companies WHERE id=?',(workspace.owner.company,)).fetchone()
            for n,(key,title,default,choices) in enumerate((('vehicleNumber','Αριθμός οχήματος',row.get('vehicle_number',''),None),('transportType','Μεταφορά: 1 ΦΔΧ · 2 ΦΙΧ · 3 πλοίο · 4 τρένο · 5 αεροσκάφος · 6 άλλη · 7 χωρίς','2',tuple(str(i) for i in range(1,8))),('carrierVatNumber','ΑΦΜ μεταφορέα',company['vat'],None),('timeStamp','Ημερομηνία / ώρα (ISO)',datetime.now().isoformat(timespec='seconds'),None),('pNumber','Πινακίδα Ρ επικαθήμενου / ρυμουλκούμενου (προαιρετικό)','',None)),1):field(form,self.values,key,title,n,default,choices)
        if operation=='ConfirmDeliveryOutcome':
            choices=('FULL',) if row['role']=='recipient' else ('FULL','PARTIAL','NONE')
            field(form,self.values,'outcome','Αποτέλεσμα: FULL πλήρης · PARTIAL μερική · NONE αποτυχία',1,'FULL',choices)
            field(form,self.values,'deliveredWithoutRecipient','Χωρίς φυσική παρουσία λήπτη',2,'false',('false','true'))
        if operation in ('RegisterTransfer','ConfirmDeliveryOutcome'):
            field(form,self.values,'packagingType','Συσκευασία (προαιρετικό): 1 παλέτα · 2 κούτα · 3 κιβώτιο · 4 βαρέλι · 5 σακούλα · 6 άλλη',6,'',tuple(['']+[str(i) for i in range(1,7)]))
            field(form,self.values,'package_quantity','Πλήθος συσκευασιών (ακέραιο)',7,'')
            field(form,self.values,'otherPackagingTypeTitle','Περιγραφή άλλης συσκευασίας',8,'')
        if operation=='RejectDeliveryNote':field(form,self.values,'rejectionReason','Αιτία απόρριψης (προαιρετικό)',0,'')
        actions=ttk.Frame(self,padding=16);actions.pack(side='bottom',fill='x')
        ttk.Button(actions,text='Προεπισκόπηση αιτήματος',command=self.preview).pack(side='left')
        self.send=ttk.Button(actions,text='Επιβεβαιώνω αποστολή στην ΑΑΔΕ',style='Primary.TButton',command=self.submit);self.send.pack(side='right');self.send.state(['disabled'])
        self.preview_host=ttk.Frame(self);self.preview_host.pack(fill='both',expand=True,padx=16,pady=8)
        self.preview_text=text_view(self.preview_host,'Έλεγξε τα στοιχεία και πάτησε «Προεπισκόπηση αιτήματος». Δεν έχει γίνει επικοινωνία με την ΑΑΔΕ.')
        for value in self.values.values():value.trace_add('write',lambda *_:self.send.state(['disabled']))
        if operation in ('SendInvoices','GetDeliveryNoteStatus','CancelInvoice'):self.preview()

    def build_payload(self):
        values={k:v.get().strip() for k,v in self.values.items()};operation=self.operation;payload={}
        if values.get('qrUrl'):payload['qrUrl']=values['qrUrl']
        if operation=='RegisterTransfer':payload['transportDetail']={k:(int(values[k]) if k=='transportType' else values[k]) for k in ('vehicleNumber','transportType','carrierVatNumber','timeStamp','pNumber') if values.get(k)}
        if operation=='ConfirmDeliveryOutcome':payload.update(outcome=values['outcome'],deliveredWithoutRecipient=values['deliveredWithoutRecipient']=='true')
        if values.get('packagingType'):
            item=dict(packagingType=int(values['packagingType']),quantity=int(values['package_quantity']))
            if values.get('otherPackagingTypeTitle'):item['otherPackagingTypeTitle']=values['otherPackagingTypeTitle']
            if operation=='RegisterTransfer':payload['transportDetail']['packingsDeclaration']=[item]
            else:payload['deliveredPackaging']=[item]
        if operation=='RejectDeliveryNote' and values.get('rejectionReason'):payload['rejectionReason']=values['rejectionReason']
        return payload

    def preview(self):
        try:
            payload=self.build_payload();preview=self.workspace.service.prepare_action(self.workspace.owner.company,self.row['id'],self.operation,payload)
            request=preview['request'];body=request.get('body') or ''
            if isinstance(body,bytes):body=body.decode('utf8')
            content=request['method']+' '+request['path']+'\n\n'+body
        except (ValueError,KeyError) as exc:
            self.send.state(['disabled']);content='Χρειάζεται διόρθωση πριν την αποστολή:\n'+str(exc)
        else:self.payload=payload;self.send.state(['!disabled'])
        self.preview_text.configure(state='normal');self.preview_text.delete('1.0','end');self.preview_text.insert('end',content);self.preview_text.configure(state='disabled')

    def submit(self):
        if self.send.instate(['disabled']) or self.workspace.owner.busy:return
        self.workspace.execute(self.row,self.operation,self.payload,self)
