"""Small group QR workspace; all network work runs through desktop worker."""
import json
import threading
import tkinter as tk
from tkinter import ttk,messagebox
import webbrowser
from app.application.delivery_groups import DeliveryGroupsService


def open_groups(owner,records):
    if owner.busy or owner.rpa_panel.running:return None
    return DeliveryGroupsWindow(owner,records)


class DeliveryGroupsWindow:
    def __init__(self,owner,records):
        self.owner=owner;self.document_ids=[r['id'] for r in records]
        self.running=False;self.cancel=None;self.rows={}
        self.win=tk.Toplevel(owner.root);self.win.title('Διακίνηση · Ομαδικά QR');self.win.geometry('940x690');self.win.minsize(720,520)
        self.win.protocol('WM_DELETE_WINDOW',self.close)
        outer=ttk.Frame(self.win,padding=14);outer.pack(fill='both',expand=True)
        ttk.Label(outer,text='Ομαδικά QR ΑΑΔΕ',style='Title.TLabel').pack(anchor='w')
        self.status=tk.StringVar(self.win,value=f'{len(self.document_ids)} επιλεγμένα δελτία · Η δημιουργία αφορά το ίδιο περιβάλλον ΑΑΔΕ.')
        ttk.Label(outer,textvariable=self.status,style='Subtitle.TLabel',wraplength=860).pack(anchor='w',pady=(4,10))
        bar=ttk.Frame(outer);bar.pack(fill='x')
        self.generate=ttk.Button(bar,text='Προεπισκόπηση & δημιουργία',command=self.generate_group,style='Primary.TButton');self.generate.pack(side='left')
        self.stop=ttk.Button(bar,text='Διακοπή αναμονής',command=self.stop_wait);self.stop.pack(side='right');self.stop.state(['disabled'])
        if len(self.document_ids)<2:self.generate.state(['disabled'])
        self.tree=ttk.Treeview(outer,columns=('id','environment','status','expires'),show='headings',height=7,selectmode='browse')
        for key,title,width in (('id','Ομάδα',70),('environment','Περιβάλλον',130),('status','Αποτέλεσμα',170),('expires','Λήξη ΑΑΔΕ',230)):
            self.tree.heading(key,text=title);self.tree.column(key,width=width)
        self.tree.pack(fill='x',pady=(12,8));self.tree.bind('<<TreeviewSelect>>',lambda _:self.selection())
        form=ttk.Frame(outer);form.pack(fill='x')
        ttk.Label(form,text='Group ID ΑΑΔΕ').pack(side='left')
        self.remote=tk.StringVar(self.win);ttk.Entry(form,textvariable=self.remote).pack(side='left',fill='x',expand=True,padx=8)
        self.lookup=ttk.Button(form,text='Προεπισκόπηση & λήψη στοιχείων',command=self.lookup_group);self.lookup.pack(side='right')
        ttk.Label(outer,text='Η δημιουργία μπορεί να επιστρέψει μόνο σύνδεσμο QR. Το Group ID συμπληρώνεται όταν παρέχεται από την ΑΑΔΕ.',style='Subtitle.TLabel',wraplength=860).pack(anchor='w',pady=6)
        actions=ttk.Frame(outer);actions.pack(fill='x',pady=(0,8))
        ttk.Button(actions,text='Αντιγραφή συνδέσμου QR',command=self.copy_qr).pack(side='left')
        ttk.Button(actions,text='Άνοιγμα QR',command=self.open_qr).pack(side='left',padx=6)
        from app.ui.desktop import read_text
        self.text=read_text(outer,'Επίλεξε ομάδα για στοιχεία και ιστορικό ενεργειών.')
        self.refresh()

    @property
    def service(self):return DeliveryGroupsService(self.owner.erp)

    def selected(self):
        selection=self.tree.selection();return self.rows.get(selection[0]) if selection else None

    def refresh(self,select=None):
        selected=str(select) if select is not None else (self.tree.selection()[0] if self.tree.selection() else None)
        self.rows={str(g['id']):g for g in self.service.list(self.owner.company)}
        self.tree.delete(*self.tree.get_children())
        labels={'pending':'Αναμονή','accepted':'Αποδεκτή ενέργεια','uncertain':'Αβέβαιο αποτέλεσμα','error':'Σφάλμα','cancelled':'Διακόπηκε'}
        for key,group in self.rows.items():self.tree.insert('','end',iid=key,values=(key,'Παραγωγικό' if group['environment']=='production' else 'Δοκιμαστικό',labels.get(group['status'],group['status']),group['expires_at'] or 'Δεν δόθηκε'))
        if selected in self.rows:self.tree.selection_set(selected)
        self.selection()

    def selection(self):
        group=self.selected()
        if not group:return
        self.remote.set(group['remote_group_id'])
        self.text.configure(state='normal');self.text.delete('1.0','end');self.text.insert('1.0',json.dumps(group,ensure_ascii=False,indent=2,default=str));self.text.configure(state='disabled')

    def preview(self,prepared,execute):
        win=tk.Toplevel(self.win);win.title('Προεπισκόπηση αιτήματος ΑΑΔΕ');win.geometry('780x540')
        environment='ΠΑΡΑΓΩΓΙΚΟ' if prepared['environment']=='production' else 'ΔΟΚΙΜΑΣΤΙΚΟ'
        ttk.Label(win,text=environment+' · '+prepared['operation'],padding=12).pack(anchor='w')
        request=prepared['request'];body=request.get('body')
        content=body.decode('utf8') if isinstance(body,bytes) else request['path']
        from app.ui.desktop import read_text
        read_text(win,content)
        def confirm():
            if not messagebox.askyesno('Αποστολή στην ΑΑΔΕ',f'Να εκτελεστεί η ενέργεια στο {environment} περιβάλλον;',parent=win):return
            win.destroy();execute()
        ttk.Button(win,text='Επιβεβαίωση & εκτέλεση',command=confirm,style='Primary.TButton').pack(anchor='e',padx=12,pady=12)

    def generate_group(self):
        if self.running or self.owner.busy:return
        try:prepared=self.service.prepare_generate(self.owner.company,self.document_ids)
        except (ValueError,RuntimeError) as exc:messagebox.showerror('Ομαδικό QR',str(exc),parent=self.win);return
        self.preview(prepared,lambda:self.execute('generate',self.document_ids))

    def lookup_group(self):
        group=self.selected()
        if not group or self.running or self.owner.busy:return
        remote=self.remote.get().strip()
        try:prepared=self.service.prepare_details(self.owner.company,group['id'],remote)
        except ValueError as exc:messagebox.showerror('Στοιχεία ομάδας',str(exc),parent=self.win);return
        self.preview(prepared,lambda:self.execute('lookup',group['id'],remote))

    def execute(self,operation,value,remote=None):
        if self.running or self.owner.busy:return
        self.running=True;self.cancel=threading.Event();cancel=self.cancel
        self.generate.state(['disabled']);self.lookup.state(['disabled']);self.stop.state(['!disabled'])
        directory=self.owner.directory;company=self.owner.company
        self.status.set('Αναμονή ΑΑΔΕ — χωρίς αυτόματη επανάληψη αποστολής.')
        def work():
            from app.application.service import ERP
            erp=ERP(directory)
            try:
                service=DeliveryGroupsService(erp)
                return service.generate(company,value,client=None,cancel=cancel,confirmed=True) if operation=='generate' else service.refresh_details(company,value,remote,client=None,cancel=cancel,confirmed=True)
            finally:erp.close()
        def finished(result):
            self.running=False;self.stop.state(['disabled']);self.lookup.state(['!disabled'])
            if len(self.document_ids)>=2:self.generate.state(['!disabled'])
            self.refresh(result['id'] if result else None)
            if result:
                last=result['actions'][-1] if result['actions'] else {};response=json.loads(last.get('response_json') or '{}')
                errors=response.get('errors') or [];self.status.set(' · '.join(str(e.get('message','')) for e in errors) if errors else 'Η ενέργεια ολοκληρώθηκε. Τα στοιχεία και η απάντηση διατηρήθηκαν στο ιστορικό.')
            else:self.status.set('Διακόπηκε πριν από αποστολή.')
        # Desktop worker routes exceptions centrally. Always return a local
        # failure value so this child window also restores its controls.
        def guarded():
            try:return work()
            except Exception as exc:return {'_error':str(exc)}
        def done(result):
            if isinstance(result,dict) and '_error' in result:
                finished(None);self.status.set(result['_error']);return
            finished(result)
        self.owner.run_worker(guarded,done)

    def stop_wait(self):
        if self.cancel:self.cancel.set();self.status.set('Ζητήθηκε διακοπή. Το ήδη απεσταλμένο αίτημα περιμένει απάντηση έως 30 δευτερόλεπτα.')

    def close(self):
        if self.running:self.stop_wait();return
        self.win.destroy()

    def copy_qr(self):
        group=self.selected()
        if group and group['group_qr_url']:self.win.clipboard_clear();self.win.clipboard_append(group['group_qr_url'])

    def open_qr(self):
        group=self.selected();url=group.get('group_qr_url','') if group else ''
        if url.startswith(('https://','http://')):webbrowser.open(url)
