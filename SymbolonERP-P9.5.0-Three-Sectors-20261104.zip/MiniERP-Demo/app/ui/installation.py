"""First-start choices; never choose a different business silently."""
import tkinter as tk
from tkinter import ttk,messagebox


def choose_legacy(source,parent=None):
    owned=parent is None
    root=tk.Tk() if owned else parent
    if owned:root.withdraw()
    try:
        answer=messagebox.askyesnocancel('Δεδομένα εγκατάστασης',
            'Βρέθηκαν τα υπάρχοντα δεδομένα σου:\n'+str(source)+'\n\n'
            'Θέλεις να αντιγραφούν ΟΛΑ σε αυτή την εγκατάσταση;\n'
            'Ναι: αντιγραφή καρτελών, λογαριασμών, παραστατικών και ρυθμίσεων.\n'
            'Όχι: νέα, ανεξάρτητη επιχείρηση.\n'
            'Ακύρωση: έξοδος χωρίς αλλαγή δεδομένων.\n\n'
            'Κλείσε πρώτα άλλες εκτελέσεις της εφαρμογής. Το αρχικό αντίγραφο διατηρείται. '
            'Οι κωδικοί ΑΑΔΕ μπορεί να χρειαστούν εκ νέου εισαγωγή.',parent=root)
        return None if answer is None else 'copy' if answer else 'new'
    finally:
        if owned:root.destroy()


def choose_company(parent,rows):
    win=tk.Toplevel(parent);win.title('Επιχείρηση εγκατάστασης');win.transient(parent)
    frame=ttk.Frame(win,padding=20);frame.pack(fill='both',expand=True)
    ttk.Label(frame,text='Η παλιά βάση περιέχει περισσότερες επιχειρήσεις.',style='Section.TLabel').pack(anchor='w')
    ttk.Label(frame,text='Επίλεξε τη μία επιχείρηση αυτής της εγκατάστασης.\nΤα δεδομένα των υπόλοιπων δεν διαγράφονται.',wraplength=560).pack(anchor='w',pady=(8,12))
    selected=tk.IntVar(value=0);result=[]
    for row in rows:
        ttk.Radiobutton(frame,text=row['name']+' · ΑΦΜ '+row['vat'],variable=selected,value=row['id']).pack(anchor='w',pady=4)
    buttons=ttk.Frame(frame);buttons.pack(fill='x',pady=(15,0))
    def accept():
        if selected.get() in {r['id'] for r in rows}:result.append(selected.get());win.destroy()
    confirm=ttk.Button(buttons,text='Χρήση αυτής της επιχείρησης',style='Primary.TButton',command=accept,state='disabled');confirm.pack(side='right')
    selected.trace_add('write',lambda *_:confirm.configure(state='normal' if selected.get() else 'disabled'))
    ttk.Button(buttons,text='Ακύρωση',command=win.destroy).pack(side='left')
    win.protocol('WM_DELETE_WINDOW',win.destroy);win.grab_set();parent.wait_window(win)
    return result[0] if result else None
