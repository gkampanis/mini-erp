"""Three-sector presentation over the existing notebook and callbacks."""
from tkinter import ttk
from pathlib import Path
import tkinter as tk


class SectorNavigation:
    def __init__(self,owner,parent):
        self.owner=owner;self.current='expenses';self.compact=None;self.buttons={};self.images={}
        self.frame=ttk.Frame(parent,style='Navigation.TFrame',padding=(12,18))
        self.brand=ttk.Frame(self.frame,style='Navigation.TFrame')
        from app.ui.branding import install
        install(owner.root,self.brand,title_style='Brand.TLabel')
        for child in self.brand.winfo_children():
            child.configure(style='Navigation.TFrame')
            for label in child.winfo_children():
                if 'image' in label.keys() and label.cget('image'):label.configure(style='NavigationCaption.TLabel')
        self.caption=ttk.Label(self.frame,text='ΧΩΡΟΣ ΕΡΓΑΣΙΑΣ',style='NavigationCaption.TLabel')
        self.caption.pack(anchor='w',pady=(8,12))
        self.items=ttk.Frame(self.frame,style='Navigation.TFrame')
        for key,title in (('expenses','Έξοδα'),('income','Έσοδα'),('movement','Διακίνηση')):
            button=ttk.Button(self.items,text=title,style='Navigation.TButton',command=lambda k=key:self.choose(k),compound='left')
            button.pack(fill='x',pady=3);self.buttons[key]=button
        self.utilities=ttk.Frame(self.frame,style='Navigation.TFrame')
        self.cards=ttk.Button(self.utilities,text='Καρτέλες',style='Navigation.TButton',command=lambda:self.open_tab(owner.creditors_tab))
        self.settings=ttk.Button(self.utilities,text='Ρυθμίσεις',style='Navigation.TButton',command=owner.open_settings)
        self.subtabs=ttk.Frame(owner.workspace_card,padding=(8,0,8,4),style='Card.TFrame')
        self.tab_buttons={}
        for tab in owner.notebook.tabs():
            text=owner.notebook.tab(tab,'text')
            text={'Μη καταχωρισμένα στο EBS':'Μη καταχωρισμένα','Έλεγχοι εισαγωγής':'Έλεγχοι'}.get(text,text)
            self.tab_buttons[tab]=ttk.Button(self.subtabs,text=text,style='Subtab.TButton',command=lambda t=tab:owner.notebook.select(t))
        owner.notebook.configure(style='Workspace.TNotebook')
        self.refresh_icons(owner.ui_preferences.theme)
        owner.root.bind('<Configure>',self._resize,add='+')
        owner.notebook.bind('<<NotebookTabChanged>>',lambda _:self.sync(),add='+')
        self._layout(owner.root.winfo_width()<1180)
        self.choose('expenses')

    def _resize(self,event):
        if event.widget is self.owner.root:self._layout(event.width<1180)

    def refresh_icons(self,mode):
        directory=Path(__file__).resolve().parents[2]/'docs/branding/navigation'
        for key,button in self.buttons.items():
            path=directory/(key+('-dark' if mode=='dark' else '')+'.png')
            try:
                self.images[key]=tk.PhotoImage(master=self.owner.root,file=str(path))
                button.configure(image=self.images[key])
            except (tk.TclError,OSError):button.configure(image='')

    def _layout(self,compact):
        if self.compact==compact:return
        self.compact=compact;self.frame.pack_forget()
        for widget in (self.brand,self.caption,self.items,self.utilities):widget.pack_forget()
        if compact:
            self.frame.configure(padding=(10,2))
            self.frame.pack(side='top',fill='x',before=self.owner.main_frame)
            self.utilities.pack(side='right')
            self.items.pack(side='left')
        else:
            self.frame.configure(padding=(12,18))
            self.frame.pack(side='left',fill='y',before=self.owner.main_frame)
            self.brand.pack(anchor='w',pady=(0,25))
            self.caption.pack(anchor='w',pady=(0,12))
            self.utilities.pack(side='bottom',fill='x')
            self.items.pack(fill='x')
        for button in (*self.buttons.values(),self.cards,self.settings):
            button.pack_forget()
            button.pack(side='left' if compact else 'top',fill=None if compact else 'x',padx=2 if compact else 0,pady=2 if compact else 4)
        self._selection_styles()

    def _selection_styles(self):
        prefix='CompactNavigation' if self.compact else 'Navigation'
        for key,button in self.buttons.items():button.configure(style=prefix+('Selected' if key==self.current else '')+'.TButton')
        for button in (self.cards,self.settings):button.configure(style=prefix+'.TButton')

    def _refresh_tabs(self):
        current=self.owner.notebook.select();visible={str(t) for t in self.tabs(self.current)}
        for tab,button in self.tab_buttons.items():
            button.pack_forget()
            if tab in visible:
                button.configure(style='SubtabSelected.TButton' if tab==current else 'Subtab.TButton')
                button.pack(side='left',padx=(0,12))
        self.subtabs.pack_forget()
        if len(visible)>1:self.subtabs.pack(fill='x',before=self.owner.notebook)

    def tabs(self,key):
        owner=self.owner
        if key in ('income','movement'):return (owner.document_views[key].parent,)
        return (owner.documents_tab,owner.document_views['expenses'].parent,owner.document_views['purchases'].parent,owner.reviews_tab,owner.suppliers_tab,owner.creditors_tab,owner.reconciliation_tab)

    def choose(self,key,select=True):
        if key not in self.buttons:return
        self.current=key;book=self.owner.notebook
        visible={str(tab) for tab in self.tabs(key)}
        # add() restores hidden tabs at their original index, retaining widgets/state.
        for tab in book.tabs():
            if tab in visible:book.add(tab)
        if select:book.select(self.tabs(key)[0])
        for tab in book.tabs():
            if tab not in visible:book.hide(tab)
        self.owner.sector_title.set({'expenses':'Έξοδα','income':'Έσοδα','movement':'Διακίνηση'}[key])
        self._selection_styles();self._refresh_tabs()

    def open_tab(self,tab):
        self.choose('expenses',select=False);self.owner.notebook.select(tab)

    def sync(self):
        selected=self.owner.notebook.select()
        if not selected:return
        key=next((k for k in self.buttons if selected in {str(t) for t in self.tabs(k)}),'expenses')
        if key!=self.current:self.choose(key,select=False)
        else:self._refresh_tabs()
