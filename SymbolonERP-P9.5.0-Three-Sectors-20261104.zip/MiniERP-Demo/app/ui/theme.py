"""Coordinated compact ttk appearance; presentation only, no external runtime."""
import sys
from pathlib import Path
import tkinter as tk
from tkinter import ttk,font

PALETTES={
 'dark':dict(bg='#1c1b23',panel='#25232e',ink='#ece9f4',muted='#bcb5ca',blue='#bba1ef',button='#33303f',border='#736a85',selected='#493763',selected_ink='#ffffff',alternate='#2b2835',hover='#453d55',primary_ink='#241832',warning='#f1c685',warning_bg='#4b3c22',success='#8cddbd'),
 'light':dict(bg='#f5f5f7',panel='#ffffff',ink='#292737',muted='#6f6a7b',blue='#8265c9',button='#efeff1',border='#e9e6ef',selected='#eee9f8',selected_ink='#4f2d86',alternate='#fcfbfd',hover='#f4f0fb',primary_ink='#ffffff',warning='#88550e',warning_bg='#fff0cc',success='#176448')}
BG=PALETTES['dark']['bg'];WHITE=PALETTES['dark']['panel'];INK=PALETTES['dark']['ink'];MUTED=PALETTES['dark']['muted']

def palette(mode='dark'):return PALETTES.get(mode,PALETTES['dark'])

def colors(widget):
    while widget is not None:
        if hasattr(widget,'_desktop_owner'):return palette(widget._desktop_owner.ui_preferences.theme)
        widget=getattr(widget,'master',None)
    return palette()


def workspace_surfaces(widget):
    """White/panel workspace card, retaining explicit semantic widget styles."""
    for child in widget.winfo_children():
        if isinstance(child,ttk.Frame) and not child.cget('style'):child.configure(style='Card.TFrame')
        elif isinstance(child,ttk.Label):
            if not child.cget('style'):child.configure(style='Card.TLabel')
            elif child.cget('style')=='Subtitle.TLabel':child.configure(style='CardSubtitle.TLabel')
        workspace_surfaces(child)


class WorkspaceSurface(tk.Frame):
    """Rounded card drawn by Tk; its content uses ordinary stable frame geometry."""
    def __init__(self,parent,**kwargs):
        c=colors(parent)
        super().__init__(parent,highlightthickness=0,borderwidth=0,background=c['bg'],**kwargs)
        self.surface=tk.Canvas(self,highlightthickness=0,borderwidth=0,background=c['bg'])
        self.surface.place(x=0,y=0,relwidth=1,relheight=1)
        self.content=ttk.Frame(self,style='Card.TFrame')
        self.content.pack(fill='both',expand=True,padx=10,pady=10)
        self.bind('<Configure>',self.redraw)

    def redraw(self,event=None):
        c=colors(self);width=self.winfo_width();height=self.winfo_height();radius=16
        self.surface.delete('surface')
        self.surface.create_polygon(radius,0,width-radius,0,width,0,width,radius,width,height-radius,width,height,width-radius,height,radius,height,0,height,0,height-radius,0,radius,0,0,fill=c['panel'],outline='',smooth=True,splinesteps=24,tags='surface')


def rounded_controls(root,style,mode):
    """Local nine-slice images keep ttk keyboard/state behavior and no runtime dependency."""
    owner=root._root()
    if not hasattr(owner,'_symbolon_surfaces'):owner._symbolon_surfaces={}
    cache=owner._symbolon_surfaces
    directory=Path(__file__).resolve().parents[2]/'docs/branding/controls'
    for kind in ('secondary','secondary-hover','primary','primary-hover','disabled','navigation'):
        key=mode+'-'+kind
        if key not in cache:cache[key]=tk.PhotoImage(master=owner,file=str(directory/(key+'.png')))
    def element(kind,hover):
        name='Symbolon.'+mode+'.'+kind
        if name not in style.element_names():
            style.element_create(name,'image',cache[mode+'-'+kind],('disabled',cache[mode+'-disabled']),('pressed',cache[mode+'-'+hover]),('focus',cache[mode+'-'+hover]),('active',cache[mode+'-'+hover]),border=8,padding=0,sticky='nsew')
        return name
    normal=element('secondary','secondary-hover');primary=element('primary','primary-hover');navigation=element('navigation','navigation')
    # Image-backed Frame elements can stall Tk's mapped grid geometry on Windows.
    # Keep frame layouts native/flat; image surfaces remain safe on controls.
    style.layout('Table.TFrame',style.layout('TFrame'))
    style.layout('WorkspaceCard.TFrame',style.layout('TFrame'))
    def button_layout(surface):return [(surface,{'sticky':'nsew','children':[('Button.padding',{'sticky':'nsew','children':[('Button.label',{'sticky':'nsew'})]})]})]
    style.layout('TButton',button_layout(normal));style.layout('Primary.TButton',button_layout(primary))
    plain=[('Button.focus',{'sticky':'nsew','children':[('Button.padding',{'sticky':'nsew','children':[('Button.label',{'sticky':'nsew'})]})]})]
    for prefix in ('Navigation','CompactNavigation'):
        style.layout(prefix+'.TButton',plain);style.layout(prefix+'Selected.TButton',button_layout(navigation))
    for name in ('Subtab.TButton','SubtabSelected.TButton'):style.layout(name,plain)
    for name in ('TEntry','TCombobox','TMenubutton'):
        layout=style.layout(name)
        def surfaces(nodes):
            result=[]
            for element_name,options in nodes:
                options=dict(options)
                if 'children' in options:options['children']=surfaces(options['children'])
                if element_name.endswith(('.field','.border')) or element_name.startswith('Symbolon.'):element_name=normal
                result.append((element_name,options))
            return result
        if layout:style.layout(name,surfaces(layout))

def apply(root,mode='dark'):
    c=palette(mode);family='Segoe UI' if sys.platform=='win32' else 'DejaVu Sans'
    for name in ('TkDefaultFont','TkTextFont','TkMenuFont'):font.nametofont(name).configure(family=family,size=10)
    style=ttk.Style(root);style.theme_use('clam')
    style.configure('.',background=c['bg'],foreground=c['ink'],font=(family,10))
    for name in ('TFrame','TLabel','TLabelframe','TNotebook'):style.configure(name,background=c['bg'])
    style.configure('TLabel',foreground=c['ink']);style.configure('Card.TFrame',background=c['panel']);style.configure('Card.TLabel',background=c['panel'],foreground=c['ink'])
    style.configure('CardSubtitle.TLabel',background=c['panel'],foreground=c['muted'])
    style.configure('Title.TLabel',font=(family,18,'bold'));style.configure('Subtitle.TLabel',foreground=c['muted'])
    style.configure('Brand.TLabel',background=c['button'],foreground=c['ink'],font=(family,12,'bold'))
    style.configure('Metric.TLabel',background=c['panel'],font=(family,23,'bold'));style.configure('Caption.TLabel',background=c['panel'],foreground=c['muted'])
    style.configure('Section.TLabel',font=(family,12,'bold'))
    style.configure('Navigation.TFrame',background=c['button'])
    style.configure('NavigationCaption.TLabel',background=c['button'],foreground=c['muted'],font=(family,8))
    style.configure('Navigation.TButton',background=c['button'],foreground=c['ink'],padding=(10,10),anchor='w',borderwidth=0)
    style.map('Navigation.TButton',background=[('active',c['hover'])],foreground=[('disabled',c['muted'])])
    style.configure('NavigationSelected.TButton',background=c['panel'],foreground=c['blue'],padding=(10,10),anchor='w',borderwidth=0)
    style.map('NavigationSelected.TButton',background=[('active',c['panel'])],foreground=[('active',c['blue'])])
    for name in ('CompactNavigation.TButton','CompactNavigationSelected.TButton'):
        style.configure(name,padding=(10,4),anchor='w',background=c['button'] if name=='CompactNavigation.TButton' else c['panel'],foreground=c['ink'] if name=='CompactNavigation.TButton' else c['blue'])
    for name in ('Subtab.TButton','SubtabSelected.TButton'):
        style.configure(name,padding=(4,8),background=c['panel'],foreground=c['blue'] if name=='SubtabSelected.TButton' else c['muted'],font=(family,9,'bold' if name=='SubtabSelected.TButton' else 'normal'))
        style.map(name,foreground=[('active',c['blue'])])
    for name in ('TButton','TMenubutton'):
        style.configure(name,padding=(11,7),background=c['panel'],foreground=c['ink'],arrowcolor=c['ink'],bordercolor=c['border'],lightcolor=c['border'],darkcolor=c['border'],focuscolor=c['blue'],relief='flat')
        style.map(name,background=[('disabled',c['button']),('pressed',c['hover']),('active',c['hover'])],foreground=[('disabled',c['muted'])],arrowcolor=[('disabled',c['muted'])],bordercolor=[('focus',c['blue'])],lightcolor=[('pressed',c['border'])],darkcolor=[('pressed',c['border'])])
    style.configure('Primary.TButton',background=c['blue'],foreground=c['primary_ink'],bordercolor=c['blue'])
    style.map('Primary.TButton',background=[('disabled',c['button']),('active',c['blue'])],foreground=[('disabled',c['muted']),('active',c['primary_ink'])])
    for name in ('TEntry','TCombobox','TSpinbox'):
        style.configure(name,padding=6,background=c['button'],fieldbackground=c['panel'],foreground=c['ink'],arrowcolor=c['ink'],bordercolor=c['border'],lightcolor=c['border'],darkcolor=c['border'],insertcolor=c['ink'],selectbackground=c['selected'],selectforeground=c['selected_ink'])
        style.map(name,background=[('disabled',c['button']),('pressed',c['hover']),('active',c['hover'])],fieldbackground=[('disabled',c['bg']),('readonly',c['panel'])],foreground=[('disabled',c['muted'])],arrowcolor=[('disabled',c['muted'])],bordercolor=[('focus',c['blue'])],lightcolor=[('focus',c['blue'])],darkcolor=[('focus',c['blue'])])
    for name in ('TCheckbutton','TRadiobutton'):
        style.configure(name,background=c['bg'],foreground=c['ink'],indicatorbackground=c['panel'],bordercolor=c['border'],lightcolor=c['border'],darkcolor=c['border'],focuscolor=c['blue'],padding=(0,3))
        style.map(name,background=[('active',c['bg'])],foreground=[('disabled',c['muted'])],indicatorbackground=[('disabled',c['bg']),('pressed',c['panel']),('alternate',c['panel']),('selected',c['panel'])],bordercolor=[('focus',c['blue'])])
    style.configure('Table.TFrame',background=c['panel'])
    style.layout('Treeview',[('Treeview.treearea',{'sticky':'nswe'})])
    style.configure('Treeview',background=c['panel'],fieldbackground=c['panel'],foreground=c['ink'],rowheight=font.nametofont('TkDefaultFont').metrics('linespace')+10,borderwidth=0,relief='flat',bordercolor=c['panel'])
    style.layout('Treeview.Heading',[('Treeheading.cell',{'sticky':'nswe'}),('Treeheading.padding',{'sticky':'nswe','children':[('Treeheading.image',{'side':'right','sticky':''}),('Treeheading.text',{'sticky':'we'})]})])
    style.configure('Treeview.Heading',background='#f7f6f9' if mode=='light' else c['alternate'],foreground=c['muted'],padding=(8,10),font=(family,9),borderwidth=0,relief='flat')
    style.map('Treeview.Heading',background=[('active',c['hover'])])
    style.map('Treeview',background=[('selected',c['selected'])],foreground=[('selected',c['selected_ink'])])
    style.configure('TNotebook',borderwidth=0);style.configure('TNotebook.Tab',padding=(10,7),font=(family,9),background=c['bg'],foreground=c['muted'])
    style.map('TNotebook.Tab',background=[('selected',c['panel'])],foreground=[('selected',c['blue'])])
    style.configure('Workspace.TNotebook',borderwidth=0,tabmargins=0,background=c['panel'],bordercolor=c['panel'],lightcolor=c['panel'],darkcolor=c['panel'])
    style.layout('Workspace.TNotebook.Tab',[])
    style.configure('TLabelframe',bordercolor=c['border']);style.configure('TLabelframe.Label',font=(family,10,'bold'),foreground=c['muted'])
    style.configure('Horizontal.TProgressbar',background=c['blue'],troughcolor=c['button'],borderwidth=0)
    for orient in ('Vertical','Horizontal'):style.configure(orient+'.TScrollbar',background=c['button'],troughcolor=c['bg'],bordercolor=c['border'],arrowcolor=c['muted'])
    for orient in ('Vertical','Horizontal'):
        name='Table.'+orient+'.TScrollbar'
        style.configure(name,background=c['button'],troughcolor=c['panel'],bordercolor=c['panel'],lightcolor=c['button'],darkcolor=c['button'],arrowcolor=c['muted'],arrowsize=11,borderwidth=0,relief='flat',gripcount=0)
        style.map(name,background=[('pressed',c['hover']),('active',c['hover'])],arrowcolor=[('disabled',c['muted'])])
    for pattern,value in {'*Text.background':c['panel'],'*Text.foreground':c['ink'],'*Text.insertBackground':c['ink'],'*Text.selectBackground':c['selected'],'*Text.selectForeground':c['selected_ink'],'*Listbox.background':c['panel'],'*Listbox.foreground':c['ink'],'*Listbox.selectBackground':c['selected'],'*Listbox.selectForeground':c['selected_ink'],'*Menu.background':c['panel'],'*Menu.foreground':c['ink'],'*Menu.activeBackground':c['selected'],'*Menu.activeForeground':c['selected_ink']}.items():root.option_add(pattern,value)
    def update(widget):
        try:
            if isinstance(widget,(tk.Tk,tk.Toplevel,tk.Frame)):
                widget.configure(background=c['bg'])
                if isinstance(widget,WorkspaceSurface):widget.redraw()
            elif isinstance(widget,tk.Text):
                widget.configure(background=c['panel'],foreground=c['ink'],insertbackground=c['ink'],selectbackground=c['selected'],selectforeground=c['selected_ink'])
                if 'issue' in widget.tag_names():widget.tag_configure('issue',background=c['warning_bg'],foreground=c['ink'])
            elif isinstance(widget,tk.Canvas):
                widget.configure(background=c['bg'])
            elif isinstance(widget,tk.Menu):widget.configure(background=c['panel'],foreground=c['ink'],activebackground=c['selected'],activeforeground=c['selected_ink'])
            elif isinstance(widget,ttk.Treeview):
                widget.tag_configure('alternate',background=c['alternate']);widget.tag_configure('difference',background=c['warning_bg'],foreground=c['ink'])
                widget.tag_configure('status_review',foreground=c['ink']);widget.tag_configure('status_approved',foreground=c['ink'])
            for child in widget.winfo_children():update(child)
        except tk.TclError:pass
    rounded_controls(root,style,mode)
    update(root);return style
