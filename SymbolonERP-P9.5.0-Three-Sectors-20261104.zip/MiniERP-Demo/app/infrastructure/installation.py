"""Installation-local data and one-business binding; no business schema changes."""
from contextlib import closing
import json
import os
from pathlib import Path
import shutil
import sqlite3
import tempfile
import time
import uuid

DATABASE='mini_erp.sqlite3'


class InstallationError(RuntimeError):pass
class InstallationCancelled(InstallationError):pass


def legacy_data_directory(base):
    base=Path(base)
    for name in ('Data','Demo'):
        if (base/name/DATABASE).is_file():return base/name
    return base/'Data'


def copy_data(source,destination):
    """Copy every adjacent file plus a coherent SQLite backup, without source writes."""
    source=Path(source).resolve();destination=Path(destination).resolve()
    if destination.exists():raise FileExistsError('Ο προορισμός υπάρχει ήδη· δεν αντικαταστάθηκαν δεδομένα.')
    if destination.is_relative_to(source) or source.is_relative_to(destination):
        raise InstallationError('Το αντίγραφο χρειάζεται ξεχωριστό φάκελο.')
    if not (source/DATABASE).is_file():raise InstallationError('Δεν βρέθηκε βάση στο αρχικό αντίγραφο.')
    destination.parent.mkdir(parents=True,exist_ok=True)
    ignored={DATABASE,DATABASE+'-wal',DATABASE+'-shm',DATABASE+'-journal'}
    def files():
        result={}
        for path in source.rglob('*'):
            if path.is_symlink():raise InstallationError('Η αντιγραφή δεν υποστηρίζει συμβολικούς συνδέσμους.')
            if path.is_file() and path.relative_to(source).as_posix() not in ignored:
                stat=path.stat();result[path.relative_to(source)]=(stat.st_size,stat.st_mtime_ns)
        return result
    with tempfile.TemporaryDirectory(prefix='.symbolon-copy-',dir=destination.parent) as staging:
        target=Path(staging)/'Data';target.mkdir()
        with closing(sqlite3.connect((source/DATABASE).as_uri()+'?mode=ro',uri=True)) as db:
            version=db.execute('PRAGMA data_version').fetchone()[0]
            before=files()
            for relative in before:
                saved=target/relative;saved.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(source/relative,saved)
            deadline=time.monotonic()+30
            def progress(status,remaining,total):
                if time.monotonic()>deadline:raise InstallationError('Η βάση είναι απασχολημένη. Κλείσε την άλλη εκτέλεση και ξαναδοκίμασε.')
            with closing(sqlite3.connect(target/DATABASE)) as saved:
                db.backup(saved,pages=256,progress=progress)
                if saved.execute('PRAGMA integrity_check').fetchone()[0]!='ok':
                    raise InstallationError('Δεν επιβεβαιώθηκε η ακεραιότητα του αντιγράφου.')
            if files()!=before or db.execute('PRAGMA data_version').fetchone()[0]!=version:
                raise InstallationError('Τα αρχικά δεδομένα άλλαξαν. Κλείσε την άλλη εκτέλεση πριν την αντιγραφή.')
        if destination.exists():raise FileExistsError('Ο προορισμός δημιουργήθηκε από άλλη εκτέλεση· δεν αντικαταστάθηκε.')
        target.rename(destination)
    return destination


def resolve_data_directory(root,environment=None,choose_legacy=None):
    root=Path(root).resolve();env=os.environ if environment is None else environment
    explicit=env.get('MINIERP_DATA_DIR')
    if explicit:
        path=Path(explicit).expanduser()
        return (path if path.is_absolute() else root/path).resolve()
    local=root/'Data'
    if (local/DATABASE).is_file():return local
    personal=root.parent
    if (personal/'personal_installation.py').is_file() and (personal/'Data'/DATABASE).is_file():return personal/'Data'
    profile=env.get('LOCALAPPDATA')
    old=legacy_data_directory(Path(profile)/'MiniERP') if profile else None
    if old is None or not (old/DATABASE).is_file():return local
    if choose_legacy is None:raise InstallationError('Χρειάζεται επιλογή αντιγραφής των παλιών δεδομένων ή νέας επιχείρησης.')
    choice=choose_legacy(old)
    if choice is None:raise InstallationCancelled('Η εκκίνηση ακυρώθηκε χωρίς αλλαγή δεδομένων.')
    if choice=='new':return local
    if choice=='copy':return copy_data(old,local)
    raise InstallationError('Μη έγκυρη επιλογή εγκατάστασης.')


def bind_company(db,directory,choose=None):
    directory=Path(directory);identity=directory/'installation.json'
    rows=db.execute('SELECT id,vat,name FROM companies ORDER BY id').fetchall()
    if identity.exists():
        try:
            if identity.stat().st_size>65536:raise ValueError()
            value=json.loads(identity.read_text(encoding='utf8'))
            if not isinstance(value,dict) or value.get('format')!='SymbolonERP-installation-v1' or type(value.get('company_id')) is not int:raise ValueError()
            row=next((r for r in rows if r['id']==value['company_id']),None)
            if row is None:raise ValueError()
            return row
        except (ValueError,TypeError,KeyError,UnicodeError) as exc:
            raise InstallationError('Η ταυτότητα εγκατάστασης δεν συμφωνεί με τη βάση. Δεν επιλέχθηκε άλλη επιχείρηση.') from exc
    if not rows:return None
    if len(rows)==1:selected=rows[0]
    else:
        if choose is None:raise InstallationError('Η παλιά βάση έχει πολλές επιχειρήσεις. Επίλεξε μία για αυτή την εγκατάσταση.')
        chosen=choose(rows)
        if chosen is None:raise InstallationCancelled('Δεν επιλέχθηκε επιχείρηση.')
        selected=next((r for r in rows if type(chosen) is int and r['id']==chosen),None)
        if selected is None:raise InstallationError('Μη έγκυρη επιχείρηση εγκατάστασης.')
    value=dict(format='SymbolonERP-installation-v1',installation_id=str(uuid.uuid4()),company_id=selected['id'])
    directory.mkdir(parents=True,exist_ok=True)
    fd,name=tempfile.mkstemp(prefix='.installation-',suffix='.json',dir=directory)
    staged=Path(name)
    try:
        with os.fdopen(fd,'w',encoding='utf8') as stream:json.dump(value,stream,ensure_ascii=False,indent=2)
        # Exclusive publication: another simultaneous launch cannot replace identity.
        try:
            if os.name=='nt':staged.rename(identity)
            else:os.link(staged,identity)
        except FileExistsError:return bind_company(db,directory)
    finally:staged.unlink(missing_ok=True)
    return selected
