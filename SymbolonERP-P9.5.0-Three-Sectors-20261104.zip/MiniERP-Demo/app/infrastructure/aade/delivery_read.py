"""Read quantity metadata from archived AADE XML, without financial parsing writes."""
from decimal import Decimal,InvalidOperation
from functools import lru_cache
import hashlib
from pathlib import Path
import xml.etree.ElementTree as ET

NS='http://www.aade.gr/myDATA/invoice/v1.0'
MAX_XML=16*1024*1024


def local(node):return node.tag.rsplit('}',1)[-1]
def child(node,name):return next((n for n in node if local(n)==name),None) if node is not None else None
def text(node,name,default=''):
    item=child(node,name);return item.text.strip() if item is not None and item.text else default
def integer(value):
    try:return int(value)
    except (TypeError,ValueError):raise ValueError('Μη έγκυρη ακέραια τιμή στο XML διακίνησης.') from None


def _root(data):
    if isinstance(data,str):data=data.encode('utf8')
    if not isinstance(data,bytes) or len(data)>MAX_XML:raise ValueError('Υπερβολικό ή μη έγκυρο XML διακίνησης.')
    # Decode declaration guards even for UTF-16/32; ElementTree does not fetch
    # external resources, and we reject internal DTDs/entities as well.
    guard=data.replace(b'\x00',b'').upper()
    if b'<!DOCTYPE' in guard or b'<!ENTITY' in guard:raise ValueError('Δεν επιτρέπονται DTD/οντότητες XML.')
    try:return ET.fromstring(data)
    except ET.ParseError:raise ValueError('Μη έγκυρο XML διακίνησης.') from None


def _address(node):
    return {key:text(node,field) for key,field in (('street','street'),('number','number'),('postal_code','postalCode'),('city','city')) if text(node,field)}


def _metadata(invoice):
    header=child(invoice,'invoiceHeader');issuer=child(invoice,'issuer');recipient=child(invoice,'counterpart')
    kind=text(header,'invoiceType')
    if kind not in ('9.1','9.2','9.3','10.1','10.2') and text(header,'isDeliveryNote').lower() not in ('true','1'):raise ValueError('Το XML δεν είναι παραστατικό διακίνησης.')
    data={'invoice_type':kind,'issuer_vat':text(issuer,'vatNumber'),'recipient_vat':text(recipient,'vatNumber'),
      'counterpart_vat':text(recipient,'vatNumber'),'counterpart_name':text(recipient,'name'),'series':text(header,'series'),
      'number':text(header,'aa'),'issue_date':text(header,'issueDate'),'lines':[]}
    for key,field in (('dispatch_date','dispatchDate'),('dispatch_time','dispatchTime'),('vehicle_number','vehicleNumber'),('other_movement_purpose','otherMovePurposeTitle')):
        if text(header,field):data[key]=text(header,field)
    for key,field in (('movement_purpose','movePurpose'),('reverse_delivery_purpose','reverseDeliveryNotePurpose'),('receiving_note_purpose','receivingNotePurpose')):
        if text(header,field):data[key]=integer(text(header,field))
    for key,field in (('reverse_delivery','reverseDeliveryNote'),('non_obligated_recipient','nonObligatedRecipient'),('to_weigh','toWeigh'),('without_digital_transport_tracking','withoutDigitalTransportTracking')):
        if child(header,field) is not None:data[key]=text(header,field).lower() in ('true','1')
    delivery=child(header,'otherDeliveryNoteHeader')
    for key,field,party,branch in (('loading_address','loadingAddress',issuer,'startShippingBranch'),('delivery_address','deliveryAddress',recipient,'completeShippingBranch')):
        source=child(delivery,field)
        if source is None:source=child(party,'address')
        address=_address(source)
        if text(party,'country'):address['country']=text(party,'country')
        number=text(delivery,branch) or text(party,'branch')
        if number:address['branch']=integer(number)
        if address:data[key]=address
    for row in invoice:
        if local(row)!='invoiceDetails':continue
        item={'line_number':integer(text(row,'lineNumber')),'description':text(row,'itemDescr'),'item_code':text(row,'itemCode')}
        quantity=text(row,'quantity')
        if quantity:
            try:value=Decimal(quantity)
            except InvalidOperation:raise ValueError('Μη έγκυρη ποσότητα XML.') from None
            if not value.is_finite():raise ValueError('Μη πεπερασμένη ποσότητα XML.')
            item['quantity']=quantity
        if text(row,'measurementUnit'):item['measurement_unit']=integer(text(row,'measurementUnit'))
        for key,field in (('other_measurement_unit_title','otherMeasurementUnitTitle'),('other_measurement_unit_quantity','otherMeasurementUnitQuantity')):
            if text(row,field):item[key]=text(row,field)
        data['lines'].append(item)
    data['correlated_marks']=[n.text.strip() for n in header if local(n)=='correlatedInvoices' and n.text] if header is not None else []
    if text(invoice,'mark'):data['mark']=text(invoice,'mark')
    if text(invoice,'qrCodeUrl'):data['qr_url']=text(invoice,'qrCodeUrl')
    if text(invoice,'invoiceDeliveryStatus'):data['aade_status']=text(invoice,'invoiceDeliveryStatus')
    lifecycle=child(invoice,'deliveryLifecycle')
    if lifecycle is not None:
        data['delivery_lifecycle_xml']=ET.tostring(lifecycle,encoding='unicode')
        for event in lifecycle:
            outcome=text(child(event,'outcomeDetails'),'outcome')
            if outcome:data['outcome']=outcome
    return data


def _extract(root,mark=None):
    invoices=[node for node in root.iter() if node.tag=='{'+NS+'}invoice']
    if mark is None:
        if len(invoices)!=1:raise ValueError('Το XML πρέπει να περιέχει ένα παραστατικό διακίνησης.')
        return _metadata(invoices[0])
    matches=[_metadata(node) for node in invoices if text(node,'mark')==str(mark)]
    if not matches:return None
    if any(item!=matches[0] for item in matches[1:]):raise ValueError('Αντικρουόμενα στοιχεία διακίνησης για το ίδιο MARK.')
    return matches[0]


def read_xml(data,mark=None):
    """Read one quantity document, or the exact MARK in a raw AADE response."""
    return _extract(_root(data),mark)


def extract_delivery(data,mark):return read_xml(data,mark)


@lru_cache(maxsize=4)
def _archived_root(path,size,mtime,digest):
    raw=Path(path).read_bytes()
    if hashlib.sha256(raw).hexdigest()!=digest:raise ValueError('Αλλοιωμένο XML στην αρχειοθήκη ΑΑΔΕ.')
    return _root(raw)


def read_record(erp,row):
    """Company/environment/sync-scoped read. Missing metadata stays visible.

    At most64 archive pages, at most16MiB per page; cached parsing uses four
    verified file versions to avoid reparsing the month for every visible row.
    """
    row=dict(row);directory=(erp.directory/'mydata'/'xml').resolve()
    pages=erp.db.execute('SELECT p.storage_path,p.sha256 FROM mydata_pages p JOIN mydata_syncs s ON s.id=p.sync_id WHERE s.company_id=? AND s.environment=? AND s.id<=? ORDER BY (s.id=?) DESC,s.id DESC,p.id LIMIT 64',(row['company_id'],row['environment'],row['last_sync'],row['last_sync'])).fetchall()
    issue='Δεν βρέθηκε το αρχικό XML διακίνησης για το συγκεκριμένο MARK.'
    for page in pages:
        try:
            path=(erp.directory/page['storage_path']).resolve()
            if not path.is_relative_to(directory):raise ValueError('Μη επιτρεπόμενη διαδρομή XML αρχειοθήκης.')
            stat=path.stat()
            if stat.st_size>MAX_XML:raise ValueError('Υπερβολικό μέγεθος XML αρχειοθήκης.')
            result=_extract(_archived_root(str(path),stat.st_size,stat.st_mtime_ns,page['sha256']),row['mark'])
            if result is not None:
                result['delivery_xml_source']=page['storage_path'];return result
        except (ValueError,OSError) as exc:issue=str(exc)
    return {'delivery_read_issue':issue}
