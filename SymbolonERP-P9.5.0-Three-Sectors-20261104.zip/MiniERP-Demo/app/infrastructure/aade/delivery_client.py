"""Explicit AADE v2.0.2 delivery writes. No retries; independent of read-only client.

Transport injection: callable(urllib.request.Request, timeout=seconds) -> bytes or
context-managed HTTP response. Requests remain on fixed official hosts.
"""
from decimal import Decimal, InvalidOperation
from functools import lru_cache
from pathlib import Path
import socket
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from app.infrastructure.aade.credentials import validate, USER_HEADER, KEY_HEADER

SCHEMAS=Path(__file__).resolve().parents[3]/'docs'/'aade_delivery'/'official_xsd'
NS='http://www.aade.gr/myDATA/invoice/v1.0'
BASES={'test':'https://mydataapidev.aade.gr/','production':'https://mydatapi.aade.gr/myDATA/'}
POSTS={'RegisterTransfer':('Transport','RegisterTransfer-v2.0.2.xsd'),
 'ConfirmDeliveryOutcome':('ConfirmDeliveryOutcomeRequest','ConfirmDeliveryOutcome-v2.0.2.xsd'),
 'RejectDeliveryNote':('RejectDeliveryNoteRequest','RejectDeliveryNote-v2.0.2.xsd'),
 'ConfirmDeliveryReturn':('ConfirmDeliveryReturnRequest','ConfirmDeliveryReturn-v2.0.2.xsd'),
 'GenerateGroupQRCode':('GenerateGroupQRCodeRequest','GenerateGroupQRCode-v2.0.2.xsd')}


def _xml(data):
    raw=data.encode('utf-8') if isinstance(data,str) else data
    if not isinstance(raw,bytes) or len(raw)>16*1024*1024:raise ValueError('Μη έγκυρο μέγεθος XML')
    if b'<!DOCTYPE' in raw.upper() or b'<!ENTITY' in raw.upper():raise ValueError('Δεν επιτρέπονται DTD/οντότητες XML')
    try:return ET.fromstring(raw)
    except ET.ParseError as exc:raise ValueError('Μη έγκυρο XML') from exc


@lru_cache(maxsize=10)
def _schema(name):
    try:import xmlschema
    except ImportError:raise ValueError('Απαιτείται η βιβλιοθήκη xmlschema για επικύρωση ΑΑΔΕ. Επανεκκίνησε από τον launcher εγκατάστασης.') from None
    return xmlschema.XMLSchema(str(SCHEMAS/name),allow='local',defuse='always')


def validate_xml(data,schema_name):
    root=_xml(data)
    try:_schema(schema_name).validate(root)
    except ValueError:raise
    except Exception as exc:raise ValueError('Το XML δεν συμφωνεί με το επίσημο XSD ΑΑΔΕ: '+str(exc)[:600]) from None
    return root


def _scalar(value):
    if isinstance(value,bool):return 'true' if value else 'false'
    if isinstance(value,float):raise ValueError('Χρησιμοποίησε δεκαδικό κείμενο αντί για float')
    if isinstance(value,Decimal):
        if not value.is_finite():raise ValueError('Μη πεπερασμένη τιμή')
        return format(value,'f')
    if value is None:raise ValueError('Λείπει τιμή XML')
    return str(value)


def _append(parent,name,value):
    if isinstance(value,list):
        for item in value:_append(parent,name,item)
        return
    child=ET.SubElement(parent,name)
    if isinstance(value,dict):
        for key,item in value.items():_append(child,key,item)
    else:child.text=_scalar(value)


def _positive(value):
    s=str(value)
    if not s.isdigit() or int(s)<=0:raise ValueError('Απαιτείται θετικό MARK')
    return s


def build_request(operation,payload):
    """Return {method,path,body}; validates locally, never performs I/O."""
    if not isinstance(payload,dict):raise ValueError('Το αίτημα πρέπει να είναι λεξικό')
    if operation in ('GetDeliveryNoteStatus','CancelInvoice','RequestGroupQRDetails'):
        allowed={'GetDeliveryNoteStatus':{'mark','qrUrl','issuerVatNumber'},'CancelInvoice':{'mark','entityVatNumber'},'RequestGroupQRDetails':{'groupId'}}[operation]
        if set(payload)-allowed:raise ValueError('Άγνωστα πεδία αιτήματος')
        if operation=='GetDeliveryNoteStatus':
            if bool(payload.get('mark'))==bool(payload.get('qrUrl')):raise ValueError('Δώσε μόνο MARK ή QR')
            if payload.get('qrUrl') and payload.get('issuerVatNumber'):raise ValueError('ΑΦΜ εκδότη μόνο με MARK')
        elif not payload.get('mark' if operation=='CancelInvoice' else 'groupId'):raise ValueError('Λείπει αναγνωριστικό')
        if payload.get('mark'):_positive(payload['mark'])
        return {'method':'POST' if operation=='CancelInvoice' else 'GET','path':operation+'?'+urllib.parse.urlencode(payload),'body':None}
    if operation=='SendInvoices':
        if set(payload)!={'xml'}:raise ValueError('Απαιτείται μόνο xml')
        raw=payload['xml'].encode('utf-8') if isinstance(payload['xml'],str) else payload['xml']
        root=validate_xml(raw,'InvoicesDoc-v2.0.2.xsd')
        invoices=root.findall('{'+NS+'}invoice')
        if len(invoices)!=1:raise ValueError('Μία έκδοση διακίνησης ανά αίτημα')
        kind=invoices[0].findtext('{'+NS+'}invoiceHeader/{'+NS+'}invoiceType')
        if kind not in ('9.1','9.2','9.3','10.1','10.2'):raise ValueError('Εδώ εκδίδονται μόνο παραστατικά διακίνησης/ποσοτικής παραλαβής')
        return {'method':'POST','path':operation,'body':raw}
    if operation not in POSTS:raise ValueError('Μη υποστηριζόμενη ενέργεια ΑΑΔΕ')
    root_name,schema_name=POSTS[operation]
    orders={'RegisterTransfer':('qrUrl','transportDetail'),
      'ConfirmDeliveryOutcome':('qrUrl','outcome','deliveredWithoutRecipient','deliveredPackaging'),
      'RejectDeliveryNote':('qrUrl','invoiceMark','rejectionReason'),
      'ConfirmDeliveryReturn':('qrUrl',),'GenerateGroupQRCode':('qrUrls',)}
    if set(payload)-set(orders[operation]):raise ValueError('Άγνωστα πεδία αιτήματος')
    if operation=='ConfirmDeliveryOutcome' and payload.get('outcome')=='PARTIAL' and not payload.get('deliveredPackaging'):raise ValueError('Η μερική παράδοση χρειάζεται συσκευασίες')
    root=ET.Element(root_name)
    for key in orders[operation]:
        if key not in payload:continue
        value=payload[key]
        if key=='transportDetail':
            order=('vehicleNumber','transportType','timeStamp','carrierVatNumber','pNumber','location','packingsDeclaration')
            if not isinstance(value,dict) or set(value)-set(order):raise ValueError('Μη έγκυρα στοιχεία μεταφοράς')
            value={k:value[k] for k in order if k in value}
        if key=='qrUrls':value={'qrUrl':value}
        _append(root,key,value)
    raw=ET.tostring(root,encoding='utf-8',xml_declaration=True)
    validate_xml(raw,schema_name)
    return {'method':'POST','path':operation,'body':raw}


def build_invoice_xml(data):
    """Build a non-monetary 9.3 draft from documented service/UI flat fields."""
    purpose=str(data.get('movement_purpose',''))
    if purpose in ('6','15','16','17','18'):raise ValueError('Ο σκοπός διακίνησης έχει καταργηθεί από τις επιχειρησιακές προδιαγραφές ΑΑΔΕ.')
    if purpose=='19' and not str(data.get('other_movement_purpose','')).strip():raise ValueError('Συμπλήρωσε περιγραφή για τον λοιπό σκοπό διακίνησης.')
    def tag(name):return '{'+NS+'}'+name
    def add(parent,name,value):
        element=ET.SubElement(parent,tag(name));element.text=_scalar(value);return element
    root=ET.Element(tag('InvoicesDoc'));invoice=ET.SubElement(root,tag('invoice'))
    for role,vat in (('issuer',data.get('issuer_vat')),('counterpart',data.get('counterpart_vat') or data.get('recipient_vat'))):
        if not vat:raise ValueError('Απαιτούνται ΑΦΜ εκδότη και λήπτη')
        address=data.get('loading_address' if role=='issuer' else 'delivery_address') or {}
        party=ET.SubElement(invoice,tag(role));add(party,'vatNumber',vat);add(party,'country',address.get('country') or 'GR');add(party,'branch',address.get('branch') or 0)
    header=ET.SubElement(invoice,tag('invoiceHeader'))
    for name,value in (('series',data.get('series')),('aa',data.get('number')),('issueDate',data.get('issue_date')),('invoiceType','9.3')):add(header,name,value)
    for mark in data.get('correlated_marks',[]):add(header,'correlatedInvoices',_positive(mark))
    for name,key in (('dispatchDate','dispatch_date'),('dispatchTime','dispatch_time'),('vehicleNumber','vehicle_number'),('movePurpose','movement_purpose')):
        if data.get(key) not in (None,''):add(header,name,data[key])
    addresses=ET.SubElement(header,tag('otherDeliveryNoteHeader'))
    for name,key in (('loadingAddress','loading_address'),('deliveryAddress','delivery_address')):
        source=data.get(key) or {};address=ET.SubElement(addresses,tag(name))
        for xml_name,field in (('street','street'),('number','number'),('postalCode','postal_code'),('city','city')):
            if source.get(field) not in (None,''):add(address,xml_name,source[field])
    for name,key in (('startShippingBranch','loading_address'),('completeShippingBranch','delivery_address')):
        branch=(data.get(key) or {}).get('branch')
        if branch is not None:add(addresses,name,branch)
    if purpose=='19':add(header,'otherMovePurposeTitle',str(data['other_movement_purpose']).strip())
    if not data.get('lines'):raise ValueError('Απαιτείται τουλάχιστον μία γραμμή είδους')
    for index,line in enumerate(data['lines'],1):
        row=ET.SubElement(invoice,tag('invoiceDetails'));add(row,'lineNumber',line.get('line_number',index))
        if line.get('item_code'):add(row,'itemCode',line['item_code'])
        if not line.get('description'):raise ValueError('Λείπει περιγραφή είδους')
        add(row,'itemDescr',line['description'])
        try:quantity=Decimal(str(line.get('quantity','')))
        except InvalidOperation:raise ValueError('Μη έγκυρη ποσότητα') from None
        if not quantity.is_finite() or quantity<=0:raise ValueError('Η ποσότητα πρέπει να είναι θετική')
        add(row,'quantity',quantity);add(row,'measurementUnit',line.get('measurement_unit',1))
        add(row,'netValue','0.00');add(row,'vatCategory',8);add(row,'vatAmount','0.00')
    summary=ET.SubElement(invoice,tag('invoiceSummary'))
    for field in ('totalNetValue','totalVatAmount','totalWithheldAmount','totalFeesAmount','totalStampDutyAmount','totalOtherTaxesAmount','totalDeductionsAmount','totalGrossValue'):add(summary,field,'0.00')
    raw=ET.tostring(root,encoding='utf-8',xml_declaration=True)
    validate_xml(raw,'InvoicesDoc-v2.0.2.xsd')
    return raw.decode('utf-8')


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):return None


def _result(**values):
    return dict(success=False,errors=[],raw_xml='',mark=None,status=None,qr_url=None,outcome=None,lifecycle_history=[],identifiers={},ambiguous=False,cancelled=False,**values)


def _parse_response(raw):
    result=_result();result['raw_xml']=raw.decode('utf-8') if isinstance(raw,bytes) else raw
    root=_xml(raw)
    local=lambda node:node.tag.rsplit('}',1)[-1]
    fields={local(node):node.text for node in root.iter() if node.text and not list(node)}
    errors=[]
    for node in root.iter():
        if local(node)=='error':errors.append({local(c):c.text or '' for c in node})
    statuses=[node.text for node in root.iter() if local(node)=='statusCode']
    valid_root=local(root) in ('ResponseDoc','GetDeliveryNoteStatusResponse','GenerateGroupQRCodeResponse','RequestGroupQRDetailsResponse')
    result['errors']=errors
    if statuses and any(s!='Success' for s in statuses) and not errors:result['errors']=[{'code':'AADE','message':', '.join(statuses)}]
    result['success']=valid_root and not result['errors'] and (bool(statuses) or local(root)!='ResponseDoc')
    if not valid_root:result['errors']=[{'code':'RESPONSE','message':'Μη αναμενόμενη απάντηση ΑΑΔΕ'}]
    keys=('invoiceMark','cancellationMark','transferMark','rejectMark','deliveryOutcomeMark','deliveryReturnMark','qrUrl','groupQrUrl','groupId','expiresAt','invoiceUid')
    result['identifiers']={k:fields[k] for k in keys if fields.get(k)}
    result['mark']=fields.get('invoiceMark');result['status']=fields.get('status')
    result['qr_url']=fields.get('qrUrl') or fields.get('groupQrUrl')
    for node in root:
        if local(node)=='lifecycleHistory':
            event={local(c):c.text for c in node if not list(c)}
            event['raw_xml']=ET.tostring(node,encoding='unicode')
            result['lifecycle_history'].append(event)
            for detail in node:
                if local(detail)=='outcomeDetails':
                    outcome=next((c.text for c in detail if local(c)=='outcome'),None)
                    if outcome is not None:result['outcome']=outcome
    return result


class DeliveryClient:
    def __init__(self,environment,username,key,transport=None):
        self.credentials=validate(environment,username,key);self.base=BASES[environment]
        self.transport=transport or urllib.request.build_opener(NoRedirect()).open

    def perform(self,operation,payload,*,cancel=None):
        request=build_request(operation,payload)
        stopped=lambda:bool(cancel and (cancel() if callable(cancel) else cancel.is_set()))
        if stopped():
            result=_result();result['cancelled']=True;return result
        headers={USER_HEADER:self.credentials['username'],KEY_HEADER:self.credentials['key'],'Content-Type':'application/xml; charset=utf-8','Accept':'application/xml'}
        req=urllib.request.Request(self.base+request['path'],data=request['body'],headers=headers,method=request['method'])
        try:
            response=self.transport(req,timeout=30)
            if isinstance(response,(bytes,str)):raw=response
            else:
                with response:raw=response.read(16*1024*1024+1)
            result=_parse_response(raw)
            if any(e.get('code')=='RESPONSE' for e in result['errors']):result['ambiguous']=operation not in ('GetDeliveryNoteStatus','RequestGroupQRDetails')
            required={'SendInvoices':'invoiceMark','CancelInvoice':'cancellationMark','RegisterTransfer':'transferMark',
              'ConfirmDeliveryOutcome':'deliveryOutcomeMark','RejectDeliveryNote':'rejectMark','ConfirmDeliveryReturn':'deliveryReturnMark',
              'GenerateGroupQRCode':'groupQrUrl','GetDeliveryNoteStatus':'invoiceMark'}
            if result['success'] and (required.get(operation) and not result['identifiers'].get(required[operation]) or operation=='GetDeliveryNoteStatus' and not result['status']):
                result['success']=False;result['ambiguous']=operation not in ('GetDeliveryNoteStatus','RequestGroupQRDetails')
                result['errors']=[{'code':'RESPONSE','message':'Η απάντηση δεν περιέχει το αναγνωριστικό/κατάσταση της ενέργειας. Έλεγξε την κατάσταση ΑΑΔΕ.'}]
            if stopped():result['cancelled']=True
            return result
        except urllib.error.HTTPError as exc:
            result=_result();result['errors']=[{'code':'HTTP_'+str(exc.code),'message':'Η ΑΑΔΕ επέστρεψε HTTP '+str(exc.code)}]
            result['ambiguous']=exc.code>=500 and operation not in ('GetDeliveryNoteStatus','RequestGroupQRDetails')
            exc.close()
            return result
        except (TimeoutError,socket.timeout,OSError) as exc:
            result=_result();result['ambiguous']=operation not in ('GetDeliveryNoteStatus','RequestGroupQRDetails')
            result['errors']=[{'code':'TRANSPORT','message':'Δεν επιβεβαιώθηκε το αποτέλεσμα. Έλεγξε την κατάσταση ΑΑΔΕ πριν νέα αποστολή.'}]
            return result
        except (ValueError,UnicodeError):
            result=_result();result['ambiguous']=operation not in ('GetDeliveryNoteStatus','RequestGroupQRDetails')
            result['errors']=[{'code':'RESPONSE','message':'Μη αναγνώσιμη απάντηση ΑΑΔΕ· χρειάζεται έλεγχος κατάστασης.'}]
            return result
