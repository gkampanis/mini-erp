"""Explicit AADE group QR generation and lookup; no EBS/financial side effects."""
import json
from urllib.parse import urlparse,parse_qs
from app.application.delivery import DeliveryService
from app.infrastructure.aade.delivery_client import DeliveryClient,build_request


def encoded(value):return json.dumps(value,ensure_ascii=False,default=str)


class DeliveryGroupsService:
    def __init__(self,erp):self.erp=erp;self.db=erp.db

    def get(self,company,id):
        row=self.db.execute('SELECT * FROM delivery_groups WHERE company_id=? AND id=?',(company,id)).fetchone()
        if row is None:raise ValueError('Δεν βρέθηκε ομάδα QR στην επιχείρηση της εγκατάστασης.')
        result=dict(row)
        for key in ('document_ids','qr_urls'):result[key]=json.loads(result[key])
        result['actions']=[dict(r) for r in self.db.execute('SELECT * FROM delivery_group_actions WHERE company_id=? AND group_id=? ORDER BY id',(company,id))]
        return result

    def list(self,company):
        return [self.get(company,r['id']) for r in self.db.execute('SELECT id FROM delivery_groups WHERE company_id=? ORDER BY id DESC',(company,))]

    def prepare_generate(self,company,document_ids):
        ids=list(dict.fromkeys(document_ids))
        if len(ids)<2:raise ValueError('Επίλεξε τουλάχιστον δύο διαφορετικά δελτία με QR.')
        documents=[DeliveryService(self.erp).get(company,id) for id in ids]
        environments={d['environment'] for d in documents}
        if len(environments)!=1:raise ValueError('Τα δελτία πρέπει να ανήκουν στο ίδιο περιβάλλον ΑΑΔΕ.')
        if any(d['role'] not in ('issuer','carrier') for d in documents):raise ValueError('Η δημιουργία ομαδικού QR γίνεται από εκδότη ή μεταφορέα.')
        urls=[d.get('qr_url','') for d in documents]
        if any(not value for value in urls) or len(set(urls))!=len(urls):raise ValueError('Κάθε δελτίο χρειάζεται διαφορετικό σύνδεσμο QR ΑΑΔΕ.')
        payload={'qrUrls':urls}
        return dict(operation='GenerateGroupQRCode',payload=payload,request=build_request('GenerateGroupQRCode',payload),environment=documents[0]['environment'],document_ids=ids,references=[d.get('reference','') for d in documents])

    def prepare_details(self,company,id,remote_group_id=None):
        group=self.get(company,id)
        remote=str(remote_group_id or group['remote_group_id']).strip()
        if not remote:raise ValueError('Συμπλήρωσε το Group ID της ΑΑΔΕ. Η απόκριση δημιουργίας μπορεί να περιέχει μόνο σύνδεσμο QR.')
        if group['remote_group_id'] and remote!=group['remote_group_id']:raise ValueError('Το Group ID δεν αντιστοιχεί στην επιλεγμένη ομάδα.')
        payload={'groupId':remote}
        return dict(operation='RequestGroupQRDetails',payload=payload,request=build_request('RequestGroupQRDetails',payload),environment=group['environment'])

    def generate(self,company,document_ids,*,confirmed=False,client=None,cancel=None):
        if confirmed is not True:raise ValueError('Απαιτείται επιβεβαίωση δημιουργίας στην ΑΑΔΕ.')
        preview=self.prepare_generate(company,document_ids)
        if self._cancelled(cancel):return None
        if client is None:
            credentials=self.erp.mydata_credentials(company,preview['environment'])
            client=DeliveryClient(preview['environment'],credentials['username'],credentials['key'])
        with self.db:
            id=self.db.execute('INSERT INTO delivery_groups(company_id,environment,document_ids,qr_urls) VALUES(?,?,?,?)',(company,preview['environment'],encoded(preview['document_ids']),encoded(preview['payload']['qrUrls']))).lastrowid
        return self._perform(company,id,preview,client,cancel)

    def refresh_details(self,company,id,remote_group_id=None,*,confirmed=False,client=None,cancel=None):
        if confirmed is not True:raise ValueError('Απαιτείται επιβεβαίωση λήψης στοιχείων από ΑΑΔΕ.')
        preview=self.prepare_details(company,id,remote_group_id)
        if self._cancelled(cancel):return self.get(company,id)
        return self._perform(company,id,preview,client,cancel)

    @staticmethod
    def _cancelled(cancel):return bool(cancel and (cancel.is_set() if hasattr(cancel,'is_set') else cancel()))

    def _perform(self,company,id,preview,client,cancel):
        operation=preview['operation'];group=self.get(company,id)
        if client is None:
            credentials=self.erp.mydata_credentials(company,group['environment'])
            client=DeliveryClient(group['environment'],credentials['username'],credentials['key'])
        raw=preview['request']['body'];raw=raw.decode('utf8') if isinstance(raw,bytes) else preview['request']['path']
        with self.db:
            if self.db.execute("SELECT 1 FROM delivery_group_actions WHERE company_id=? AND group_id=? AND status='pending'",(company,id)).fetchone():raise ValueError('Η ομάδα περιμένει ήδη απάντηση ΑΑΔΕ.')
            action=self.db.execute("INSERT INTO delivery_group_actions(company_id,group_id,operation,status,request_json,raw_request) VALUES(?,?,?,'pending',?,?)",(company,id,operation,encoded(preview['payload']),raw)).lastrowid
        try:response=client.perform(operation,preview['payload'],cancel=cancel)
        except Exception:response=dict(success=False,ambiguous=operation=='GenerateGroupQRCode',errors=[dict(code='TRANSPORT',message='Δεν επιβεβαιώθηκε το αποτέλεσμα από ΑΑΔΕ.')],raw_xml='')
        identifiers=response.get('identifiers') or {}
        if response.get('success') and operation=='RequestGroupQRDetails' and identifiers.get('groupId')!=preview['payload']['groupId']:
            response=dict(response,success=False,errors=[dict(code='IDENTITY',message='Η απάντηση αφορά διαφορετικό Group ID.')])
        if response.get('success') and operation=='GenerateGroupQRCode' and not identifiers.get('groupQrUrl'):
            response=dict(response,success=False,ambiguous=True,errors=[dict(code='RESPONSE',message='Δεν επιστράφηκε σύνδεσμος ομαδικού QR.')])
        state='uncertain' if response.get('ambiguous') else 'accepted' if response.get('success') else 'cancelled' if response.get('cancelled') else 'error'
        qr=group['group_qr_url'];remote=group['remote_group_id'];expires=group['expires_at']
        if response.get('success'):
            qr=identifiers.get('groupQrUrl') or qr
            # The official generation response contains no groupId field. Only
            # use an explicit named query parameter; never infer opaque paths.
            query=parse_qs(urlparse(qr).query).get('groupId',[])
            remote=identifiers.get('groupId') or (query[0] if len(query)==1 else '') or remote
            expires=identifiers.get('expiresAt') or expires
        group_state=state if operation=='GenerateGroupQRCode' or response.get('success') else group['status']
        with self.db:
            self.db.execute('UPDATE delivery_group_actions SET status=?,response_json=?,raw_response=?,completed_at=CURRENT_TIMESTAMP WHERE company_id=? AND id=?',(state,encoded(response),response.get('raw_xml',''),company,action))
            self.db.execute('UPDATE delivery_groups SET status=?,group_qr_url=?,remote_group_id=?,expires_at=?,updated_at=CURRENT_TIMESTAMP WHERE company_id=? AND id=?',(group_state,qr,remote,expires,company,id))
        return self.get(company,id)
