"""Independent quantity-document workspace; never enters expense posting tables."""
from datetime import date
from decimal import Decimal, InvalidOperation
import json


def encoded(value):
    return json.dumps(value,ensure_ascii=False,default=str,sort_keys=True)


class DeliveryService:
    def __init__(self,erp):self.erp=erp;self.db=erp.db

    def _event(self,company,document,event,payload,action=None):
        self.db.execute('INSERT INTO delivery_events(company_id,delivery_id,action_id,event,payload) VALUES(?,?,?,?,?)',(company,document,action,event,encoded(payload)))

    def _local(self,company,document):
        if document['source']!='mydata':return document['id']
        id=self.db.execute('INSERT INTO delivery_documents(company_id,environment,issuer_vat,series,number,issue_date,role,data_json,local_status,aade_status,mark,qr_url) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(company,document['environment'],document['issuer_vat'],document.get('series',''),document.get('number',''),document['issue_date'],document['role'],encoded(document),'imported',document['aade_status'],document['mark'],document.get('qr_url',''))).lastrowid
        self._event(company,id,'mydata_linked',dict(mark=document['mark']))
        return id

    def set_role(self,company,id,role,confirmed=False):
        if confirmed is not True or role not in ('issuer','recipient','carrier'):raise ValueError('Απαιτείται επιβεβαίωση έγκυρου ρόλου.')
        document=self.get(company,id)
        if document['local_status']=='pending':raise ValueError('Υπάρχει ενέργεια σε εξέλιξη.')
        vat=self.db.execute('SELECT vat FROM companies WHERE id=?',(company,)).fetchone()[0]
        expected=document.get('issuer_vat') if role=='issuer' else document.get('recipient_vat')
        if role!='carrier' and (not expected or expected!=vat):raise ValueError('Ο ρόλος δεν αντιστοιχεί στο ΑΦΜ της εγκατάστασης.')
        with self.db:
            id=self._local(company,document);document['role']=role
            self.db.execute('UPDATE delivery_documents SET role=?,data_json=?,updated_at=CURRENT_TIMESTAMP WHERE company_id=? AND id=?',(role,encoded(document),company,id))
            self._event(company,id,'role_selected',dict(role=role))
        return self.get(company,id)

    def reconcile_issue(self,company,id,confirmed=False):
        """Recover an uncertain issue only from an exact official outgoing record.

        Fetching RequestTransmittedDocs is a separate explicit operation. No user
        supplied MARK/QR or network request is used by this local reconciliation.
        """
        if confirmed is not True:raise ValueError('Απαιτείται επιβεβαίωση διασταύρωσης με τις αποθηκευμένες εγγραφές ΑΑΔΕ.')
        if self.db.in_transaction:raise ValueError('Ολοκλήρωσε πρώτα την τοπική αλλαγή.')
        recovery='not_found';message='Δεν βρέθηκε ακριβής εξερχόμενη εγγραφή. Άντλησε πρώτα τα εκδοθέντα της περιόδου από την ΑΑΔΕ και ξανακάνε διασταύρωση.'
        with self.db:
            self.db.execute('BEGIN IMMEDIATE')
            document=self.get(company,id);id=document['id']
            vat=self.db.execute('SELECT vat FROM companies WHERE id=?',(company,)).fetchone()[0]
            actions=[a for a in document['actions'] if a['operation']=='SendInvoices' and a['status'] in ('pending','uncertain')]
            if document.get('mark') or document['local_status'] not in ('pending','uncertain') or document.get('issuer_vat')!=vat or not actions:raise ValueError('Η διασταύρωση αφορά μόνο αβέβαιη έκδοση χωρίς MARK της επιχείρησης εγκατάστασης.')
            matches=[]
            rows=self.db.execute("SELECT r.*,s.method FROM mydata_records r JOIN mydata_syncs s ON s.id=r.last_sync AND s.company_id=r.company_id AND s.environment=r.environment WHERE r.company_id=? AND r.environment=? AND s.method='RequestTransmittedDocs'",(company,document['environment']))
            for row in rows:
                try:item=json.loads(row['record_json'])
                except (ValueError,TypeError):continue
                expected=dict(vat=vat,series=document['series'],number=document['number'],date=document['issue_date'],kind=document.get('invoice_type','9.3'))
                if any(str(item.get(key,''))!=str(value) for key,value in expected.items()):continue
                if item.get('direction','outgoing')!='outgoing':continue
                if document.get('recipient_vat') and item.get('receiver')!=document['recipient_vat']:continue
                if not str(row['mark']).isdigit() or int(row['mark'])<=0 or item.get('mark') and str(item['mark'])!=str(row['mark']):continue
                matches.append((row,item))
            if len(matches)==1:
                row,item=matches[0]
                bound=self.db.execute('SELECT id FROM delivery_documents WHERE company_id=? AND environment=? AND mark=? AND id<>?',(company,document['environment'],row['mark'],id)).fetchone()
                if bound:
                    recovery='ambiguous';message='Το MARK συνδέεται ήδη με άλλο τοπικό δελτίο. Η αβέβαιη έκδοση παραμένει σε έλεγχο.'
                else:
                    recovery='matched';message='Η έκδοση επιβεβαιώθηκε από μία ακριβή εξερχόμενη εγγραφή της ΑΑΔΕ.'
                    self.db.execute("UPDATE delivery_documents SET mark=?,qr_url=?,aade_status=?,local_status='accepted',updated_at=CURRENT_TIMESTAMP WHERE company_id=? AND id=?",(str(row['mark']),item.get('qr_url') or item.get('qrUrl') or '',str(item.get('delivery_status') or ''),company,id))
                    self.db.execute("UPDATE delivery_actions SET status='reconciled' WHERE company_id=? AND delivery_id=? AND operation='SendInvoices' AND status IN ('pending','uncertain')",(company,id))
                    self._event(company,id,'issue_reconciled',dict(mydata_record_id=row['id'],sync_id=row['last_sync'],mark=row['mark'],record=item),actions[-1]['id'])
            elif len(matches)>1:
                recovery='ambiguous';message='Βρέθηκαν περισσότερα από ένα MARK με την ίδια ταυτότητα. Δεν έγινε αυτόματη σύνδεση.'
            if recovery!='matched':self._event(company,id,'issue_reconciliation_unresolved',dict(status=recovery,candidates=[r['id'] for r,_ in matches]))
        result=self.get(company,id);result.update(recovery_status=recovery,recovery_message=message)
        return result

    def get(self,company,id,*,details=True):
        if isinstance(id,str) and id.startswith('mydata:'):
            row=self.db.execute('SELECT * FROM mydata_records WHERE company_id=? AND id=?',(company,id[7:])).fetchone()
            if row is None:raise ValueError('Δεν βρέθηκε δελτίο στην επιχείρηση της εγκατάστασης.')
            data=json.loads(row['record_json'])
            if details:
                from app.infrastructure.aade.delivery_read import read_record
                data.update(read_record(self.erp,row))
            if not (data.get('is_delivery_note') or str(data.get('kind','')).startswith(('9.','10.'))):raise ValueError('Η εγγραφή δεν είναι παραστατικό διακίνησης.')
            local=self.db.execute('SELECT id FROM delivery_documents WHERE company_id=? AND environment=? AND mark=?',(company,row['environment'],row['mark'])).fetchone()
            if local:return self.get(company,local['id'])
            role='recipient' if data.get('direction','incoming')=='incoming' else 'issuer'
            return dict(data,id=id,source='mydata',environment=row['environment'],mark=row['mark'],issue_date=data.get('date',''),reference=str(data.get('series',''))+'/'+str(data.get('number','')),local_status='imported',state='imported',aade_status=data.get('delivery_status',''),role=role,issuer_vat=data.get('vat',''),recipient_vat=data.get('receiver',''),counterpart_vat=data.get('vat','') if role=='recipient' else data.get('receiver',''),counterpart_name=data.get('name',''),qr_url=data.get('qr_url',''),invoice_type=data.get('kind',''),events=[],actions=[])
        row=self.db.execute('SELECT * FROM delivery_documents WHERE company_id=? AND id=?',(company,id)).fetchone()
        if row is None:raise ValueError('Δεν βρέθηκε δελτίο στην επιχείρηση της εγκατάστασης.')
        result=json.loads(row['data_json']);result.update(dict(row));result.pop('data_json',None)
        result.update(source='local',state=row['local_status'],reference=row['series']+'/'+row['number'])
        result['events']=[dict(r,payload=json.loads(r['payload'])) for r in self.db.execute('SELECT * FROM delivery_events WHERE company_id=? AND delivery_id=? ORDER BY id',(company,id))]
        result['actions']=[dict(r) for r in self.db.execute('SELECT * FROM delivery_actions WHERE company_id=? AND delivery_id=? ORDER BY id',(company,id))]
        return result

    def list(self,company,period=None):
        query='SELECT id FROM delivery_documents WHERE company_id=?';args=[company]
        if period:query+=' AND substr(issue_date,1,7)=?';args.append(period)
        rows=[self.get(company,r['id']) for r in self.db.execute(query+' ORDER BY issue_date DESC,id DESC',args)]
        local_marks={(r['environment'],r['mark']) for r in rows if r['mark']}
        for row in self.db.execute('SELECT * FROM mydata_records WHERE company_id=? ORDER BY id DESC',(company,)):
            data=json.loads(row['record_json'])
            if not (data.get('is_delivery_note') or str(data.get('kind','')).startswith(('9.','10.'))):continue
            if (row['environment'],row['mark']) in local_marks:continue
            when=data.get('date','')
            if period and when[:7]!=period:continue
            rows.append(self.get(company,'mydata:'+str(row['id']),details=False))
        return rows

    def save_draft(self,company,data,document_id=None):
        data=dict(data);existing=self.get(company,document_id) if document_id is not None else None
        if existing and (existing['local_status']!='draft' or existing['actions']):raise ValueError('Το δελτίο έχει ήδη ενέργεια ΑΑΔΕ και δεν αλλάζει ως πρόχειρο.')
        environment=data.get('environment','test');role=data.get('role','issuer')
        if environment not in ('test','production') or role not in ('issuer','carrier','recipient'):raise ValueError('Μη έγκυρο περιβάλλον ή ρόλος.')
        date.fromisoformat(data.get('issue_date',''))
        series=str(data.get('series','')).strip()
        if not series:raise ValueError('Συμπλήρωσε σειρά δελτίου.')
        lines=[]
        for n,item in enumerate(data.get('lines',[]),1):
            item=dict(item)
            try:q=Decimal(str(item.get('quantity','')))
            except InvalidOperation:raise ValueError('Μη έγκυρη ποσότητα.') from None
            if not q.is_finite() or q<=0:raise ValueError('Η ποσότητα πρέπει να είναι θετική και πεπερασμένη.')
            item.update(quantity=str(q),line_number=n);lines.append(item)
        data.update(environment=environment,role=role,series=series,lines=lines)
        for key in ('id','company_id','source','state','reference','events','actions','created_at','updated_at','local_status','aade_status'):data.pop(key,None)
        with self.db:
            self.db.execute('INSERT INTO delivery_series VALUES(?,?,?,1) ON CONFLICT DO NOTHING',(company,environment,series))
            number=str(existing['number'] if existing else data.get('number') or self.db.execute('SELECT next_number FROM delivery_series WHERE company_id=? AND environment=? AND series=?',(company,environment,series)).fetchone()[0])
            if not number.isdigit() or int(number)<=0:raise ValueError('Ο αριθμός δελτίου πρέπει να είναι θετικός ακέραιος.')
            number=str(int(number));data['number']=number
            self.db.execute('UPDATE delivery_series SET next_number=max(next_number,?) WHERE company_id=? AND environment=? AND series=?',(int(number)+1,company,environment,series))
            if existing:
                self.db.execute('UPDATE delivery_documents SET environment=?,issuer_vat=?,series=?,number=?,issue_date=?,role=?,data_json=?,updated_at=CURRENT_TIMESTAMP WHERE company_id=? AND id=?',(environment,data.get('issuer_vat',''),series,number,data['issue_date'],role,encoded(data),company,document_id))
            else:
                document_id=self.db.execute('INSERT INTO delivery_documents(company_id,environment,issuer_vat,series,number,issue_date,role,data_json) VALUES(?,?,?,?,?,?,?,?)',(company,environment,data.get('issuer_vat',''),series,number,data['issue_date'],role,encoded(data))).lastrowid
            self._event(company,document_id,'draft_saved',data)
        return self.get(company,document_id)

    def allowed_actions(self,company,id):
        document=self.get(company,id)
        if document['local_status'] in ('uncertain','pending'):return ['GetDeliveryNoteStatus'] if document.get('mark') else []
        if not document.get('mark') and document['local_status'] in ('draft','error'):
            return ['SendInvoices'] if document['role']=='issuer' else []
        actions=['GetDeliveryNoteStatus'];state={'1':'Registered','2':'Cancelled','3':'InTransit','4':'Rejected','5':'DeliveredByCarrier','7':'FailedDelivery','8':'Completed','9':'InTransitReturn'}.get(document['aade_status'],document['aade_status']);role=document['role']
        if role=='issuer' and state=='Registered':actions.append('CancelInvoice')
        if role=='carrier' and state in ('Registered','InTransit','Rejected','InTransitReturn'):actions.append('RegisterTransfer')
        if role=='carrier' and state=='DeliveredByCarrier' and document.get('outcome')=='PARTIAL':actions.append('RegisterTransfer')
        if role=='recipient' and state in ('Registered','InTransit','DeliveredByCarrier'):actions.append('RejectDeliveryNote')
        if role=='issuer' and (state in ('Rejected','FailedDelivery') or state=='DeliveredByCarrier' and document.get('outcome')=='PARTIAL' or state=='InTransit' and (str(document.get('invoice_type',''))=='9.2' or str(document.get('invoice_type',''))=='9.3' and document.get('reverse_delivery'))):actions.append('ConfirmDeliveryReturn')
        if role=='carrier' and state=='InTransit' or role=='recipient' and (state=='InTransit' or state=='DeliveredByCarrier' and document.get('outcome')!='PARTIAL'):actions.append('ConfirmDeliveryOutcome')
        return actions

    def prepare_action(self,company,id,operation,payload=None):
        from app.infrastructure.aade.delivery_client import build_request,build_invoice_xml,validate_xml
        document=self.get(company,id)
        id=document['id']
        if document['local_status'] in ('uncertain','pending') and not document.get('mark'):raise ValueError('Η έκδοση δεν επέστρεψε MARK. Άντλησε τα εκδοθέντα από την ΑΑΔΕ και επίλεξε διασταύρωση έκδοσης· δεν συνδέεται χειροκίνητο MARK.')
        if operation not in self.allowed_actions(company,id):raise ValueError('Η ενέργεια δεν επιτρέπεται για τον ρόλο και την κατάσταση του δελτίου. Κάνε ενημέρωση κατάστασης.')
        payload=dict(payload or {})
        for key,expected in (('mark',document.get('mark')),('invoiceMark',document.get('mark')),('qrUrl',document.get('qr_url'))):
            if expected and key in payload and str(payload[key])!=str(expected):raise ValueError('Το αναγνωριστικό δεν ανήκει στο επιλεγμένο δελτίο.')
        if operation=='SendInvoices':
            vat=self.db.execute('SELECT vat FROM companies WHERE id=?',(company,)).fetchone()[0]
            if document.get('issuer_vat')!=vat:raise ValueError('Ο εκδότης δεν είναι η επιχείρηση της εγκατάστασης.')
            kind=str(document.get('invoice_type','9.3'))
            if kind not in ('9.1','9.2','9.3','10.1','10.2'):raise ValueError('Η διακίνηση εκδίδει μόνο μη αξιακούς τύπους 9.1, 9.2, 9.3, 10.1 και 10.2.')
            if 'xml' not in payload:
                if document.get('original_xml'):payload['xml']=document['original_xml']
                elif kind=='9.3':payload['xml']=build_invoice_xml(document)
                else:raise ValueError('Για τον ειδικό τύπο απαιτείται εισαγωγή πλήρους XML ΑΑΔΕ.')
            # Guard size/DTD before parsing, then validate the official schema.
            root=validate_xml(payload['xml'],'InvoicesDoc-v2.0.2.xsd');ns={'a':'http://www.aade.gr/myDATA/invoice/v1.0'}
            invoices=root.findall('a:invoice',ns)
            if len(invoices)!=1:raise ValueError('Το XML πρέπει να αφορά ένα δελτίο.')
            for path,value in (('a:issuer/a:vatNumber',vat),('a:invoiceHeader/a:series',document['series']),('a:invoiceHeader/a:aa',document['number']),('a:invoiceHeader/a:issueDate',document['issue_date']),('a:invoiceHeader/a:invoiceType',kind)):
                if invoices[0].findtext(path,namespaces=ns)!=str(value):raise ValueError('Το XML δεν αντιστοιχεί στην ταυτότητα του πρόχειρου δελτίου.')
            monetary={'netValue','vatAmount','withheldAmount','feesAmount','stampDutyAmount','otherTaxesAmount','deductionsAmount','taxAmount','amount','tipAmount','underlyingValue'}
            for node in invoices[0].iter():
                name=node.tag.rsplit('}',1)[-1]
                if (name in monetary or name.startswith('total')) and node.text and Decimal(node.text)!=0:raise ValueError('Το δελτίο διακίνησης δεν μπορεί να περιέχει χρηματικές αξίες.')
        elif operation=='GetDeliveryNoteStatus':
            if document.get('mark'):
                payload.setdefault('mark',document['mark'])
                if document.get('issuer_vat'):payload.setdefault('issuerVatNumber',document['issuer_vat'])
            elif document.get('qr_url'):payload.setdefault('qrUrl',document['qr_url'])
        elif operation=='CancelInvoice':payload.setdefault('mark',document['mark'])
        elif operation=='RejectDeliveryNote':payload.setdefault('invoiceMark',document['mark'])
        else:payload.setdefault('qrUrl',document.get('qr_url',''))
        if operation=='ConfirmDeliveryOutcome' and document['role']=='recipient' and payload.get('outcome')!='FULL':raise ValueError('Ο παραλήπτης επιβεβαιώνει μόνο πλήρη παραλαβή.')
        return dict(operation=operation,payload=payload,request=build_request(operation,payload))

    def perform_action(self,company,id,operation,payload=None,client=None,cancel=None,confirmed=False):
        if confirmed is not True:raise ValueError('Απαιτείται ρητή επιβεβαίωση πριν από αποστολή στην ΑΑΔΕ.')
        document=self.get(company,id)
        if document['local_status'] in ('uncertain','pending') and operation!='GetDeliveryNoteStatus':raise ValueError('Η προηγούμενη αποστολή έχει αβέβαιο αποτέλεσμα. Απαιτείται ενημέρωση κατάστασης πριν από νέα αποστολή.')
        preview=self.prepare_action(company,id,operation,payload)
        if cancel and (cancel.is_set() if hasattr(cancel,'is_set') else cancel()):return document
        if client is None:
            from app.infrastructure.aade.delivery_client import DeliveryClient
            credentials=self.erp.mydata_credentials(company,document['environment'])
            client=DeliveryClient(document['environment'],credentials['username'],credentials['key'])
        raw=preview['request'].get('body') or ''
        if isinstance(raw,bytes):raw=raw.decode('utf8')
        if self.db.in_transaction:raise ValueError('Ολοκλήρωσε πρώτα την τοπική αλλαγή πριν από ενέργεια ΑΑΔΕ.')
        with self.db:
            self.db.execute('BEGIN IMMEDIATE')
            id=self._local(company,document)
            current=self.get(company,id)
            if current['local_status'] in ('pending','uncertain') and operation!='GetDeliveryNoteStatus':raise ValueError('Υπάρχει ήδη εκκρεμής ή αβέβαιη ενέργεια. Ενημέρωσε πρώτα την κατάσταση ΑΑΔΕ.')
            action=self.db.execute("INSERT INTO delivery_actions(company_id,delivery_id,operation,status,request_json,raw_request) VALUES(?,?,?,'pending',?,?)",(company,id,operation,encoded(preview['payload']),raw or encoded(preview['request']))).lastrowid
            self.db.execute("UPDATE delivery_documents SET local_status='pending' WHERE company_id=? AND id=?",(company,id))
            self._event(company,id,'action_started',dict(operation=operation),action)
        try:response=client.perform(operation,preview['payload'],cancel=cancel)
        except Exception as error:
            # No automatic retry: after invocation a network error may hide acceptance.
            response=dict(success=False,ambiguous=True,errors=[dict(message=str(error))],raw_xml='')
        if response.get('success') and document.get('mark') and response.get('mark') and str(response['mark'])!=str(document['mark']):
            response=dict(response,success=False,ambiguous=True,mark=document['mark'],status=None,qr_url=None,qrUrl=None,identifiers={},errors=[dict(code='IDENTITY',message='Η απάντηση ΑΑΔΕ αφορά διαφορετικό MARK. Διατηρήθηκε το αρχικό δελτίο.')])
        state='uncertain' if response.get('ambiguous') else 'accepted' if response.get('success') else 'error'
        if operation=='GetDeliveryNoteStatus' and not response.get('success') and document['local_status'] in ('uncertain','pending'):state='uncertain'
        if response.get('cancelled') and not response.get('ambiguous') and not response.get('success'):state=document['local_status']
        aade_status=response.get('status') or (document['aade_status'] if operation=='GetDeliveryNoteStatus' or not response.get('success') else '')
        if not isinstance(aade_status,str):aade_status=encoded(aade_status)
        mark=str(response.get('mark') or document.get('mark') or '')
        qr=response.get('qr_url') or response.get('qrUrl') or response.get('identifiers',{}).get('qrUrl') or document.get('qr_url','')
        stored=json.loads(self.db.execute('SELECT data_json FROM delivery_documents WHERE company_id=? AND id=?',(company,id)).fetchone()[0])
        if response.get('success'):
            if operation=='GetDeliveryNoteStatus':
                stored['outcome']=response.get('outcome')
                stored['lifecycle_history']=response.get('lifecycle_history',[])
            elif operation=='ConfirmDeliveryOutcome':stored['outcome']=preview['payload'].get('outcome')
        with self.db:
            self.db.execute('UPDATE delivery_actions SET status=?,response_json=?,raw_response=?,completed_at=CURRENT_TIMESTAMP WHERE company_id=? AND id=?',(state,encoded(response),response.get('raw_xml',''),company,action))
            self.db.execute('UPDATE delivery_documents SET local_status=?,aade_status=?,mark=?,qr_url=?,data_json=?,updated_at=CURRENT_TIMESTAMP WHERE company_id=? AND id=?',(state,aade_status,mark,qr,encoded(stored),company,id))
            self._event(company,id,'action_'+state,response,action)
        return self.get(company,id)
