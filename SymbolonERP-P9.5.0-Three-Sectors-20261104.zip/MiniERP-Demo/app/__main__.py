import argparse
from pathlib import Path
import os


def main():
    parser = argparse.ArgumentParser(description='Ανεξάρτητο Mini ERP')
    parser.add_argument('--data-dir',type=Path)
    parser.add_argument('--check',action='store_true',help='Initialize/migrate database and report integrity')
    args = parser.parse_args()
    from app.infrastructure.installation import resolve_data_directory,InstallationCancelled,InstallationError
    installation_root=Path(__file__).resolve().parents[1]
    if args.check:
        from app.application.service import ERP
        directory=args.data_dir if args.data_dir is not None else resolve_data_directory(installation_root)
        service = ERP(directory)
        print('SQLite integrity:',service.db.execute('PRAGMA integrity_check').fetchone()[0])
        service.close()
    else:
        import tkinter as tk
        from app.ui.desktop import Desktop
        from app.ui.dpi import enable
        enable()
        root = tk.Tk()
        root.withdraw()
        from app.ui.installation import choose_legacy
        try:
            directory=args.data_dir if args.data_dir is not None else resolve_data_directory(installation_root,choose_legacy=lambda path:choose_legacy(path,parent=root))
        except InstallationCancelled:
            root.destroy();return
        except (InstallationError,OSError) as exc:
            from tkinter import messagebox
            messagebox.showerror('Εκκίνηση',str(exc),parent=root);root.destroy();return
        root.deiconify()
        def callback_error(kind,error,tb):
            from app.infrastructure.crashlog import record
            from tkinter import messagebox
            record(directory,error.with_traceback(tb),'callback')
            messagebox.showerror('Σφάλμα εφαρμογής','Αποθηκεύτηκε διαγνωστικό. Ρυθμίσεις → Υποστήριξη → Αποθήκευση crashlog.',parent=root)
        root.report_callback_exception=callback_error
        Desktop(root,directory)
        try:
            root.mainloop()
        except tk.TclError:
            pass

if __name__ == '__main__':
    main()
