# Navigation icons

Receipt, chart-line-up and truck-side: Flaticon UIcons, Regular Rounded.
Created by Flaticon: https://www.flaticon.com/uicons
Distributed as locally rendered PNGs with author attribution under the Flaticon
free license. No runtime font, download or external service is required.

Source package: @flaticon/flaticon-uicons (regular/rounded.css and referenced
regular-rounded font), retrieved 2026-11-03 from jsDelivr.
https://www.flaticon.com/legal
