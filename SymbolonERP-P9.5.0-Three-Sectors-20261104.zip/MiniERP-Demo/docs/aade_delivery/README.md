# Official AADE delivery protocol — checked 2026-11-03

This folder ships the unmodified XSD files from the official v2.0.2 ZIP:
https://www.aade.gr/sites/default/files/2026-09/v2.0.2XSDs_0.zip

Official index: https://www.aade.gr/mydata/tehnikes-prodiagrafes-ekdoseis-mydata

Delivery REST specification (September 2026):
https://www.aade.gr/sites/default/files/2026-09/myDATA%20API%20Documentation_DeliveryNote_v2.0.2_official_0.pdf

ERP specification (September 2026), SendInvoices §4.2.1 and CancelInvoice §4.2.5:
https://www.aade.gr/sites/default/files/2026-09/myDATA%20API%20Documentation%20v2.0.2_official_erp_1.pdf

Legal amendment A.1233/30.10.2026:
https://www.aade.gr/sites/default/files/2026-11/A1233_2026fek.pdf

The technical version is not proof of all production activation dates. The legal
amendment ties technical compliance to production activation, not merely the PDF
publication date. No live AADE calls were made to verify this implementation.

## Boundary and small implementation plan

Keep the established read-only acquisition client unchanged. The new
`app.infrastructure.aade.delivery_client` builds and validates explicit requests,
sends each request once, then normalizes the response. Persistence, identity,
authorization, operation confirmation and action history belong to the delivery
service. They are not inferred from the HTTP client.

1. Offline requests validated against the bundled official XSD.
2. Mock HTTP tests for business errors, identifiers, cancellation, ambiguity.
3. Service integration and targeted tests for state/role/action journaling.
4. Separately recorded official sandbox acceptance before claiming live operation.

## Public contract

`DeliveryClient(environment, username, key, transport=None).perform(operation,
payload, *, cancel=None)` returns:

`success`, `errors` (list of code/message dictionaries), `raw_xml`, `mark`
(invoice MARK), `status` (actual AADE status, possibly None), `qr_url`,
`identifiers`, `ambiguous`, `cancelled`, `outcome` (last actual outcome event or
None), `lifecycle_history` (event fields plus raw event XML).

`build_request(operation,payload)` returns `{method,path,body}` without network
I/O. `body` is UTF-8 XML bytes or None. Invalid local requests raise ValueError
before sending. `build_invoice_xml(data)` produces a schema-validated ordinary
9.3 non-monetary draft from the UI/service flat shape. Other allowed delivery
types 9.1/9.2/10.1/10.2 can be supplied as complete validated XML. No monetary
invoice issuance endpoint is exposed through this client.

Injection contract: transport(Request, timeout=30) -> bytes or context-managed
HTTP response. URLs always use fixed official bases. Redirects are not followed.
No credentials are included in reports or persisted request previews.

## Payload fields (AADE camelCase)

* SendInvoices: `{xml: str|bytes}`, one delivery invoice only.
* CancelInvoice: `{mark, entityVatNumber?}`; POST, query, no body.
* GetDeliveryNoteStatus: `{mark,issuerVatNumber?}` OR `{qrUrl}`; GET.
* RegisterTransfer: `{qrUrl,transportDetail:{vehicleNumber,transportType,
  timeStamp?,carrierVatNumber,pNumber?,location?:{longitude,latitude},
  packingsDeclaration?:[packaging]}}`.
* ConfirmDeliveryOutcome: `{qrUrl,outcome,deliveredWithoutRecipient?,
  deliveredPackaging?:[packaging]}`. outcome FULL/PARTIAL/NONE; PARTIAL requires
  delivered packaging and is only permitted for the participating carrier.
* RejectDeliveryNote: `{qrUrl OR invoiceMark,rejectionReason?}`.
* ConfirmDeliveryReturn: `{qrUrl}`.
* GenerateGroupQRCode: `{qrUrls:[str,str,...]}` (at least two).
* RequestGroupQRDetails: `{groupId}`; GET.

Packaging: `{packagingType:int1..6,quantity:int,otherPackagingTypeTitle?:str}`.
Transport type 1 public-use truck, 2 private-use truck, 3 ship, 4 train, 5 aircraft,
6 other, 7 none. Packaging type 1 pallet, 2 box, 3 crate, 4 barrel, 5 bag, 6 other.
Use decimal strings/Decimal, not floats. The XSD determines order and types;
packaging quantities are integers, item quantities are decimal.

Ordinary draft fields: series,number,issue_date,issuer_vat,
counterpart_vat/recipient_vat,dispatch_date,dispatch_time,movement_purpose,
vehicle_number,loading_address/delivery_address
{street,number,postal_code,city,country?,branch?},
lines:[{line_number?,description,quantity,measurement_unit?,item_code?}],
correlated_marks?. Dates ISO, times ISO; postal_code/city required by XSD.
The builder emits zero monetary amounts, VAT category8, no classifications.
Schema validation is not a substitute for AADE business validation or legal
eligibility; the service must not claim remote acceptance before a response.

## State and role authority

Status values:1 Registered,2 Cancelled,3 InTransit,4 Rejected,
5 DeliveredByCarrier,7 FailedDelivery,8 Completed,9 InTransit(Return).
The normative transitions and special return conditions are the delivery PDF
§1.2/§3.2 tables. Roles issuer/carrier/recipient belong to the current installed
business. PARTIAL/NONE must not be offered as recipient confirmation.

## Failure handling

HTTP200 may contain ValidationError/XMLSyntaxError/TechnicalError. A write success
requires Success and the operation-specific identifier. Ambiguous transport,
HTTP5xx or malformed write responses are not retried. Refresh/read evidence first.
Pre-cancellation sends nothing. Cancellation during a blocking HTTP call waits
for that one request (30s timeout); a known success is preserved, never discarded.
Unknown/empty status responses are not reported as successful.
