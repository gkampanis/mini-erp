import copy
import json
from pathlib import Path
import tempfile
import unittest

from app.application.service import ERP
from app.application.mydata import MyData
from app.infrastructure.aade.client import APIError, parsed_page, unique_pages
from tests.test_workflow import response


def delivery_xml(status):
    return response().replace(b'</invoice>', ('<invoiceDeliveryStatus>'+status+'</invoiceDeliveryStatus><deliveryLifecycle><status>'+status+'</status></deliveryLifecycle></invoice>').encode())


class DeliveryImportUpdateTests(unittest.TestCase):
    def test_newer_metadata_on_later_page_retains_all_raw_pages_and_events(self):
        old,new=delivery_xml('1'),delivery_xml('8')
        pages=[(old,parsed_page(old)),(new,parsed_page(new))]
        pages[0][1]['cancellations']=['999']
        original=copy.deepcopy(pages)
        result=unique_pages(pages)
        self.assertEqual([p[0] for p in result],[old,new])
        self.assertEqual(sum(len(p[1]['records']) for p in result),1)
        record=next(r for _,p in result for r in p['records'])
        self.assertEqual(record['delivery_status'],'8')
        self.assertIn('8',record['delivery_lifecycle'])
        self.assertEqual(result[0][1]['cancellations'],['999'])
        self.assertEqual(pages,original)

    def test_repeated_mark_in_one_xml_accepts_metadata_update(self):
        import xml.etree.ElementTree as ET
        root=ET.fromstring(delivery_xml('1'))
        newer=ET.fromstring(delivery_xml('8'))
        root[0].append(newer[0][0])
        page=parsed_page(ET.tostring(root))
        self.assertEqual(len(page['records']),1)
        self.assertEqual(page['records'][0]['delivery_status'],'8')

    def test_financial_and_identity_conflicts_still_fail(self):
        old=parsed_page(delivery_xml('1'))
        for key,value in [('net','2'),('kind','2.1'),('vat','000000099'),
                          ('receiver','000000099'),('date','2026-10-20'),
                          ('correlated_marks',['777']),('number','99'),
                          ('detail_analysis',None)]:
            with self.subTest(key=key):
                changed=copy.deepcopy(old);changed['records'][0][key]=value
                with self.assertRaises(APIError):unique_pages([(b'old',old),(b'new',changed)])

    def test_same_page_financial_conflict_is_not_hidden_by_metadata_refresh(self):
        import xml.etree.ElementTree as ET
        changes=[(b'<totalNetValue>0.10',b'<totalNetValue>0.20'),
                 (b'<netValue>0.10',b'<netValue>0.20'),
                 (b'<invoiceType>1.1',b'<invoiceType>2.1'),
                 (b'<issueDate>2026-10-21',b'<issueDate>2026-10-20'),
                 (b'<vatNumber>000000001',b'<vatNumber>000000099'),
                 (b'</invoiceHeader>',b'<correlatedInvoices>777</correlatedInvoices></invoiceHeader>')]
        for before,after in changes:
            with self.subTest(before=before):
                root=ET.fromstring(delivery_xml('1'))
                root[0].append(ET.fromstring(delivery_xml('8').replace(before,after))[0][0])
                with self.assertRaises(APIError):parsed_page(ET.tostring(root))

    def test_persistence_keeps_latest_metadata_and_both_xml_sources(self):
        with tempfile.TemporaryDirectory() as temp:
            erp=ERP(Path(temp)/'data');company=erp.company('000000000','Synthetic')
            try:
                pages=[(raw,parsed_page(raw)) for raw in (delivery_xml('1'),delivery_xml('8'))]
                MyData(erp).persist(company,'production','2026-10-01','2026-10-31',pages)
                row=erp.db.execute('SELECT record_json FROM mydata_records').fetchone()
                self.assertEqual(json.loads(row[0])['delivery_status'],'8')
                self.assertEqual(erp.db.execute('SELECT count(*) FROM mydata_pages').fetchone()[0],2)
                raw=delivery_xml('3')
                MyData(erp).persist(company,'production','2026-10-01','2026-10-31',[(raw,parsed_page(raw))])
                row=erp.db.execute('SELECT record_json FROM mydata_records').fetchone()
                self.assertEqual(json.loads(row[0])['delivery_status'],'3')
                self.assertEqual(erp.db.execute('SELECT count(*) FROM mydata_records').fetchone()[0],1)
                self.assertEqual(erp.db.execute('SELECT count(*) FROM mydata_pages').fetchone()[0],3)
            finally:erp.close()
