import tempfile
import unittest
from app.application.service import ERP
from app.application.delivery import DeliveryService
from app.application.delivery_groups import DeliveryGroupsService


class DeliveryGroupsTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.erp=ERP(self.temp.name)
        self.company=self.erp.company('000000001','Synthetic');self.service=DeliveryGroupsService(self.erp)
    def tearDown(self):self.erp.close();self.temp.cleanup()
    def doc(self,environment='test',role='issuer',company=None):
        company=company or self.company
        result=DeliveryService(self.erp).save_draft(company,dict(environment=environment,role=role,series='DA',issue_date='2026-11-03',issuer_vat='000000001',lines=[]))
        with self.erp.db:self.erp.db.execute("UPDATE delivery_documents SET mark=?,qr_url=?,aade_status='1',local_status='accepted' WHERE id=?",(str(result['id']),'https://example.test/qr/'+str(result['id']),result['id']))
        return result['id']
    def test_preview_is_offline_and_requires_two_same_environment(self):
        first=self.doc();second=self.doc()
        prepared=self.service.prepare_generate(self.company,[first,second])
        self.assertEqual(prepared['operation'],'GenerateGroupQRCode')
        self.assertEqual(len(prepared['payload']['qrUrls']),2)
        self.assertEqual(self.erp.db.execute('SELECT count(*) FROM delivery_groups').fetchone()[0],0)
        with self.assertRaises(ValueError):self.service.prepare_generate(self.company,[first])
        with self.assertRaises(ValueError):self.service.prepare_generate(self.company,[first,self.doc(environment='production')])
    def test_company_role_and_missing_qr_are_checked(self):
        first=self.doc();second=self.doc(role='recipient')
        with self.assertRaises(ValueError):self.service.prepare_generate(self.company,[first,second])
        other=self.erp.company('000000003','Other');foreign=self.doc(company=other)
        with self.assertRaises(ValueError):self.service.prepare_generate(self.company,[first,foreign])
        with self.erp.db:self.erp.db.execute("UPDATE delivery_documents SET qr_url='' WHERE id=?",(first,))
        with self.assertRaises(ValueError):self.service.prepare_generate(self.company,[first,self.doc()])
    def test_generation_durable_before_network_and_details_retained(self):
        ids=[self.doc(),self.doc()]
        class Client:
            def perform(inner,operation,payload,**kwargs):
                self.assertFalse(self.erp.db.in_transaction)
                self.assertEqual(self.erp.db.execute('SELECT status FROM delivery_group_actions ORDER BY id DESC').fetchone()[0],'pending')
                return dict(success=True,identifiers={'groupQrUrl':'https://example.test/group?groupId=abc','expiresAt':'2026-11-04T10:00:00'},raw_xml='<group/>')
        result=self.service.generate(self.company,ids,client=Client(),confirmed=True)
        self.assertEqual(result['remote_group_id'],'abc');self.assertEqual(result['status'],'accepted')
        self.assertEqual(len(result['actions']),1)
        class Lookup:
            def perform(inner,operation,payload,**kwargs):
                self.assertEqual(payload,{'groupId':'abc'})
                return dict(success=True,identifiers={'groupId':'abc','expiresAt':'2026-11-05T10:00:00'},raw_xml='<details/>')
        refreshed=self.service.refresh_details(self.company,result['id'],client=Lookup(),confirmed=True)
        self.assertEqual(refreshed['expires_at'],'2026-11-05T10:00:00');self.assertEqual(len(refreshed['actions']),2)
    def test_timeout_is_not_retried_and_confirmation_precedes_write(self):
        ids=[self.doc(),self.doc()]
        with self.assertRaises(ValueError):self.service.generate(self.company,ids,client=object())
        class Client:
            calls=0
            def perform(inner,*args,**kwargs):inner.calls+=1;raise TimeoutError()
        client=Client();result=self.service.generate(self.company,ids,client=client,confirmed=True)
        self.assertEqual(client.calls,1);self.assertEqual(result['status'],'uncertain')
        self.assertEqual(result['actions'][0]['status'],'uncertain')
    def test_detail_response_cannot_switch_bound_group(self):
        ids=[self.doc(),self.doc()]
        class Client:
            def perform(inner,*args,**kwargs):return dict(success=True,identifiers={'groupQrUrl':'https://example.test/?groupId=abc'},raw_xml='<group/>')
        group=self.service.generate(self.company,ids,client=Client(),confirmed=True)
        class Wrong:
            def perform(inner,*args,**kwargs):return dict(success=True,identifiers={'groupId':'different'},raw_xml='<wrong/>')
        result=self.service.refresh_details(self.company,group['id'],client=Wrong(),confirmed=True)
        self.assertEqual(result['remote_group_id'],'abc');self.assertEqual(result['actions'][-1]['status'],'error')

    def test_missing_credentials_does_not_leave_pending_orphan(self):
        from unittest.mock import patch
        with patch.object(self.erp,'mydata_credentials',side_effect=ValueError('Missing credentials')):
            with self.assertRaises(ValueError):self.service.generate(self.company,[self.doc(),self.doc()],confirmed=True)
        self.assertEqual(self.erp.db.execute('SELECT count(*) FROM delivery_groups').fetchone()[0],0)

    def test_precancel_creates_nothing_and_never_calls_client(self):
        import threading
        cancel=threading.Event();cancel.set()
        result=self.service.generate(self.company,[self.doc(),self.doc()],client=object(),cancel=cancel,confirmed=True)
        self.assertIsNone(result)
        self.assertEqual(self.erp.db.execute('SELECT count(*) FROM delivery_groups').fetchone()[0],0)


if __name__=='__main__':unittest.main()
