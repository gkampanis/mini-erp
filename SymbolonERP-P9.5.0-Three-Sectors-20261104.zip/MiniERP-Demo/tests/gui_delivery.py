"""Synthetic, operator-facing delivery draft and explicit-send boundaries."""
import unittest
from unittest.mock import patch
from tests import gui_regressions as harness


class DeliveryWorkspaceTests(unittest.TestCase):
    setUpClass=classmethod(harness.DesktopRegressions.setUpClass.__func__)
    tearDownClass=classmethod(harness.DesktopRegressions.tearDownClass.__func__)
    setUp=harness.DesktopRegressions.setUp
    tearDown=harness.DesktopRegressions.tearDown

    def test_draft_quantities_persist_without_expense_or_network_writes(self):
        ui=self.app.delivery_workspace
        editor=ui.new_draft()
        editor.values['counterpart_vat'].set('000000002')
        editor.values['counterpart_name'].set('Synthetic recipient')
        editor.lines.append(dict(description='Synthetic goods',quantity='1.250',measurement_unit=1))
        with patch('app.infrastructure.aade.delivery_client.DeliveryClient.perform') as remote:
            saved=editor.save();remote.assert_not_called()
        self.assertEqual(saved['lines'][0]['quantity'],'1.250')
        self.assertEqual(self.app.erp.db.execute('SELECT count(*) FROM documents').fetchone()[0],0)
        self.assertIn(str(saved['id']),ui.tree.get_children())
        self.assertEqual(ui.rows[str(saved['id'])]['environment'],'test')

    def test_sector_acquisition_chooses_outgoing_only_for_income(self):
        with patch('app.ui.aade_dialog.open_settings') as acquire:
            self.app.navigation.choose('income');self.root.update();self.app.open_acquisition()
            self.assertEqual(acquire.call_args.kwargs['direction'],'outgoing')
            self.app.navigation.choose('expenses');self.root.update();self.app.open_acquisition()
            self.assertEqual(acquire.call_args.kwargs['direction'],'incoming')

    def test_preview_and_cancel_never_start_network(self):
        ui=self.app.delivery_workspace;editor=ui.new_draft()
        editor.values['counterpart_vat'].set('000000002')
        editor.lines.append(dict(description='Goods',quantity='1',measurement_unit=1))
        row=editor.save();ui.tree.selection_set(str(row['id']))
        with patch('app.application.delivery.DeliveryService.prepare_action',return_value={'request':{'method':'POST','path':'SendInvoices','body':b'<synthetic/>'}}),patch('app.infrastructure.aade.delivery_client.DeliveryClient.perform') as remote:
            window=ui.action('SendInvoices')
            self.assertTrue(window.winfo_exists());window.destroy();remote.assert_not_called()
        self.assertEqual(self.app.erp.db.execute('SELECT count(*) FROM delivery_actions').fetchone()[0],0)

    def test_special_xml_import_is_local_and_keeps_exact_92_document(self):
        from app.infrastructure.aade.delivery_client import build_invoice_xml
        from tests.gui_smoke import widgets
        from tkinter import ttk
        data=dict(series='XML',number='1',issue_date='2026-11-03',issuer_vat='000000000',counterpart_vat='000000002',
                  loading_address=dict(postal_code='11111',city='Athens'),delivery_address=dict(postal_code='22222',city='Athens'),
                  lines=[dict(description='Goods',quantity='2.500',measurement_unit=1)])
        xml=build_invoice_xml(data).replace('>9.3<','>9.2<')
        path=self.folder/'special.xml';path.write_bytes(xml.encode('utf8'))
        with patch('app.ui.delivery.filedialog.askopenfilename',return_value=str(path)),patch('app.infrastructure.aade.delivery_client.DeliveryClient.perform') as remote:
            win=self.app.delivery_workspace.import_xml()
            next(w for w in widgets(win) if isinstance(w,ttk.Button) and w.cget('text')=='Αποθήκευση πρόχειρου μόνο').invoke()
            remote.assert_not_called()
        row=next(iter(self.app.delivery_workspace.rows.values()))
        self.assertEqual(row['invoice_type'],'9.2');self.assertEqual(row['original_xml'],xml)
        self.assertEqual(row['lines'][0]['quantity'],'2.500')
        self.assertEqual(self.app.erp.db.execute('SELECT count(*) FROM documents').fetchone()[0],0)


if __name__=='__main__':unittest.main()
