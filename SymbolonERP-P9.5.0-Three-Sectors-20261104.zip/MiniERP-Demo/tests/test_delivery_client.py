import threading
import unittest
from decimal import Decimal
from app.infrastructure.aade.delivery_client import DeliveryClient, build_request, build_invoice_xml


class DeliveryClientTests(unittest.TestCase):
    def test_status_choice_and_encoded_query(self):
        request=build_request('GetDeliveryNoteStatus',{'qrUrl':'https://example.test/?a=1&b=2'})
        self.assertEqual(request['method'],'GET')
        self.assertIn('%26b%3D2',request['path'])
        with self.assertRaises(ValueError):build_request('GetDeliveryNoteStatus',{'mark':'1','qrUrl':'x'})

    def test_official_transport_order_and_decimal(self):
        request=build_request('RegisterTransfer',{'qrUrl':'https://example.test/qr','transportDetail':{'vehicleNumber':'ABC','transportType':2,'carrierVatNumber':'000000000','location':{'longitude':Decimal('23.700'),'latitude':Decimal('37.9')}}})
        self.assertIn(b'<longitude>23.700</longitude>',request['body'])
        self.assertIn(b'<Transport>',request['body'])

    def test_bad_outcome_and_incomplete_packaging_are_rejected(self):
        with self.assertRaises(ValueError):build_request('ConfirmDeliveryOutcome',{'qrUrl':'x','outcome':'YES'})
        with self.assertRaises(ValueError):build_request('ConfirmDeliveryOutcome',{'qrUrl':'x','outcome':'PARTIAL'})

    def test_http_200_business_error_is_not_success(self):
        calls=[]
        def transport(request,timeout):
            calls.append(request)
            return b'<ResponseDoc><response><errors><error><message>Not allowed</message><code>800</code></error></errors><statusCode>ValidationError</statusCode></response></ResponseDoc>'
        result=DeliveryClient('test','demo','secret',transport).perform('ConfirmDeliveryReturn',{'qrUrl':'x'})
        self.assertFalse(result['success']);self.assertEqual(result['errors'][0]['code'],'800')
        self.assertEqual(len(calls),1);self.assertEqual(calls[0].host,'mydataapidev.aade.gr')

    def test_timeout_is_ambiguous_and_never_retried(self):
        calls=[]
        def transport(request,timeout):calls.append(1);raise TimeoutError('timeout')
        result=DeliveryClient('production','demo','secret',transport).perform('CancelInvoice',{'mark':'42'})
        self.assertTrue(result['ambiguous']);self.assertFalse(result['success']);self.assertEqual(len(calls),1)

    def test_pre_cancel_never_calls_transport(self):
        cancelled=threading.Event();cancelled.set()
        def transport(*args,**kwargs):self.fail('Must not send')
        result=DeliveryClient('test','demo','secret',transport).perform('CancelInvoice',{'mark':'42'},cancel=cancelled)
        self.assertTrue(result['cancelled']);self.assertFalse(result['ambiguous'])

    def test_success_identifiers_and_status_response(self):
        def transport(request,timeout):return b'<ResponseDoc><response><invoiceMark>42</invoiceMark><qrUrl>x</qrUrl><deliveryReturnMark>99</deliveryReturnMark><statusCode>Success</statusCode></response></ResponseDoc>'
        result=DeliveryClient('test','demo','secret',transport).perform('ConfirmDeliveryReturn',{'qrUrl':'x'})
        self.assertTrue(result['success']);self.assertEqual(result['mark'],'42')
        def status(request,timeout):return b'<GetDeliveryNoteStatusResponse><invoiceMark>42</invoiceMark><status>3</status><dispatchTimestamp>2026-11-03T10:00:00</dispatchTimestamp></GetDeliveryNoteStatusResponse>'
        result=DeliveryClient('test','demo','secret',status).perform('GetDeliveryNoteStatus',{'mark':'42'})
        self.assertTrue(result['success']);self.assertEqual(result['status'],'3')

    def test_invoice_xml_needs_real_schema_and_single_delivery(self):
        with self.assertRaises(ValueError):build_request('SendInvoices',{'xml':'<InvoicesDoc/>'})

    def test_normal_draft_builds_valid_non_monetary_93(self):
        data={'series':'DA','number':'1','issue_date':'2026-11-03','issuer_vat':'000000000','recipient_vat':'111111111',
          'dispatch_date':'2026-11-03','dispatch_time':'10:00:00','movement_purpose':1,'vehicle_number':'ABC',
          'loading_address':{'street':'One','number':'1','postal_code':'10000','city':'Athens'},
          'delivery_address':{'street':'Two','number':'2','postal_code':'20000','city':'Athens'},
          'lines':[{'description':'Item','quantity':'1.250','measurement_unit':1}]}
        xml=build_invoice_xml(data)
        request=build_request('SendInvoices',{'xml':xml})
        self.assertIn(b'1.250',request['body']);self.assertNotIn(b'<currency>',request['body'])
        self.assertNotIn(b'classification',request['body'])

    def test_other_movement_purpose_requires_and_preserves_title(self):
        data={'series':'DA','number':'1','issue_date':'2026-11-03','issuer_vat':'000000000','recipient_vat':'111111111',
          'movement_purpose':19,'loading_address':{'postal_code':'10000','city':'Athens'},'delivery_address':{'postal_code':'20000','city':'Athens'},
          'lines':[{'description':'Item','quantity':'1','measurement_unit':1}]}
        with self.assertRaises(ValueError):build_invoice_xml(data)
        data['other_movement_purpose']='Special movement'
        self.assertIn('otherMovePurposeTitle',build_invoice_xml(data))
        for purpose in (6,15,16,17,18):
            data['movement_purpose']=purpose
            with self.assertRaises(ValueError):build_invoice_xml(data)

    def test_all_lifecycle_shapes_pass_official_xsd(self):
        cases={'RejectDeliveryNote':{'invoiceMark':'42','rejectionReason':'No'},
          'ConfirmDeliveryReturn':{'qrUrl':'x'},'ConfirmDeliveryOutcome':{'qrUrl':'x','outcome':'PARTIAL','deliveredPackaging':[{'packagingType':2,'quantity':1}]},
          'GenerateGroupQRCode':{'qrUrls':['x','y']}}
        for operation,payload in cases.items():
            with self.subTest(operation=operation):self.assertIsInstance(build_request(operation,payload)['body'],bytes)

    def test_unknown_fields_and_entities_rejected(self):
        with self.assertRaises(ValueError):build_request('ConfirmDeliveryReturn',{'qrUrl':'x','secret':'y'})
        with self.assertRaises(ValueError):build_request('SendInvoices',{'xml':'<!DOCTYPE x [<!ENTITY y SYSTEM "file:///secret">]><x>&y;</x>'})

    def test_invalid_response_after_write_is_ambiguous(self):
        result=DeliveryClient('test','demo','secret',lambda request,timeout:b'broken').perform('CancelInvoice',{'mark':'42'})
        self.assertFalse(result['success']);self.assertTrue(result['ambiguous'])

    def test_redirect_does_not_leak_headers_or_retry(self):
        import urllib.error
        calls=[]
        def transport(request,timeout):
            calls.append(request)
            raise urllib.error.HTTPError(request.full_url,302,'redirect',{'Location':'https://evil.test'},None)
        result=DeliveryClient('test','demo','secret',transport).perform('CancelInvoice',{'mark':'42'})
        self.assertFalse(result['success']);self.assertEqual(len(calls),1)
        self.assertEqual(result['errors'][0]['code'],'HTTP_302')

    def test_empty_status_and_no_identifier_write_are_not_success(self):
        for operation,payload,xml in [('GetDeliveryNoteStatus',{'mark':'42'},b'<GetDeliveryNoteStatusResponse/>'),('CancelInvoice',{'mark':'42'},b'<ResponseDoc><response><statusCode>Success</statusCode></response></ResponseDoc>')]:
            with self.subTest(operation=operation):
                result=DeliveryClient('test','demo','secret',lambda request,timeout:xml).perform(operation,payload)
                self.assertFalse(result['success'])

    def test_status_exposes_actual_last_outcome_and_history(self):
        xml=b'<GetDeliveryNoteStatusResponse><invoiceMark>42</invoiceMark><status>5</status><dispatchTimestamp>2026-11-03T10:00:00</dispatchTimestamp><lifecycleHistory><eventType>ConfirmOutcome</eventType><eventTimestamp>2026-11-03T11:00:00</eventTimestamp><actorVat>000000000</actorVat><outcomeDetails><outcome>PARTIAL</outcome></outcomeDetails></lifecycleHistory></GetDeliveryNoteStatusResponse>'
        result=DeliveryClient('test','demo','secret',lambda request,timeout:xml).perform('GetDeliveryNoteStatus',{'mark':'42'})
        self.assertEqual(result['outcome'],'PARTIAL')
        self.assertEqual(result['lifecycle_history'][0]['eventType'],'ConfirmOutcome')


if __name__=='__main__':unittest.main()
