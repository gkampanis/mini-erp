import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from app.application.service import ERP
from app.application.delivery import DeliveryService
from app.infrastructure.aade.delivery_read import read_record,extract_delivery

XML=b'''<RequestedDoc xmlns="http://www.aade.gr/myDATA/invoice/v1.0"><invoicesDoc><invoice><mark>1234</mark><issuer><vatNumber>000000002</vatNumber><country>GR</country><branch>2</branch></issuer><counterpart><vatNumber>000000001</vatNumber><country>GR</country><branch>0</branch></counterpart><invoiceHeader><series>DA</series><aa>5</aa><issueDate>2026-11-03</issueDate><invoiceType>9.3</invoiceType><dispatchDate>2026-11-03</dispatchDate><dispatchTime>10:30:00</dispatchTime><vehicleNumber>ABC</vehicleNumber><movePurpose>1</movePurpose><otherDeliveryNoteHeader><loadingAddress><street>A</street><number>1</number><postalCode>10000</postalCode><city>Athens</city></loadingAddress><deliveryAddress><street>B</street><number>2</number><postalCode>20000</postalCode><city>Patra</city></deliveryAddress><startShippingBranch>2</startShippingBranch></otherDeliveryNoteHeader></invoiceHeader><invoiceDetails><lineNumber>1</lineNumber><itemCode>X</itemCode><itemDescr>Goods</itemDescr><quantity>1.2500</quantity><measurementUnit>2</measurementUnit><netValue>0</netValue><vatCategory>8</vatCategory><vatAmount>0</vatAmount></invoiceDetails><qrCodeUrl>https://example.test/qr</qrCodeUrl></invoice></invoicesDoc></RequestedDoc>'''


class DeliveryReadTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.erp=ERP(self.temp.name);self.company=self.erp.company('000000001','Synthetic')
    def tearDown(self):self.erp.close();self.temp.cleanup()
    def archive(self,xml=XML,environment='test',page_company=None):
        company=page_company or self.company
        digest=hashlib.sha256(xml).hexdigest();path=Path(self.temp.name)/'mydata'/'xml'/(digest+'.xml');path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(xml)
        with self.erp.db:
            sync=self.erp.db.execute("INSERT INTO mydata_syncs(company_id,environment,method,date_from,date_to,report) VALUES(?,?,'RequestDocs','2026-11-01','2026-11-30','{}')",(company,environment)).lastrowid
            self.erp.db.execute('INSERT INTO mydata_pages(sync_id,sha256,storage_path) VALUES(?,?,?)',(sync,digest,path.relative_to(self.temp.name).as_posix()))
        return sync,path
    def record(self,sync,environment='test',mark='1234'):
        data=dict(kind='9.3',is_delivery_note=True,date='2026-11-03',series='DA',number='5',vat='000000002',receiver='000000001',direction='incoming')
        with self.erp.db:
            id=self.erp.db.execute("INSERT INTO mydata_records(company_id,environment,mark,record_json,match_status,last_sync,invoice_type,is_delivery_note) VALUES(?,?,?,?, 'unmatched',?,'9.3',1)",(self.company,environment,mark,json.dumps(data),sync)).lastrowid
        return self.erp.db.execute('SELECT * FROM mydata_records WHERE id=?',(id,)).fetchone()
    def test_exact_mark_quantities_addresses_and_transport_are_preserved(self):
        sync,path=self.archive();row=self.record(sync);data=read_record(self.erp,row)
        self.assertEqual(data['lines'][0]['quantity'],'1.2500');self.assertEqual(data['loading_address']['branch'],2)
        self.assertEqual(data['delivery_address']['city'],'Patra');self.assertEqual(data['vehicle_number'],'ABC')
        self.assertEqual(data['qr_url'],'https://example.test/qr');self.assertEqual(data['dispatch_time'],'10:30:00')
        imported=DeliveryService(self.erp).get(self.company,'mydata:'+str(row['id']))
        self.assertEqual(imported['lines'][0]['description'],'Goods')
        self.assertEqual(self.erp.db.execute('SELECT count(*) FROM documents').fetchone()[0],0)
    def test_other_mark_is_never_used(self):
        self.assertIsNone(extract_delivery(XML,'9999'))
    def test_environment_company_and_hash_are_scoped(self):
        sync,path=self.archive(environment='production');row=self.record(sync,environment='test')
        self.assertNotIn('lines',read_record(self.erp,row))
        with self.erp.db:self.erp.db.execute("UPDATE mydata_records SET environment='production' WHERE id=?",(row['id'],))
        row=self.erp.db.execute('SELECT * FROM mydata_records WHERE id=?',(row['id'],)).fetchone();path.write_bytes(b'<tampered/>')
        self.assertIn('delivery_read_issue',read_record(self.erp,row))
    def test_foreign_sync_and_path_escape_are_rejected(self):
        other=self.erp.company('000000003','Other');sync,path=self.archive(page_company=other);row=self.record(sync)
        self.assertNotIn('lines',read_record(self.erp,row))
        sync,path=self.archive();row=self.record(sync,mark='4321')
        with self.erp.db:self.erp.db.execute("UPDATE mydata_pages SET storage_path='../outside.xml' WHERE sync_id=?",(sync,))
        self.assertIn('delivery_read_issue',read_record(self.erp,row))
    def test_xml_entities_and_conflicting_same_mark_are_rejected(self):
        with self.assertRaises(ValueError):extract_delivery(b'<!DOCTYPE x [<!ENTITY z "bad">]><x>&z;</x>','1234')
        duplicate=XML.replace(b'</invoicesDoc>',XML[XML.index(b'<invoice>'):XML.index(b'</invoice>')+10].replace(b'1.2500',b'2.5')+b'</invoicesDoc>')
        with self.assertRaises(ValueError):extract_delivery(duplicate,'1234')


if __name__=='__main__':unittest.main()
