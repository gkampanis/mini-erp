"""Independent integration counterexamples; synthetic databases only."""
import json
import tempfile
import unittest
from unittest.mock import patch
from app.application.service import ERP
from app.application.delivery import DeliveryService


class DeliverySafetyTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.erp=ERP(self.temp.name)
        self.company=self.erp.company('000000001','Synthetic');self.service=DeliveryService(self.erp)
    def tearDown(self):self.erp.close();self.temp.cleanup()
    def imported(self,role='recipient',state='3',kind='9.3',**extra):
        data=dict(environment='test',role=role,series='DA',number='1',issue_date='2026-11-03',issuer_vat='000000002' if role=='recipient' else '000000001',recipient_vat='000000001',invoice_type=kind,mark='1234',qr_url='https://example.test/qr',**extra)
        item=self.service.save_draft(self.company,data)
        with self.erp.db:self.erp.db.execute("UPDATE delivery_documents SET local_status='imported',mark='1234',aade_status=? WHERE id=?",(state,item['id']))
        return item['id']
    def test_recipient_status_includes_official_required_issuer_vat(self):
        id=self.imported()
        prepared=self.service.prepare_action(self.company,id,'GetDeliveryNoteStatus')
        self.assertEqual(prepared['payload']['issuerVatNumber'],'000000002')
    def test_consolidated_92_return_does_not_require_reverse_93_flag(self):
        id=self.imported(role='issuer',kind='9.2')
        self.assertIn('ConfirmDeliveryReturn',self.service.allowed_actions(self.company,id))
    def test_refreshed_partial_outcome_controls_followup_actions(self):
        id=self.imported(role='carrier')
        class Client:
            def perform(inner,*args,**kwargs):return dict(success=True,status='5',mark='1234',outcome='PARTIAL',lifecycle_history=[],identifiers={},raw_xml='<status/>')
        self.service.perform_action(self.company,id,'GetDeliveryNoteStatus',client=Client(),confirmed=True)
        self.assertIn('RegisterTransfer',self.service.allowed_actions(self.company,id))
    def test_failed_refresh_cannot_unlock_uncertain_write(self):
        id=self.imported(role='issuer')
        with self.erp.db:self.erp.db.execute("UPDATE delivery_documents SET local_status='uncertain' WHERE id=?",(id,))
        class Client:
            def perform(inner,*args,**kwargs):return dict(success=False,errors=[dict(message='network')],raw_xml='')
        result=self.service.perform_action(self.company,id,'GetDeliveryNoteStatus',client=Client(),confirmed=True)
        self.assertEqual(result['local_status'],'uncertain')
    def test_status_response_cannot_replace_bound_mark(self):
        id=self.imported()
        class Client:
            def perform(inner,*args,**kwargs):return dict(success=True,status='3',mark='9999',identifiers={},raw_xml='<wrong/>')
        result=self.service.perform_action(self.company,id,'GetDeliveryNoteStatus',client=Client(),confirmed=True)
        self.assertEqual(result['mark'],'1234')
        self.assertNotEqual(result['actions'][-1]['status'],'accepted')


if __name__=='__main__':unittest.main()
