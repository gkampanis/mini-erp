import unittest
from types import SimpleNamespace

from app.domain.invoice_types import classify, income_record
from app.ui.document_views import belongs, income_amounts
from app.ui.aade_dialog import acquisition_options


class RevenueSectorTests(unittest.TestCase):
    def test_revenue_excludes_nonfinancial_self_expenses_and_unknown(self):
        for code in ('8.6', '9.1', '10.2', '13.1', '14.1', '17.5', '99.99'):
            with self.subTest(code=code):
                self.assertFalse(income_record(dict(kind=code, direction='outgoing')))
                self.assertFalse(belongs(dict(classify(code), direction='outgoing'), 'income'))

    def test_invoice_with_delivery_is_one_revenue_and_a_movement(self):
        row = dict(classify('1.1', True), direction='outgoing')
        self.assertTrue(belongs(row, 'income'))
        self.assertTrue(belongs(row, 'movement'))
        self.assertTrue(income_record(dict(kind='1.1', direction='outgoing', is_delivery_note=True)))
        self.assertFalse(income_record(dict(kind='1.1', direction='incoming')))

    def test_credit_presentation_is_negative_without_double_negating_or_mutating(self):
        for sign in (1, -1):
            row = dict(family='credit_note', net_minor=sign*10000,
                       tax_minor=sign*2400, gross_minor=sign*12400)
            original = dict(row)
            self.assertEqual(income_amounts(row), dict(net_minor=-10000, tax_minor=-2400, gross_minor=-12400))
            self.assertEqual(row, original)
        self.assertEqual(income_amounts(dict(family='invoice', net_minor=100, tax_minor=24, gross_minor=124))['gross_minor'], 124)

    def test_outgoing_acquisition_avoids_expense_book_and_pdf(self):
        self.assertEqual(acquisition_options('Εκδοθέντα'), dict(methods=['RequestTransmittedDocs'], book=False, download=False))
        self.assertEqual(acquisition_options('Ληφθέντα'), dict(methods=['RequestDocs'], book=True, download=False))
        self.assertEqual(acquisition_options('Ληφθέντα και εκδοθέντα')['methods'], ['RequestDocs', 'RequestTransmittedDocs'])

    def test_filtered_revenue_count_and_totals_use_signed_values_without_tk(self):
        class Value:
            def __init__(self, value=''):self.value=value
            def get(self):return self.value
            def set(self, value):self.value=value
        from app.ui.document_views import DocumentView
        def row(identifier, code, amount):
            return dict(classify(code), id=identifier, direction='outgoing',
                        series='A', number=str(identifier), issue_date='2026-10-01',
                        name='Synthetic', vat='000000000', mark=str(identifier),
                        issuer_name='',issuer_vat='',receiver_name='',receiver_vat='',
                        correlated_marks=[],delivery_status='',
                        net_minor=amount,tax_minor=0,gross_minor=amount)
        source=[row(1,'1.1',10000),row(2,'5.1',2000),row(3,'8.6',90000)]
        panel=DocumentView.__new__(DocumentView)
        panel.owner=SimpleNamespace(_month_rows=source,month_filter=Value('October 2026'))
        panel.view='income';panel.query=Value();panel.kind=Value('Όλα');panel.count=Value()
        panel.sort=('issue_date',False)
        panel.column_filters=SimpleNamespace(apply=lambda rows:rows)
        panel.refresh(render=False)
        self.assertEqual(set(panel.rows),{1,2})
        self.assertEqual(sum(r['gross_minor'] for r in panel.rows.values()),8000)
        self.assertIn('80,00',panel.count.get())
        self.assertEqual(source[1]['gross_minor'],2000)
        panel.kind.set('Πιστωτικά');panel.refresh(render=False)
        self.assertEqual(set(panel.rows),{2})
        self.assertIn('-20,00',panel.count.get())


if __name__ == '__main__':
    unittest.main()
