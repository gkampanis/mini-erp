import tempfile
import json
import unittest
from unittest.mock import patch
from app.application.service import ERP
from app.application.delivery import DeliveryService


class DeliveryServiceTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.erp=ERP(self.temp.name)
        self.company=self.erp.company('000000001','Synthetic')
        self.service=DeliveryService(self.erp)
    def tearDown(self):
        self.erp.close();self.temp.cleanup()
    def draft(self,**changes):
        return dict(environment='test',role='issuer',series='DA',issue_date='2026-11-03',
                    counterpart_vat='000000002',counterpart_name='Receiver',issuer_vat='000000001',
                    recipient_vat='000000002',lines=[dict(description='Goods',quantity='1.250',measurement_unit=1)],**changes)
    def test_exact_quantities_reservation_and_company_scope(self):
        first=self.service.save_draft(self.company,self.draft())
        second=self.service.save_draft(self.company,self.draft())
        self.assertEqual((first['number'],second['number']),('1','2'))
        self.assertEqual(first['lines'][0]['quantity'],'1.250')
        other=self.erp.company('000000003','Other')
        with self.assertRaises(ValueError):self.service.get(other,first['id'])
        self.assertEqual(self.erp.db.execute('SELECT count(*) FROM documents').fetchone()[0],0)
    def test_invalid_quantity_does_not_consume_number(self):
        bad=self.draft();bad['lines'][0]['quantity']='NaN'
        with self.assertRaises(ValueError):self.service.save_draft(self.company,bad)
        self.assertEqual(self.service.save_draft(self.company,self.draft())['number'],'1')
    def test_edit_retains_number_and_records_history(self):
        first=self.service.save_draft(self.company,self.draft())
        edited=dict(first);edited['counterpart_name']='Changed'
        result=self.service.save_draft(self.company,edited,first['id'])
        self.assertEqual(result['number'],'1');self.assertEqual(len(result['events']),2)
    def test_confirmation_required_before_client_or_action_record(self):
        draft=self.service.save_draft(self.company,self.draft())
        with self.assertRaises(ValueError):self.service.perform_action(self.company,draft['id'],'issue',client=object())
        self.assertEqual(self.erp.db.execute('SELECT count(*) FROM delivery_actions').fetchone()[0],0)
    def test_timeout_is_durable_and_blocks_resend_without_retry(self):
        draft=self.service.save_draft(self.company,self.draft())
        class Client:
            calls=0
            def perform(inner,*args,**kwargs):
                self.assertFalse(self.erp.db.in_transaction)
                self.assertEqual(self.erp.db.execute("SELECT status FROM delivery_actions").fetchone()[0],'pending')
                inner.calls+=1;raise TimeoutError('timeout')
        client=Client()
        with patch.object(self.service,'prepare_action',return_value=dict(operation='SendInvoices',payload={'xml':'<test/>'},request={'body':b'<test/>','path':'SendInvoices','method':'POST'})):
            result=self.service.perform_action(self.company,draft['id'],'SendInvoices',client=client,confirmed=True)
            self.assertEqual(result['local_status'],'uncertain')
            with self.assertRaises(ValueError):self.service.perform_action(self.company,draft['id'],'SendInvoices',client=client,confirmed=True)
        self.assertEqual(client.calls,1)
        self.assertEqual(self.service.get(self.company,draft['id'])['actions'][0]['raw_request'],'<test/>')
    def test_http200_error_is_not_success_and_is_logged(self):
        draft=self.service.save_draft(self.company,self.draft())
        class Client:
            def perform(inner,*args,**kwargs):return dict(success=False,errors=[{'code':'101','message':'Rejected'}],raw_xml='<error/>')
        with patch.object(self.service,'prepare_action',return_value=dict(operation='SendInvoices',payload={'xml':'<test/>'},request={'body':b'<test/>','path':'SendInvoices','method':'POST'})):
            result=self.service.perform_action(self.company,draft['id'],'SendInvoices',client=Client(),confirmed=True)
        self.assertEqual(result['local_status'],'error');self.assertEqual(result['actions'][0]['raw_response'],'<error/>')
    def incoming(self,company=None):
        company=company or self.company
        with self.erp.db:
            sync=self.erp.db.execute("INSERT INTO mydata_syncs(company_id,environment,method,date_from,date_to,report) VALUES(?,'test','RequestDocs','2026-11-01','2026-11-30','{}')",(company,)).lastrowid
            data=dict(kind='9.3',is_delivery_note=True,date='2026-11-03',series='DA',number='1',vat='000000002',receiver='000000001',direction='incoming',delivery_status='Registered',mark='1234')
            id=self.erp.db.execute("INSERT INTO mydata_records(company_id,environment,mark,record_json,match_status,last_sync,invoice_type,is_delivery_note) VALUES(?,'test','1234',?,'unmatched',?,'9.3',1)",(company,json.dumps(data),sync)).lastrowid
        return 'mydata:'+str(id)
    def test_incoming_quantity_note_is_read_without_financial_document(self):
        id=self.incoming();item=self.service.get(self.company,id)
        self.assertEqual(item['role'],'recipient');self.assertIn('RejectDeliveryNote',self.service.allowed_actions(self.company,id))
        self.assertEqual(len(self.service.list(self.company,'2026-11')),1)
        self.assertEqual(self.erp.db.execute('SELECT count(*) FROM documents').fetchone()[0],0)
    def test_list_does_not_reparse_archived_xml_for_every_row(self):
        self.incoming()
        with patch('app.infrastructure.aade.delivery_read.read_record') as archive:
            self.assertEqual(len(self.service.list(self.company,'2026-11')),1)
            archive.assert_not_called()
    def test_foreign_incoming_id_is_not_visible(self):
        id=self.incoming();other=self.erp.company('000000003','Other')
        with self.assertRaises(ValueError):self.service.get(other,id)
    def test_successful_write_clears_stale_remote_state_and_keeps_qr(self):
        id=self.incoming()
        class Client:
            def perform(inner,*args,**kwargs):return dict(success=True,status=None,mark='1234',identifiers={'qrUrl':'https://example.test/qr'},raw_xml='<Success/>')
        preview=dict(operation='RejectDeliveryNote',payload={'invoiceMark':'1234'},request={'body':b'<test/>','path':'RejectDeliveryNote','method':'POST'})
        with patch.object(self.service,'prepare_action',return_value=preview):
            result=self.service.perform_action(self.company,id,'RejectDeliveryNote',client=Client(),confirmed=True)
        self.assertEqual(result['aade_status'],'');self.assertEqual(result['qr_url'],'https://example.test/qr')
        self.assertEqual(self.service.allowed_actions(self.company,result['id']),['GetDeliveryNoteStatus'])
        self.assertEqual(len(self.service.list(self.company,'2026-11')),1)
    def test_precancel_event_sends_and_records_nothing(self):
        import threading
        draft=self.service.save_draft(self.company,self.draft());cancel=threading.Event();cancel.set()
        with patch.object(self.service,'prepare_action',return_value={}):
            self.service.perform_action(self.company,draft['id'],'SendInvoices',client=object(),cancel=cancel,confirmed=True)
        self.assertEqual(self.erp.db.execute('SELECT count(*) FROM delivery_actions').fetchone()[0],0)
    def test_numeric_states_and_audited_actor_selection(self):
        id=self.incoming()
        with self.assertRaises(ValueError):self.service.set_role(self.company,id,'issuer',confirmed=True)
        with self.assertRaises(ValueError):self.service.set_role(self.company,id,'carrier')
        result=self.service.set_role(self.company,id,'carrier',confirmed=True)
        self.assertEqual(result['role'],'carrier');self.assertEqual(result['events'][-1]['event'],'role_selected')
        with self.erp.db:self.erp.db.execute("UPDATE delivery_documents SET aade_status='3' WHERE id=?",(result['id'],))
        self.assertIn('RegisterTransfer',self.service.allowed_actions(self.company,result['id']))
        self.assertIn('ConfirmDeliveryOutcome',self.service.allowed_actions(self.company,result['id']))
    def test_prepare_status_cannot_target_different_document(self):
        id=self.incoming()
        with self.assertRaises(ValueError):self.service.prepare_action(self.company,id,'GetDeliveryNoteStatus',{'mark':'9999'})
    def test_real_offline_xml_preview_and_accepted_issue_refresh(self):
        data=self.draft();data.update(loading_address=dict(street='A',number='1',postal_code='11111',city='Athens'),delivery_address=dict(street='B',number='2',postal_code='22222',city='Athens'))
        draft=self.service.save_draft(self.company,data)
        preview=self.service.prepare_action(self.company,draft['id'],'SendInvoices')
        self.assertIn(b'<',preview['request']['body']);self.assertEqual(preview['request']['method'],'POST')
        self.assertEqual(self.erp.db.execute('SELECT count(*) FROM delivery_actions').fetchone()[0],0)
        class Client:
            def perform(inner,operation,payload,**kwargs):
                return dict(success=True,mark='77',status='1' if operation=='GetDeliveryNoteStatus' else None,identifiers={'qrUrl':'https://example.test/qr'},raw_xml='<ok/>')
        result=self.service.perform_action(self.company,draft['id'],'SendInvoices',client=Client(),confirmed=True)
        self.assertEqual(result['mark'],'77');self.assertEqual(self.service.allowed_actions(self.company,result['id']),['GetDeliveryNoteStatus'])
        result=self.service.perform_action(self.company,result['id'],'GetDeliveryNoteStatus',client=Client(),confirmed=True)
        self.assertEqual(result['aade_status'],'1');self.assertIn('CancelInvoice',self.service.allowed_actions(self.company,result['id']))
    def test_failed_status_refresh_does_not_unlock_uncertain_send(self):
        draft=self.service.save_draft(self.company,self.draft())
        with self.erp.db:self.erp.db.execute("UPDATE delivery_documents SET local_status='uncertain' WHERE id=?",(draft['id'],))
        class Client:
            def perform(inner,*args,**kwargs):return dict(success=False,errors=[dict(message='network')],raw_xml='')
        with patch.object(self.service,'prepare_action',return_value=dict(operation='GetDeliveryNoteStatus',payload={'mark':'77'},request={'body':None,'path':'GetDeliveryNoteStatus?mark=77','method':'GET'})):
            result=self.service.perform_action(self.company,draft['id'],'GetDeliveryNoteStatus',client=Client(),confirmed=True)
        self.assertEqual(result['local_status'],'uncertain')
        self.assertEqual(self.service.allowed_actions(self.company,draft['id']),[])
    def test_recipient_status_query_contains_issuer_and_refresh_retains_partial(self):
        id=self.incoming();preview=self.service.prepare_action(self.company,id,'GetDeliveryNoteStatus')
        self.assertEqual(preview['payload']['issuerVatNumber'],'000000002')
        class Client:
            def perform(inner,*args,**kwargs):return dict(success=True,mark='1234',status='5',outcome='PARTIAL',lifecycle_history=[{'outcome':'PARTIAL'}],raw_xml='<status/>')
        result=self.service.perform_action(self.company,id,'GetDeliveryNoteStatus',client=Client(),confirmed=True)
        self.assertEqual(result['outcome'],'PARTIAL')
        self.assertNotIn('ConfirmDeliveryOutcome',self.service.allowed_actions(self.company,result['id']))
        result=self.service.set_role(self.company,result['id'],'carrier',confirmed=True)
        self.assertIn('RegisterTransfer',self.service.allowed_actions(self.company,result['id']))
    def test_cancel_after_known_success_does_not_restore_draft(self):
        draft=self.service.save_draft(self.company,self.draft())
        class Client:
            def perform(inner,*args,**kwargs):return dict(success=True,cancelled=True,mark='77',raw_xml='<success/>')
        preview=dict(operation='SendInvoices',payload={'xml':'<test/>'},request={'body':b'<test/>','path':'SendInvoices','method':'POST'})
        with patch.object(self.service,'prepare_action',return_value=preview):result=self.service.perform_action(self.company,draft['id'],'SendInvoices',client=Client(),confirmed=True)
        self.assertEqual(result['local_status'],'accepted');self.assertEqual(result['mark'],'77')
    def uncertain_issue(self):
        draft=self.service.save_draft(self.company,self.draft())
        class Client:
            def perform(inner,*args,**kwargs):return dict(success=False,ambiguous=True,raw_xml='')
        preview=dict(operation='SendInvoices',payload={'xml':'<test/>'},request={'body':b'<test/>','path':'SendInvoices','method':'POST'})
        with patch.object(self.service,'prepare_action',return_value=preview):return self.service.perform_action(self.company,draft['id'],'SendInvoices',client=Client(),confirmed=True)
    def official_issue(self,mark='77',**changes):
        data=dict(kind='9.3',is_delivery_note=True,date='2026-11-03',series='DA',number='1',vat='000000001',receiver='000000002',direction='outgoing',delivery_status='1',mark=mark,qr_url='https://example.test/qr')
        method=changes.pop('method','RequestTransmittedDocs');environment=changes.pop('environment','test');data.update(changes)
        with self.erp.db:
            sync=self.erp.db.execute("INSERT INTO mydata_syncs(company_id,environment,method,date_from,date_to,report) VALUES(?,?,?,'2026-11-01','2026-11-30','{}')",(self.company,environment,method)).lastrowid
            self.erp.db.execute("INSERT INTO mydata_records(company_id,environment,mark,record_json,match_status,last_sync,invoice_type,is_delivery_note) VALUES(?,?,?,?,?,?,?,1)",(self.company,environment,mark,json.dumps(data),'unmatched',sync,data['kind']))
    def test_reconcile_issue_binds_only_unique_official_outgoing_identity(self):
        draft=self.uncertain_issue();self.official_issue()
        with self.assertRaises(ValueError):self.service.reconcile_issue(self.company,draft['id'])
        result=self.service.reconcile_issue(self.company,draft['id'],confirmed=True)
        self.assertEqual(result['recovery_status'],'matched');self.assertEqual(result['mark'],'77')
        self.assertEqual(result['local_status'],'accepted');self.assertEqual(result['events'][-1]['event'],'issue_reconciled')
        self.assertEqual(result['qr_url'],'https://example.test/qr')
        self.assertEqual(len(result['actions']),1)
    def test_reconcile_issue_none_and_multiple_leave_uncertain(self):
        draft=self.uncertain_issue()
        self.assertEqual(self.service.reconcile_issue(self.company,draft['id'],confirmed=True)['recovery_status'],'not_found')
        self.official_issue('77');self.official_issue('78')
        result=self.service.reconcile_issue(self.company,draft['id'],confirmed=True)
        self.assertEqual(result['recovery_status'],'ambiguous');self.assertEqual(result['mark'],'');self.assertEqual(result['local_status'],'uncertain')
    def test_reconcile_issue_rejects_wrong_source_environment_and_identity(self):
        for changes in (dict(method='RequestDocs'),dict(environment='production'),dict(vat='000000003'),dict(series='OTHER'),dict(number='9'),dict(date='2026-11-02'),dict(kind='9.2'),dict(receiver='000000004')):
            with self.subTest(changes=changes):
                # Each distinct MARK keeps all counterexamples in the same official cache.
                self.official_issue(str(100+len(list(self.erp.db.execute('SELECT id FROM mydata_records')))),**changes)
        draft=self.uncertain_issue()
        result=self.service.reconcile_issue(self.company,draft['id'],confirmed=True)
        self.assertEqual(result['recovery_status'],'not_found');self.assertEqual(result['local_status'],'uncertain')
    def test_initial_uncertain_issue_cannot_blindly_bind_manual_mark(self):
        draft=self.uncertain_issue()
        with self.assertRaises(ValueError):self.service.prepare_action(self.company,draft['id'],'GetDeliveryNoteStatus',{'mark':'9999'})
        self.assertEqual(self.service.get(self.company,draft['id'])['mark'],'')
    def special_xml_draft(self,kind='9.2',financial=False):
        from app.infrastructure.aade.delivery_client import build_invoice_xml
        number=str(self.erp.db.execute('SELECT count(*) FROM delivery_documents').fetchone()[0]+1)
        data=self.draft();data.update(number=number,loading_address=dict(street='A',number='1',postal_code='11111',city='Athens'),delivery_address=dict(street='B',number='2',postal_code='22222',city='Athens'))
        xml=build_invoice_xml(data).replace('<ns0:invoiceType>9.3</ns0:invoiceType>','<ns0:invoiceType>'+kind+'</ns0:invoiceType>')
        if financial:xml=xml.replace('<ns0:netValue>0.00</ns0:netValue>','<ns0:netValue>1.00</ns0:netValue>')
        data.update(invoice_type=kind,original_xml=xml)
        return self.service.save_draft(self.company,data)
    def test_validated_special_quantity_xml_is_used_without_rebuilding_93(self):
        draft=self.special_xml_draft()
        preview=self.service.prepare_action(self.company,draft['id'],'SendInvoices')
        self.assertIn(b'>9.2<',preview['request']['body'])
    def test_financial_types_and_nonzero_quantity_xml_cannot_be_sent(self):
        draft=self.special_xml_draft('1.1')
        with self.assertRaises(ValueError):self.service.prepare_action(self.company,draft['id'],'SendInvoices')
        draft=self.special_xml_draft('9.2',financial=True)
        with self.assertRaises(ValueError):self.service.prepare_action(self.company,draft['id'],'SendInvoices')
    def test_raw_xml_dtd_is_rejected_before_identity_parse(self):
        draft=self.service.save_draft(self.company,self.draft())
        with self.assertRaises(ValueError):self.service.prepare_action(self.company,draft['id'],'SendInvoices',{'xml':'<!DOCTYPE x [<!ENTITY x "x">]><InvoicesDoc/>'})
