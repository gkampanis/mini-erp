"""Delivery callback safety without opening Tk windows or contacting AADE."""
from types import SimpleNamespace
import unittest
from unittest.mock import MagicMock,patch
from app.ui.delivery import DeliveryWorkspace,DraftEditor,PURPOSES,PURPOSE_CHOICES


class DeliveryUILogicTests(unittest.TestCase):
    def workspace(self):
        workspace=object.__new__(DeliveryWorkspace);callbacks={}
        def run(work,done):callbacks.update(work=work,done=done);return True
        workspace.owner=SimpleNamespace(company=1,directory='synthetic-unused',run_worker=run,root=None)
        workspace.stop_button=MagicMock();workspace.caption=MagicMock();workspace.tree=MagicMock();workspace.rows={};workspace.refresh=MagicMock()
        workspace.execute({'id':1},'SendInvoices',{},MagicMock())
        return workspace,callbacks
    def test_erp_constructor_failure_returns_to_ui_cleanup(self):
        with patch('app.application.service.ERP',side_effect=ValueError('cannot open data')):
            workspace,callbacks=self.workspace()
            result=callbacks['work']()
        with patch('app.ui.delivery.messagebox.showerror'):
            callbacks['done'](result)
        self.assertIsNone(workspace.cancel_event);workspace.stop_button.state.assert_called_with(['disabled'])
    def test_success_hidden_by_filter_does_not_select_nonexistent_item(self):
        workspace,callbacks=self.workspace()
        callbacks['done'](dict(id=1,local_status='accepted',actions=[],aade_status='1'))
        workspace.tree.selection_set.assert_not_called()
    def test_purpose_20_is_available_with_official_name(self):
        self.assertEqual(PURPOSES['20'],'20 · Μεταφορές - Ταχυμεταφορές')
    def editor(self,purpose):
        raw=dict(environment='test',series='DA',number='',issue_date='2026-11-03',counterpart_vat='000000002',movement_purpose=PURPOSES[purpose],correlated_marks='',other_movement_purpose='')
        for address in ('loading_address','delivery_address'):
            for name in ('street','number','postal_code','city'):raw[address+'.'+name]='example'
        values={key:SimpleNamespace(get=lambda value=value:value) for key,value in raw.items()}
        workspace=MagicMock();workspace.owner.company=1
        workspace.service.save_draft.return_value=dict(id=1,issue_date='2026-11-03')
        return SimpleNamespace(values=values,issuer='000000001',lines=[],workspace=workspace,original=None,destroy=MagicMock())
    def test_retired_purpose_and_missing_other_description_do_not_save(self):
        for purpose in ('6','15','16','17','18','19'):
            with self.subTest(purpose=purpose),patch('app.ui.delivery.messagebox.showerror'):
                editor=self.editor(purpose);self.assertIsNone(DraftEditor.save(editor));editor.workspace.service.save_draft.assert_not_called()
        self.assertNotIn(PURPOSES['6'],PURPOSE_CHOICES)
    def test_saved_draft_selects_its_period_before_refresh(self):
        editor=self.editor('20');DraftEditor.save(editor)
        editor.workspace.owner.select_period.assert_called_once_with('2026-11')
        self.assertEqual(editor.workspace.mock_calls.index(unittest.mock.call.owner.select_period('2026-11'))<editor.workspace.mock_calls.index(unittest.mock.call.refresh()),True)
