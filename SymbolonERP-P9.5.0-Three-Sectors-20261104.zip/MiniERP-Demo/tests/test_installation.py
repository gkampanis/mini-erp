"""Installation isolation with synthetic directories, SQLite WAL and configuration."""
from contextlib import closing
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import patch


class InstallationTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
    def tearDown(self):self.temp.cleanup()
    def database(self,path):
        path.mkdir(parents=True,exist_ok=True)
        db=sqlite3.connect(path/'mini_erp.sqlite3');db.row_factory=sqlite3.Row
        db.execute('CREATE TABLE companies(id INTEGER PRIMARY KEY,vat TEXT,name TEXT)')
        db.execute("INSERT INTO companies VALUES(1,'000000001','FIRST')");db.commit()
        return db
    def test_two_installations_never_default_to_the_shared_profile(self):
        from app.infrastructure.installation import resolve_data_directory
        for name in ('first','second'):
            root=self.root/name
            self.assertEqual(resolve_data_directory(root,{}),root/'Data')
            self.assertFalse((root/'Data').exists())
    def test_explicit_and_personal_wrapper_keep_their_existing_data(self):
        from app.infrastructure.installation import resolve_data_directory
        explicit=self.root/'explicit'
        self.assertEqual(resolve_data_directory(self.root,{'MINIERP_DATA_DIR':str(explicit)}),explicit)
        app=self.root/'personal/MiniERP-Demo';app.mkdir(parents=True)
        with closing(self.database(app.parent/'Data')):pass
        # An unrelated sibling Data is not implicitly selected.
        self.assertEqual(resolve_data_directory(app,{}),app/'Data')
        (app.parent/'personal_installation.py').touch()
        self.assertEqual(resolve_data_directory(app,{}),app.parent/'Data')
    def test_existing_local_data_has_priority_over_a_shared_legacy_database(self):
        from app.infrastructure.installation import resolve_data_directory
        with closing(self.database(self.root/'app/Data')):pass
        with closing(self.database(self.root/'profile/MiniERP/Data')):pass
        self.assertEqual(resolve_data_directory(self.root/'app',{'LOCALAPPDATA':str(self.root/'profile')}),self.root/'app/Data')
    def test_legacy_requires_explicit_choice_and_cancel_writes_nothing(self):
        from app.infrastructure.installation import resolve_data_directory,InstallationCancelled,InstallationError
        with closing(self.database(self.root/'profile/MiniERP/Data')):pass
        app=self.root/'app';env={'LOCALAPPDATA':str(self.root/'profile')}
        with self.assertRaises(InstallationError):resolve_data_directory(app,env)
        with self.assertRaises(InstallationCancelled):resolve_data_directory(app,env,lambda old:None)
        self.assertFalse((app/'Data').exists())
        self.assertEqual(resolve_data_directory(app,env,lambda old:'new'),app/'Data')
    def test_copy_preserves_committed_wal_all_settings_and_original(self):
        from app.infrastructure.installation import resolve_data_directory
        old=self.root/'profile/MiniERP/Data';db=self.database(old)
        try:
            db.execute('PRAGMA journal_mode=WAL')
            db.execute("UPDATE companies SET name='WAL CONFIGURATION'");db.commit()
            files={'ui-preferences.json':b'{"theme":"dark"}','mapping.json':b'{"account":"64.00"}','nested/archive.pdf':b'%PDF synthetic'}
            for name,data in files.items():
                p=old/name;p.parent.mkdir(exist_ok=True);p.write_bytes(data)
            copied=resolve_data_directory(self.root/'app',{'LOCALAPPDATA':str(self.root/'profile')},lambda path:'copy')
            self.assertNotEqual(copied,old)
            with closing(sqlite3.connect(copied/'mini_erp.sqlite3')) as saved:
                self.assertEqual(saved.execute('SELECT name FROM companies').fetchone()[0],'WAL CONFIGURATION')
                self.assertEqual(saved.execute('PRAGMA integrity_check').fetchone()[0],'ok')
            self.assertEqual(db.execute('SELECT name FROM companies').fetchone()[0],'WAL CONFIGURATION')
            for name,data in files.items():self.assertEqual((copied/name).read_bytes(),data);self.assertEqual((old/name).read_bytes(),data)
        finally:db.close()
    def test_copy_never_overwrites_existing_destination_and_failed_copy_leaves_no_partial_data(self):
        from app.infrastructure.installation import copy_data
        with closing(self.database(self.root/'old')):pass
        target=self.root/'target';target.mkdir();(target/'keep').write_text('existing')
        with self.assertRaises(FileExistsError):copy_data(self.root/'old',target)
        self.assertEqual((target/'keep').read_text(),'existing')
        with patch('app.infrastructure.installation.shutil.copy2',side_effect=OSError('synthetic failure')):
            (self.root/'old/config.json').write_text('{}')
            with self.assertRaises(OSError):copy_data(self.root/'old',self.root/'failed')
        self.assertFalse((self.root/'failed').exists())
    def test_binding_is_explicit_for_legacy_multi_company_and_does_not_delete_any_company(self):
        from app.infrastructure.installation import bind_company,InstallationError
        with closing(self.database(self.root/'data')) as db:
            db.execute("INSERT INTO companies VALUES(2,'000000002','SECOND')");db.commit()
            with self.assertRaises(InstallationError):bind_company(db,self.root/'data')
            selected=bind_company(db,self.root/'data',lambda rows:2)
            self.assertEqual(selected['id'],2)
            self.assertEqual(bind_company(db,self.root/'data')['id'],2)
            self.assertEqual(db.execute('SELECT COUNT(*) FROM companies').fetchone()[0],2)
    def test_single_company_binds_and_missing_or_corrupt_binding_never_falls_back(self):
        from app.infrastructure.installation import bind_company,InstallationError
        with closing(self.database(self.root/'data')) as db:
            self.assertEqual(bind_company(db,self.root/'data')['id'],1)
            identity=self.root/'data/installation.json'
            db.execute('DELETE FROM companies');db.commit()
            with self.assertRaises(InstallationError):bind_company(db,self.root/'data')
            identity.write_text('{invalid')
            with self.assertRaises(InstallationError):bind_company(db,self.root/'data')

    def test_existing_destination_identity_and_credentials_remain_separate(self):
        from app.infrastructure.installation import bind_company,resolve_data_directory
        from app.infrastructure.aade.credentials import target_for
        first=resolve_data_directory(self.root/'first',{});second=resolve_data_directory(self.root/'second',{})
        for path in (first,second):
            with closing(self.database(path)) as db:bind_company(db,path)
        a=json.loads((first/'installation.json').read_text());b=json.loads((second/'installation.json').read_text())
        self.assertNotEqual(a['installation_id'],b['installation_id'])
        self.assertNotEqual(target_for(first,'000000001','production'),target_for(second,'000000001','production'))

if __name__=='__main__':unittest.main()
